"""The rules of Campus Quest, independent of Pygame and screen layout.

Actions change a small set of dictionaries. Quests derive their progress from
those dictionaries, and JSON saves contain only ordinary Python values.
All support processes, dates and outcomes in this story are fictional.
"""

from copy import deepcopy

from events import EventManager
from quests import QuestManager


CHAPTERS = {
    1: ("First Day", "Find the Library and Lecture Theatre, then take one small first step on your project."),
    2: ("Deadline Rush", "Reach 40% on your Python project. A useful break is part of the plan."),
    3: ("Group Project Chaos", "A teammate is late. Choose how to respond and make a manageable contribution."),
    4: ("Health Disruption", "You are feeling unwell. Visit the practitioner, collect a document and make time to recover."),
    5: ("Special Consideration", "Submit a fictional request, follow its messages and provide the extra information requested."),
    6: ("Exam Season", "Revise, try a quiz and sit the fictional exam. Rest belongs in your preparation too."),
    7: ("Money Matters", "Work a short shift, make a budget and enjoy something on campus that costs nothing."),
    8: ("Career Quest", "Review your resume, meet people at the hub and practise an interview. Find your next move."),
}

SUPPORT_STATUSES = {"DRAFT", "SUBMITTED", "UNDER REVIEW",
                    "MORE INFORMATION REQUIRED", "APPROVED"}

CHALLENGE_TITLES = {"memory": "Maya's Memory Break", "route": "Petal & Bean: Cafe Rush",
                    "code": "Library Logic Lab"}


class GameState:
    """Own story state and apply validated, presentation-friendly actions."""

    def __init__(self, demo_mode=True):
        self.demo_mode = bool(demo_mode)
        self.stats = {"health": 85, "energy": 75, "focus": 60, "stress": 25,
                      "social": 40, "money": 65, "confidence": 40, "career": 0}
        self.chapter = 1
        self.clock = 9 * 60
        self.assignments = {
            "python": {"title": "COMP9001 Python Project", "progress": 0,
                       "due": "Friday 11:59 PM (story time)"},
            "group": {"title": "INFO6007 Group Project", "progress": 0,
                      "due": "Sunday 11:59 PM (story time)"},
            "quiz": {"title": "COMP9121 Practice Quiz", "progress": 0,
                     "due": "During Exam Season"},
            "revision": {"title": "Exam Revision", "progress": 0,
                         "due": "Before the fictional exam"},
        }
        self.inventory = []
        self.support_status = "DRAFT"
        self.messages = []
        self.relationships = {"Maya": 40, "Leo": 35, "Nina": 35,
                              "Group": 35, "Tutor": 35}
        self.stars = {}
        self.unlocked_levels = [1]
        self.flags = {}
        self.visited = []
        self.history = []
        self.quests = QuestManager()
        self.events = EventManager()
        self.chapter_complete = False
        self.finished = False
        self.current_location = "campus"
        self.checkpoint = None
        self._post_message("Nina", "Welcome! Start with the Library and Lecture Theatre. TAB opens your campus phone.")
        self._post_message("Campus Quest", "This is a fictional campus story. Rest, support and social connection all count as progress.")
        self.checkpoint = self._serialise(include_checkpoint=False)

    @property
    def chapter_title(self):
        return CHAPTERS[self.chapter][0]

    @property
    def chapter_description(self):
        return CHAPTERS[self.chapter][1]

    @property
    def day_name(self):
        return ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
                "Saturday", "Sunday")[(self.clock // 1440) % 7]

    @property
    def time_label(self):
        minute = self.clock % 1440
        hour = minute // 60
        return f"{hour % 12 or 12}:{minute % 60:02d} {'AM' if hour < 12 else 'PM'}"

    @property
    def objectives(self):
        return [quest.to_dict() for quest in self.quests.active(self.chapter)]

    @property
    def total_stars(self):
        return sum(sum(rating) for rating in self.stars.values())

    @property
    def timetable(self):
        """A story schedule, never a real university timetable."""
        return [
            {"time": "10:00 AM", "title": "COMP9001 lecture", "location": "Lecture Theatre"},
            {"time": "1:00 PM", "title": "Project / group study", "location": "Library"},
            {"time": "3:00 PM", "title": "Group meeting", "location": "Student Centre"},
            {"time": "4:00 PM", "title": "Free society gathering", "location": "Campus stalls"},
            {"time": "Any time", "title": "Rest and replan", "location": "Bench, cafe or phone"},
        ]

    @property
    def challenge_summary(self):
        """Describe puzzle records without adding fields to older JSON saves."""
        day = self.clock // 1440
        summary = []
        for kind, title in CHALLENGE_TITLES.items():
            prefix = f"challenge:{kind}:"
            last_reward = self.flags.get(prefix + "last_reward_day")
            summary.append({"kind": kind, "title": title,
                            "best": self.flags.get(prefix + "best", 0),
                            "attempts": self.flags.get(prefix + "attempts", 0),
                            "cleared": bool(self.flags.get(prefix + "cleared", 0)),
                            "reward_available": last_reward is None or last_reward < day})
        return summary

    @property
    def study_preview(self):
        """Show how preparation and wellbeing affect the next study session.

        The same calculation is used by the action, so the Library can explain
        its trade-off before a player spends time or energy.
        """
        base = 20 if self.demo_mode else 15
        modifier = 0
        reasons = []
        if self.stats["focus"] >= 80:
            modifier += 4
            reasons.append("high focus +4")
        if self.stats["stress"] >= 65:
            modifier -= 5
            reasons.append("high stress -5")
        if self.stats["energy"] < 25:
            modifier -= 4
            reasons.append("low energy -4")
        if self.stats["health"] < 45:
            modifier -= 3
            reasons.append("feeling unwell -3")
        boost = min(5, max(0, self.flags.get("study_boost", 0)))
        if boost:
            modifier += boost
            reasons.append(f"prepared plan +{boost}")
        increase = min(100 - self.assignments["python"]["progress"],
                       max(8, base + modifier))
        return {"base": base, "increase": increase, "modifier": modifier,
                "boost": boost, "reasons": reasons,
                "reason": "; ".join(reasons) or "steady pace"}

    def complete_challenge(self, kind, score, hints=0):
        """Record a solved puzzle and award its once-per-story-day benefit.

        Interfaces call this only after a solution; opening, retrying or leaving
        a puzzle never spends story resources. Completed replays still advance
        their activity time and improve records, without farming daily rewards.
        """
        if (not isinstance(kind, str) or kind not in CHALLENGE_TITLES
                or type(score) is not int or not 1 <= score <= 3
                or type(hints) is not int or hints < 0):
            return self._blocked("Challenge Result Unavailable",
                                 "A completed challenge needs a valid type, 1-3 stars and a non-negative hint count.")

        message_count = len(self.messages)
        prefix = f"challenge:{kind}:"
        self.flags[prefix + "attempts"] = self.flags.get(prefix + "attempts", 0) + 1
        self.flags[prefix + "best"] = max(score, self.flags.get(prefix + "best", 0))
        self.flags[prefix + "cleared"] = self.flags.get(prefix + "cleared", 0) + 1
        self.flags[prefix + "hints"] = self.flags.get(prefix + "hints", 0) + hints
        day = self.clock // 1440
        last_reward = self.flags.get(prefix + "last_reward_day")
        reward_available = last_reward is None or last_reward < day
        minutes = {"memory": 20, "route": 15, "code": 45}[kind]
        effects = {}
        item = None
        text = f"You solved {CHALLENGE_TITLES[kind]} with {score}/3 stars. "

        if reward_available:
            self.flags[prefix + "last_reward_day"] = day
            if kind == "memory":
                effects = {"energy": 12, "stress": -10, "social": 6}
                text += "A playful break restores some energy and helps you unwind."
            elif kind == "route":
                effects = {"focus": 8, "confidence": 5, "stress": -4}
                self.flags["study_boost"] = max(self.flags.get("study_boost", 0), 5)
                text += "A focused practice round helps you organise the next step. Your next study session has a +5 progress planning boost."
            else:
                before = self.assignments["python"]["progress"]
                self.assignments["python"]["progress"] = min(100, before + 10 + score * 2)
                self._mark("study")
                effects = {"energy": -5, "focus": 5, "stress": -3}
                increase = self.assignments["python"]["progress"] - before
                text += f"Your debugging practice adds {increase}% to your Python project ({self.assignments['python']['progress']}% total)."
        else:
            text += "Your personal record is updated. Today's activity reward was already collected; another becomes available on a later story day."

        if all(self.flags.get(f"challenge:{name}:cleared", 0) for name in CHALLENGE_TITLES):
            badge = "Campus Challenge Badge"
            if badge not in self.inventory:
                self.inventory.append(badge)
                item = badge
                text += " You completed all three challenges and earned the Campus Challenge Badge!"

        applied = self.change_stats(effects)
        self.history.append({"chapter": self.chapter, "action": "challenge_" + kind,
                             "time": self.clock, "score": score, "hints": hints})
        self.advance_time(minutes)
        completed = self._sync_quests()
        result = {"ok": True, "title": CHALLENGE_TITLES[kind] + " Complete!",
                  "text": text, "effects": applied, "item": item,
                  "chapter_complete": self.chapter_complete,
                  "quests_completed": [q.title for q in completed],
                  "reward_available": reward_available, "score": score}
        if len(self.messages) > message_count:
            result["notification"] = self.messages[-1]["text"]
        return result

    def _post_message(self, sender, text):
        self.messages.append({"from": sender, "text": text,
                              "time": f"{self.day_name[:3]} {self.time_label}"})

    def change_stats(self, effects):
        """Apply deltas and return actual changes after clamping."""
        changed = {}
        for key, amount in effects.items():
            if key not in self.stats:
                continue
            old = self.stats[key]
            new = max(0, old + int(amount))
            if key != "money":
                new = min(100, new)
            self.stats[key] = new
            if new != old:
                changed[key] = new - old
        return changed

    def _mark(self, action):
        key = f"{self.chapter}:{action}"
        self.flags[key] = self.flags.get(key, 0) + 1

    def _sync_quests(self):
        completed = self.quests.refresh(self)
        for quest in completed:
            self.history.append({"chapter": self.chapter,
                                 "action": "quest_complete", "title": quest.title,
                                 "time": self.clock})
        if not self.chapter_complete and self.quests.required_complete(self.chapter):
            self.chapter_complete = True
            rating = self._rate_chapter()
            previous = self.stars.get(str(self.chapter), [1, 1, 1, 1])
            self.stars[str(self.chapter)] = [max(old, new) for old, new in zip(previous, rating)]
            if self.chapter < 8 and self.chapter + 1 not in self.unlocked_levels:
                self.unlocked_levels.append(self.chapter + 1)
            if self.chapter == 8:
                self.finished = True
            self._post_message("Campus Quest", f"Chapter {self.chapter} complete! You earned {sum(self.stars[str(self.chapter)])}/12 stars.")
        return completed

    def _rate_chapter(self):
        """Four transparent 1-3 star categories; no hidden failure state."""
        health = 3 if self.stats["health"] >= 70 else (2 if self.stats["health"] >= 45 else 1)
        academic = 3 if self.quests.required_complete(self.chapter) else 1
        wellbeing = 3 if self.stats["stress"] <= 45 and self.stats["energy"] >= 35 else 2
        if self.stats["stress"] > 75 and self.stats["energy"] < 20:
            wellbeing = 1
        social = 3 if self.stats["social"] >= 55 else (2 if self.stats["social"] >= 30 else 1)
        return [health, academic, wellbeing, social]

    def visit(self, map_id):
        aliases = {"lecture_theatre": "lecture_hall", "health_center": "health_centre",
                   "student_center": "student_centre", "career": "career_hub"}
        map_id = aliases.get(map_id, map_id)
        self.current_location = map_id
        if map_id not in self.visited:
            self.visited.append(map_id)
        completed = self._sync_quests()
        return {"ok": True, "title": "A New Corner of Campus", "text": "Your campus map has been updated.",
                "quests_completed": [q.title for q in completed], "chapter_complete": self.chapter_complete}

    def advance_time(self, minutes):
        """Move story time forward and process delayed support messages."""
        self.clock += max(0, int(minutes))
        due = self.flags.get("support_due")
        if due is not None and self.clock >= due:
            if self.support_status == "SUBMITTED":
                self.support_status = "UNDER REVIEW"
                self._post_message("Student Support", "Your fictional application is now under review. You can continue other campus activities.")
                self.flags["support_due"] = due + (45 if self.demo_mode else 120)
                due = self.flags["support_due"]
            if self.support_status == "UNDER REVIEW" and self.clock >= due:
                if self.flags.get("support_followup_attached"):
                    self.support_status = "APPROVED"
                    self.flags.pop("support_due", None)
                    self.change_stats({"stress": -18, "confidence": 10})
                    self._post_message("Student Support", "Your fictional application is APPROVED. Your story assessment plan has been adjusted. Real processes and outcomes vary.")
                else:
                    self.support_status = "MORE INFORMATION REQUIRED"
                    self.flags.pop("support_due", None)
                    self._post_message("Student Support", "MORE INFORMATION REQUIRED: please revisit the Health Centre for a Follow-up Note, then attach it in this app. This is a game scenario.")
        self._sync_quests()

    def _blocked(self, title, text):
        return {"ok": False, "title": title, "text": text,
                "chapter_complete": self.chapter_complete}

    def _energy_required(self, amount):
        if self.stats["energy"] < amount:
            return self._blocked("A Smaller Next Step", "You need more energy for this action. Rest for free at a campus bench or in your phone, or visit the Health Centre. Nothing is locked while you recover.")
        return None

    def perform(self, action):
        """Run a named action and return text/effects for any interface."""
        if not isinstance(action, str):
            return self._blocked("Choose an Action", "Select a campus activity to continue.")
        if action.startswith("visit_"):
            return self.visit(action[6:])
        if action.startswith("event:"):
            parts = action.split(":")
            if len(parts) == 3:
                result = self.events.resolve(parts[1], parts[2], self)
                self._sync_quests()
                result["chapter_complete"] = self.chapter_complete
                return result
            return self._blocked("Choose a Response", "Please select one of the encounter choices.")

        aliases = {"work": "study", "library_study": "study", "attend_lecture": "lecture",
                   "practitioner": "health", "see_practitioner": "health", "health_appointment": "health",
                   "buy_snack": "snack", "buy_coffee": "coffee", "sit_maya": "maya",
                   "sit_with_maya": "maya", "revise": "revision", "sleep": "rest",
                   "shift": "money_shift", "career_shift": "money_shift", "free_event": "festival",
                   "resume": "career_resume", "network": "career_network", "interview": "career_interview",
                   "support_wait": "wait", "submit_support": "support_submit", "attach_document": "support_attach"}
        action = aliases.get(action, action)
        message_count = len(self.messages)
        item = None
        minutes = 0
        effects = {}
        title = "Find Your Next Move"
        text = ""
        major = True

        if action == "study":
            blocked = self._energy_required(10)
            if blocked:
                return blocked
            preview = self.study_preview
            increase = preview["increase"]
            before = self.assignments["python"]["progress"]
            self.assignments["python"]["progress"] = min(100, before + increase)
            self.flags.pop("study_boost", None)
            effects = {"energy": -10, "focus": -5, "stress": 4}
            if self.stats["health"] < 45:
                effects.update({"health": -3, "stress": 7})
            minutes = 60
            title = "One Session, Real Progress"
            text = f"You work on COMP9001 for an hour. Project progress: {before}% -> {self.assignments['python']['progress']}% (+{increase}%; {preview['reason']}). A manageable step counts."

        elif action == "work_plan":
            major = False
            self.flags["study_boost"] = max(self.flags.get("study_boost", 0), 5)
            effects, minutes = {"focus": 6, "stress": -3}, 15
            title = "A Smaller Next Step"
            text = ("You split your project into a clear next task. Your next study session gets a +5 progress boost. "
                    "Planning again does not stack that boost.")

        elif action == "lecture":
            blocked = self._energy_required(8)
            if blocked:
                return blocked
            effects = {"focus": 15, "energy": -8, "confidence": 3}
            minutes = 60
            title = "An Idea Clicks"
            text = "You attend the lecture, take a few useful notes and leave with a clearer direction."
            if self.chapter == 6:
                self.assignments["revision"]["progress"] = min(100, self.assignments["revision"]["progress"] + 10)

        elif action == "health":
            effects = {"health": 25, "energy": 10, "stress": -8}
            minutes = 60
            title = "You Made Room for Support"
            if self.support_status == "MORE INFORMATION REQUIRED":
                item = "Follow-up Note"
                text = "The practitioner gives you a fictional Follow-up Note. Open Phone > Student Support to attach it to your request."
            else:
                item = "Supporting Document"
                text = "After a supportive consultation, you receive a fictional Supporting Document. Keep it for the Student Support storyline."
            self.flags["practitioner_seen"] = True

        elif action == "rest":
            effects = {"energy": 35, "health": 12, "stress": -15, "focus": 6}
            minutes = 120
            title = "Rest Is Part of the Plan"
            text = "You take two quiet hours to recover. Campus will still be here when you are ready."

        elif action in ("snack", "coffee"):
            price = 6 if action == "snack" else 5
            if self.stats["money"] < price:
                return self._blocked("Keep Your Budget Intact", "There is not enough money for this purchase. Rest is free, and the campus stalls have a free society event.")
            if action == "snack":
                effects = {"money": -6, "energy": 20, "stress": -2}
                title, text = "A Proper Little Break", "A snack gives you some energy for your next step."
            else:
                effects = {"money": -5, "energy": 12, "focus": 5}
                title, text = "A Cup and a Pause", "You enjoy your coffee and a moment to collect your thoughts."
            minutes = 15

        elif action == "maya":
            effects = {"social": 15, "stress": -10, "confidence": 4}
            self.relationships["Maya"] = min(100, self.relationships["Maya"] + 12)
            minutes = 60
            title = "You Don't Have to Do It Alone"
            text = "Maya listens without trying to solve everything. You talk, laugh a little and leave feeling more connected. No purchase needed."

        elif action.startswith("group_"):
            if action not in ("group_wait", "group_message", "group_continue", "group_tutor"):
                return self._blocked("Group Meeting", "Choose whether to wait, message, continue or ask the tutor.")
            if action == "group_wait":
                effects, minutes, progress = {"stress": 3, "social": 3}, 30, 15
                title = "A Little Patience"
                text = "Your teammate eventually arrives and explains the delay. You agree on a smaller contribution and begin."
            elif action == "group_message":
                effects, minutes, progress = {"stress": -5, "social": 8, "confidence": 3}, 30, 25
                title = "A Clear, Kind Message"
                text = "You check in without blame. Your teammate replies, and the group agrees on realistic next steps."
                self.relationships["Group"] = min(100, self.relationships["Group"] + 10)
            elif action == "group_tutor":
                effects, minutes, progress = {"stress": -8, "confidence": 6}, 30, 20
                title = "Guidance Helps"
                text = "The tutor helps you document contributions and agree on a fair plan. You are not expected to carry everything."
                self.relationships["Tutor"] = min(100, self.relationships["Tutor"] + 10)
            else:
                blocked = self._energy_required(8)
                if blocked:
                    return blocked
                effects, minutes, progress = {"energy": -8, "focus": -3, "stress": 3}, 60, (35 if self.demo_mode else 25)
                title = "A Manageable Contribution"
                text = "You work on your agreed section and share what you completed with the group."
            self.flags["group_resolved"] = True
            self.assignments["group"]["progress"] = min(100, self.assignments["group"]["progress"] + progress)
            text += f" Group progress: {self.assignments['group']['progress']}%."

        elif action == "support_submit":
            if self.support_status != "DRAFT":
                return self._blocked("Request Already Started", "Your current status is " + self.support_status + ". Check the phone messages for the next step.")
            if "Supporting Document" not in self.inventory:
                return self._blocked("First, Get Supporting Information", "Visit the Health Centre practitioner to receive the fictional Supporting Document. Then return to Student Support in your phone.")
            self.support_status = "SUBMITTED"
            self.flags["support_submitted"] = True
            self.flags["support_due"] = self.clock + (30 if self.demo_mode else 120)
            effects, minutes = {"stress": -5, "confidence": 3}, 5
            title = "Request Submitted"
            text = "Your fictional request includes your Supporting Document. It is now SUBMITTED. Continue your day or choose Wait 30 minutes in this app."
            self._post_message("Student Support", "We received your fictional request. This game uses shortened, invented processing times; it does not describe university policy.")

        elif action == "support_attach":
            if self.support_status != "MORE INFORMATION REQUIRED":
                return self._blocked("Check the Current Status", "Additional information can be attached after Student Support asks for it. Current status: " + self.support_status + ".")
            if "Follow-up Note" not in self.inventory:
                return self._blocked("One More Supporting Note", "Revisit the Health Centre practitioner for a Follow-up Note. Your original document remains in your inventory.")
            self.flags["support_followup_attached"] = True
            self.support_status = "UNDER REVIEW"
            self.flags["support_due"] = self.clock + (45 if self.demo_mode else 180)
            effects, minutes = {"stress": -5}, 5
            title = "Follow-up Attached"
            text = "The fictional Follow-up Note has been attached. Your request is UNDER REVIEW again. Keep doing useful things while waiting."
            self._post_message("Student Support", "Thank you for the additional fictional information. We will send another message after review.")

        elif action in ("support_check", "support_info"):
            major = False
            title = "Student Support: " + self.support_status
            instructions = {
                "DRAFT": "Collect a Supporting Document at the Health Centre, then submit your fictional request here.",
                "SUBMITTED": "Your request is in the queue. Continue an activity or use Wait 30 minutes.",
                "UNDER REVIEW": "A staff member is reviewing the fictional request. Continue your day or use Wait 30 minutes.",
                "MORE INFORMATION REQUIRED": "Revisit the Health Centre practitioner for a Follow-up Note. Then select Attach Follow-up Note here.",
                "APPROVED": "Your fictional request is approved and the story assessment plan is adjusted.",
            }
            text = instructions[self.support_status] + " All processes, times and outcomes in this game are fictional."

        elif action == "wait":
            effects, minutes = {"energy": 4, "stress": -2}, 30
            title = "A Little Space in Your Day"
            text = "Thirty story minutes pass. You check your phone, breathe and consider your next move."

        elif action == "revision":
            blocked = self._energy_required(8)
            if blocked:
                return blocked
            self.assignments["revision"]["progress"] = min(100, self.assignments["revision"]["progress"] + (30 if self.demo_mode else 20))
            effects, minutes = {"energy": -8, "focus": 5, "stress": 2}, 60
            title = "One Topic at a Time"
            text = f"You practise a small set of questions. Revision preparation: {self.assignments['revision']['progress']}%."

        elif action == "quiz":
            blocked = self._energy_required(5)
            if blocked:
                return blocked
            self.assignments["quiz"]["progress"] = 100
            effects, minutes = {"energy": -5, "focus": 5, "confidence": 5}, 30
            title = "A Useful Knowledge Check"
            text = "You finish the practice quiz and note what to revisit. Practice is a chance to learn."

        elif action == "exam":
            if self.assignments["revision"]["progress"] < 40:
                return self._blocked("A Little More Preparation", "Reach at least 40% revision at a library computer before sitting this fictional exam.")
            blocked = self._energy_required(15)
            if blocked:
                return blocked
            self.flags["exam_completed"] = True
            effects, minutes = {"energy": -15, "stress": -12, "confidence": 10}, 90
            title = "You Showed Up Prepared"
            text = "You complete the fictional exam. Whatever comes next, this step is behind you."

        elif action == "money_shift":
            blocked = self._energy_required(15)
            if blocked:
                return blocked
            effects = {"money": 45 if self.demo_mode else 35, "energy": -15, "confidence": 5}
            minutes = 120
            title = "A Shift Finished"
            text = "You help at the cafe for two story hours and receive your fictional shift pay. Leave room to recover afterwards."

        elif action == "budget":
            effects, minutes = {"stress": -8, "confidence": 5}, 15
            title = "A Budget with Breathing Room"
            text = f"You review your ${self.stats['money']} balance, reserve money for essentials and choose a free campus activity. The game does not deduct a hidden reservation."

        elif action == "festival":
            effects, minutes = {"social": 15, "stress": -8, "energy": -3}, 45
            title = "Belonging Doesn't Need a Ticket"
            text = "You join a free society gathering at the campus stalls. A few conversations make campus feel a little more familiar."

        elif action == "transport":
            if self.stats["money"] < 4:
                return self._blocked("Take the Free Route", "The fictional shuttle costs $4. Walking around this campus is free.")
            effects, minutes = {"money": -4, "energy": 4}, 20
            title = "A Quieter Journey"
            text = "You take the fictional campus shuttle and save a little energy."

        elif action in ("career_resume", "career_appointment"):
            self.flags["resume_reviewed"] = True
            effects, minutes = {"career": 20, "confidence": 10, "focus": 5}, 45
            title = "Your Experience Has a Story"
            text = "The career adviser helps you describe your project clearly and improve your resume. Your next step is a networking conversation."
            self.flags[f"{self.chapter}:career_resume"] = self.flags.get(f"{self.chapter}:career_resume", 0) + 1

        elif action == "career_network":
            self.flags["networked"] = True
            effects, minutes = {"career": 15, "social": 12, "confidence": 8}, 45
            title = "A Conversation, Not a Test"
            text = "You introduce yourself, ask a question and learn about a possible direction. Next: try the practice interview."

        elif action == "career_interview":
            if not self.flags.get("resume_reviewed") or not self.flags.get("networked"):
                return self._blocked("Prepare Your Next Move", "Review your resume and join a networking conversation at the Career Hub before the practice interview.")
            blocked = self._energy_required(10)
            if blocked:
                return blocked
            self.flags["interview_completed"] = True
            effects, minutes = {"career": 25, "confidence": 15, "energy": -10, "stress": -8}, 60
            title = "Your Next Move Is Yours"
            text = "You practise describing a challenge, your choices and what you learned. You finish your campus journey with a plan, rather than every answer."

        elif action in ("enrolment", "timetable", "student_card", "general_support"):
            major = False
            title = "A Friendly Place to Ask"
            text = {"enrolment": "Nina: In our fictional campus, the support desk can point you towards enrolment information. You do not have to work everything out alone.",
                    "timetable": "Nina: Your phone has a story timetable. Classes, rest and social time all deserve a place in a plan.",
                    "student_card": "Support staff: Keep your campus card somewhere easy to find. We can help if it goes missing in this fictional world.",
                    "general_support": "Support staff: Start with one clear question. For the game's assessment support story, open Student Support in your phone."}[action]

        else:
            return self._blocked("Choose Your Next Move", "That activity is not available. Check your phone quests or interact with a campus location.")

        if item and item not in self.inventory:
            self.inventory.append(item)
        applied = self.change_stats(effects)
        self._mark(action)
        self.history.append({"chapter": self.chapter, "action": action, "time": self.clock})
        self.advance_time(minutes)
        completed = self._sync_quests()
        result = {"ok": True, "title": title, "text": text, "effects": applied,
                  "item": item, "chapter_complete": self.chapter_complete,
                  "quests_completed": [q.title for q in completed]}
        if len(self.messages) > message_count:
            result["notification"] = self.messages[-1]["text"]
        if major:
            event = self.events.maybe_trigger(self)
            if event:
                result["event"] = event
        return result

    def resolve_event(self, event_id, choice):
        return self.perform(f"event:{event_id}:{choice}")

    def next_chapter(self):
        if not self.chapter_complete:
            return self._blocked("A Few Steps Remain", "Check the required quests in your phone before moving to the next chapter.")
        if self.chapter >= 8:
            self.finished = True
            return {"ok": True, "title": "You Found Your Next Move", "text": "All eight chapters are complete. You can explore campus, replay this chapter or start a new story.", "chapter_complete": True}
        self.chapter += 1
        self.chapter_complete = False
        self.finished = False
        self.events.pending = None
        self.clock = max(self.clock, (self.chapter - 1) * 1440 + 9 * 60)
        if self.chapter == 3:
            self._post_message("Maya", "We are meeting at the Student Centre. One teammate is late. We can check in, keep going or ask the tutor for guidance.")
        elif self.chapter == 4:
            self.stats["health"] = 40
            self.stats["energy"] = 35
            self.change_stats({"stress": 12})
            self._post_message("Campus Quest", "Unexpected disruption: you feel unwell. The Health Centre is open, and rest is always available.")
        elif self.chapter == 5:
            self._post_message("Student Support", "Open the Student Support phone app to start your fictional application. Read later messages for follow-up steps.")
        elif self.chapter == 6:
            self._post_message("Leo", "Revision at the Library, a practice quiz, then the exam at the Lecture Theatre. Let's leave room for sleep too.")
        elif self.chapter == 7:
            self.stats["money"] = min(self.stats["money"], 18)
            self._post_message("Maya", "A tight-budget story day: there is a casual cafe shift and a free society event. Let's make a plan.")
        elif self.chapter == 8:
            self._post_message("Career Adviser", "Visit the Career Hub for a resume review, networking and a practice interview. You have a story to tell.")
        self._sync_quests()
        self.checkpoint = self._serialise(include_checkpoint=False)
        return {"ok": True, "title": self.chapter_title, "text": self.chapter_description,
                "chapter_complete": self.chapter_complete}

    def replay_chapter(self):
        if not self.checkpoint:
            return self._blocked("No Chapter Checkpoint", "Start a new story to replay from the beginning.")
        earned_stars = deepcopy(self.stars)
        unlocked = list(self.unlocked_levels)
        challenge_records = {key: value for key, value in self.flags.items()
                             if key.startswith("challenge:")}
        challenge_badge = "Campus Challenge Badge" in self.inventory
        reading_records = [deepcopy(entry) for entry in self.history
                           if isinstance(entry,dict) and entry.get('action')=='conversation']
        reading_flags = {key:value for key,value in self.flags.items() if key.startswith('talk:')}
        checkpoint = deepcopy(self.checkpoint)
        restored = GameState.from_dict(checkpoint)
        self.__dict__.update(restored.__dict__)
        self.stars = earned_stars
        self.unlocked_levels = unlocked
        self.flags.update(challenge_records)
        self.flags.update(reading_flags)
        recorded_topics = {entry.get('topic') for entry in self.history
                           if isinstance(entry,dict) and entry.get('action')=='conversation'}
        for entry in reading_records:
            if entry.get('topic') not in recorded_topics:
                self.history.append(entry)
                recorded_topics.add(entry.get('topic'))
        if challenge_badge and "Campus Challenge Badge" not in self.inventory:
            self.inventory.append("Campus Challenge Badge")
        self.checkpoint = checkpoint
        self.chapter_complete = False
        self.finished = False
        return {"ok": True, "title": "A Fresh Start", "text": f"Chapter {self.chapter}: {self.chapter_title}. Your chapter-start state is restored; earned stars and challenge records stay in your album.", "chapter_complete": False}

    def _serialise(self, include_checkpoint=True):
        fields = ("demo_mode", "stats", "chapter", "clock", "assignments", "inventory",
                  "support_status", "messages", "relationships", "stars", "unlocked_levels",
                  "flags", "visited", "history", "chapter_complete", "finished", "current_location")
        result = {name: deepcopy(getattr(self, name)) for name in fields}
        result["quests"] = self.quests.to_dict()
        result["events"] = self.events.to_dict()
        if include_checkpoint:
            result["checkpoint"] = deepcopy(self.checkpoint)
        return result

    def to_dict(self):
        return self._serialise()

    @classmethod
    def from_dict(cls, data):
        """Validate a saved state before constructing a replacement instance."""
        if not isinstance(data, dict):
            raise ValueError("The saved game state is not an object.")
        chapter = data.get("chapter")
        clock = data.get("clock")
        if not isinstance(chapter, int) or isinstance(chapter, bool) or not 1 <= chapter <= 8:
            raise ValueError("The saved chapter must be between 1 and 8.")
        if not isinstance(clock, int) or isinstance(clock, bool) or not 0 <= clock <= 10**9:
            raise ValueError("The saved game clock is invalid.")
        stats = data.get("stats")
        expected_stats = {"health", "energy", "focus", "stress", "social", "money", "confidence", "career"}
        if not isinstance(stats, dict) or not expected_stats.issubset(stats):
            raise ValueError("The saved player stats are incomplete.")
        for name in expected_stats:
            value = stats[name]
            if not isinstance(value, int) or isinstance(value, bool) or value < 0 or (name != "money" and value > 100):
                raise ValueError("The saved " + name + " stat is invalid.")
        assignments = data.get("assignments")
        if not isinstance(assignments, dict):
            raise ValueError("The saved assignments are missing.")
        for key in ("python", "group", "quiz", "revision"):
            assignment = assignments.get(key)
            if not isinstance(assignment, dict) or not isinstance(assignment.get("progress"), int) or not 0 <= assignment["progress"] <= 100:
                raise ValueError("The saved assignment progress is invalid.")
            if not isinstance(assignment.get("title"), str) or not isinstance(assignment.get("due"), str):
                raise ValueError("The saved assignment description is invalid.")
        if data.get("support_status") not in SUPPORT_STATUSES:
            raise ValueError("The saved support status is invalid.")
        for key in ("inventory", "messages", "visited", "history", "unlocked_levels"):
            if not isinstance(data.get(key), list):
                raise ValueError("The saved " + key + " list is invalid.")
        for key in ("flags", "relationships", "stars"):
            if not isinstance(data.get(key), dict):
                raise ValueError("The saved " + key + " data is invalid.")
        for key in ("inventory", "visited"):
            if any(not isinstance(value, str) for value in data[key]):
                raise ValueError("The saved " + key + " entries are invalid.")
        for message in data["messages"]:
            if not isinstance(message, dict) or any(not isinstance(message.get(key), str) for key in ("from", "text", "time")):
                raise ValueError("A saved phone message is invalid.")
        for value in data["unlocked_levels"]:
            if not isinstance(value, int) or not 1 <= value <= 8:
                raise ValueError("The saved unlocked chapters are invalid.")
        for key, ratings in data["stars"].items():
            if key not in {str(n) for n in range(1, 9)} or not isinstance(ratings, list) or len(ratings) != 4 or any(not isinstance(n, int) or not 1 <= n <= 3 for n in ratings):
                raise ValueError("The saved chapter stars are invalid.")
        if not {"Maya", "Leo", "Nina", "Group", "Tutor"}.issubset(data["relationships"]):
            raise ValueError("The saved relationships are incomplete.")
        for value in data["relationships"].values():
            if not isinstance(value, int) or not 0 <= value <= 100:
                raise ValueError("A saved relationship value is invalid.")
        for key, value in data["flags"].items():
            if not isinstance(key, str):
                raise ValueError("A saved story flag is invalid.")
            if ":" in key and (not isinstance(value, int) or value < 0):
                raise ValueError("A saved action counter is invalid.")
            if key.startswith("challenge:") and type(value) is not int:
                raise ValueError("A saved challenge record is invalid.")
            if key.startswith("challenge:") and key.endswith(":best") and value > 3:
                raise ValueError("A saved challenge star rating is invalid.")
        study_boost = data["flags"].get("study_boost", 0)
        if type(study_boost) is not int or not 0 <= study_boost <= 5:
            raise ValueError("The saved study planning boost is invalid.")
        support_due = data["flags"].get("support_due")
        if support_due is not None and (not isinstance(support_due, int) or support_due < 0):
            raise ValueError("The saved support timer is invalid.")

        state = cls(data.get("demo_mode", True))
        for name in ("stats", "chapter", "clock", "assignments", "inventory", "support_status",
                     "messages", "relationships", "stars", "unlocked_levels", "flags", "visited", "history"):
            setattr(state, name, deepcopy(data[name]))
        state.chapter_complete = bool(data.get("chapter_complete", False))
        state.finished = bool(data.get("finished", False))
        state.current_location = data.get("current_location", "campus")
        if not isinstance(state.current_location, str):
            raise ValueError("The saved location is invalid.")
        state.quests.restore(data.get("quests", []))
        state.events.restore(data.get("events", {}))
        state.checkpoint = deepcopy(data.get("checkpoint"))
        if state.checkpoint is not None and not isinstance(state.checkpoint, dict):
            raise ValueError("The saved chapter checkpoint is invalid.")
        if state.checkpoint is not None:
            if state.checkpoint.get("checkpoint") is not None:
                raise ValueError("A chapter checkpoint cannot contain another checkpoint.")
            cls.from_dict(state.checkpoint)
        # Current progress is authoritative, even if the saved quest UI was stale.
        state._sync_quests()
        return state
