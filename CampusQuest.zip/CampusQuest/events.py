"""Original, lightweight campus encounters with explicit player choices."""

from dataclasses import dataclass, field
import random


@dataclass
class Event:
    id: str
    title: str
    text: str
    choices: list
    min_chapter: int = 1
    max_chapter: int = 8
    locations: list = field(default_factory=list)

    def payload(self):
        return {
            "id": self.id,
            "title": self.title,
            "text": self.text,
            "choices": [
                {"label": choice["label"], "action": f"event:{self.id}:{i}"}
                for i, choice in enumerate(self.choices)
            ],
        }


def _choice(label, text, effects=None, minutes=0, item=None):
    return {"label": label, "text": text, "effects": effects or {},
            "minutes": minutes, "item": item}


class EventManager:
    """Seeded encounters appear only between major actions, never while walking.

    The counter is saved, so loading does not reroll a pending choice. Encounter
    effects are applied only after the player selects a response.
    """

    def __init__(self, seed=9001):
        self.seed = seed
        self.counter = 0
        self.last_trigger = -4
        self.seen = []
        self.pending = None
        later = _choice("Maybe next time", "You keep a little space in your day.")
        self.events = [
            Event("free_food", "A Little Campus Kindness", "A society stall has spare fruit and sandwiches. Would you like one?", [
                _choice("Pick up a free snack", "A free snack gives you a welcome boost.", {"energy": 12, "social": 2}, 10), later]),
            Event("society", "A Seat at the Table", "A student society invites you to a short, free board-game break.", [
                _choice("Join for a little while", "You meet a few friendly faces.", {"social": 10, "stress": -6, "energy": -3}, 25), later]),
            Event("rain", "Sudden Rain", "A spring shower rolls over campus. The covered walkway is nearby.", [
                _choice("Wait under cover", "You listen to the rain until the path clears.", {"stress": -3}, 15),
                _choice("Take the covered detour", "A slightly longer walk keeps your notes dry.", {"energy": -3}, 10)]),
            Event("printer", "Printer, Please", "The library printer is taking a break of its own. The librarian suggests a digital copy.", [
                _choice("Use the digital copy", "You adapt your plan and keep moving.", {"confidence": 3}, 5),
                _choice("Try again later", "You save the document for later.", {}, 5)]),
            Event("computer", "Every Seat Is Taken", "The busiest computer room is full. A quiet study desk is available downstairs.", [
                _choice("Plan at the quiet desk", "An outline makes your next session easier.", {"focus": 5}, 15), later]),
            Event("coffee_friend", "Coffee with a Classmate?", "A classmate waves from a cafe table. There is a spare seat.", [
                _choice("Stop for a chat (no purchase)", "A good conversation does not need a purchase.", {"social": 8, "stress": -6}, 20), later]),
            Event("tutor_announcement", "A Helpful Announcement", "Your tutor posted a short clarification about the fictional assignment.", [
                _choice("Read the clarification", "A confusing requirement now makes sense.", {"focus": 6, "confidence": 3}, 10), later]),
            Event("deadline", "One Step at a Time", "A phone reminder suggests checking the next small assignment step.", [
                _choice("Write a tiny next step", "You turn a vague task into an achievable action.", {"focus": 4, "stress": -3}, 5), later]),
            Event("career_fair", "A Future Conversation", "A career fair volunteer offers a quick introduction to the fictional showcase.", [
                _choice("Say hello", "You discover an interesting direction for later.", {"career": 5, "confidence": 4, "social": 4}, 20), later], 2),
            Event("market", "Campus Market", "Handmade badges and second-hand books fill the plaza. Browsing is free.", [
                _choice("Browse the stalls", "You enjoy a change of pace without spending.", {"stress": -5, "social": 3}, 15), later]),
            Event("student_card", "A Lost Student Card", "You spot another student's card on a bench. The support desk is nearby.", [
                _choice("Hand it to the desk", "The staff will help return the card.", {"confidence": 5, "social": 3}, 10),
                _choice("Tell a staff member", "You let a staff member know where it is.", {"confidence": 2}, 5)]),
            Event("transport_delay", "A Bus Runs Late", "Your fictional campus shuttle is delayed. You can make a small plan while waiting.", [
                _choice("Plan the next task", "You use the wait to make a calmer plan.", {"focus": 3}, 15),
                _choice("Take a short breather", "A quiet pause helps you reset.", {"energy": 5, "stress": -3}, 15)]),
            Event("merch", "A Pocket-Sized Souvenir", "The welcome booth has a few spare campus stickers.", [
                _choice("Take a sticker", "A tiny reminder of your campus journey.", {"confidence": 2}, 5, "Campus Sticker"), later]),
            Event("study_group", "Study Together?", "Leo invites you to compare notes for a few minutes.", [
                _choice("Compare notes", "Explaining one idea helps it stick.", {"focus": 7, "social": 4, "energy": -3}, 20), later]),
            Event("unexpected_quiz", "A Tiny Practice Challenge", "Nina offers an optional practice question. It is not a graded assessment.", [
                _choice("Give it a try", "Practice builds confidence, whatever the answer.", {"focus": 4, "confidence": 5}, 10), later]),
            Event("health_flare", "Listen to Yourself", "You notice you are feeling tired again. A short pause is available.", [
                _choice("Take a gentle break", "You give yourself room to recover.", {"health": 5, "energy": 8, "stress": -4}, 20),
                _choice("Choose a smaller next step", "You reduce the pressure of the next task.", {"stress": -3, "confidence": 2}, 5)], 6),
            Event("feedback", "Feedback Has Arrived", "A tutor has released encouraging fictional assessment feedback.", [
                _choice("Read and reflect", "You note one strength and one next step.", {"confidence": 8, "focus": 3}, 10), later], 2),
        ]

    def maybe_trigger(self, state):
        self.counter += 1
        if self.pending or state.chapter_complete or self.counter - self.last_trigger < 4:
            return None
        rng = random.Random(self.seed + self.counter * 73)
        if rng.random() > 0.55:
            return None
        available = [event for event in self.events
                     if event.min_chapter <= state.chapter <= event.max_chapter
                     and event.id not in self.seen[-6:]]
        if not available:
            return None
        event = rng.choice(available)
        self.pending = event.id
        self.last_trigger = self.counter
        return event.payload()

    def resolve(self, event_id, choice, state):
        if self.pending != event_id:
            return {"ok": False, "title": "That moment has passed", "text": "Continue your campus day.", "chapter_complete": state.chapter_complete}
        event = next((event for event in self.events if event.id == event_id), None)
        try:
            choice_index = int(choice)
        except (TypeError, ValueError):
            choice_index = -1
        if event is None or not 0 <= choice_index < len(event.choices):
            return {"ok": False, "title": "Choose a response", "text": "Please select one of the displayed choices.", "chapter_complete": state.chapter_complete}
        selected = event.choices[choice_index]
        effects = state.change_stats(selected["effects"])
        state.advance_time(selected["minutes"])
        item = selected.get("item")
        if item and item not in state.inventory:
            state.inventory.append(item)
        self.pending = None
        self.seen.append(event_id)
        return {"ok": True, "title": event.title, "text": selected["text"],
                "effects": effects, "item": item, "chapter_complete": state.chapter_complete}

    def current(self):
        event = next((e for e in self.events if e.id == self.pending), None)
        return event.payload() if event else None

    def to_dict(self):
        return {"seed": self.seed, "counter": self.counter,
                "last_trigger": self.last_trigger, "seen": self.seen,
                "pending": self.pending}

    def restore(self, data):
        if not isinstance(data, dict):
            return
        for name in ("seed", "counter", "last_trigger"):
            value = data.get(name)
            if isinstance(value, int):
                setattr(self, name, value)
        valid_ids = {event.id for event in self.events}
        self.seen = [key for key in data.get("seen", []) if key in valid_ids]
        self.pending = data.get("pending") if data.get("pending") in valid_ids else None
