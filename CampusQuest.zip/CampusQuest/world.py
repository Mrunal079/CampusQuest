"""JSON tile maps, physical collision, enterable interiors and campus rendering.

The same two-dimensional arrays are used for visual tiles and collision checks.
Map files are original authored data generated once by ``ensure_maps``; gameplay
loads them rather than painting temporary placeholder worlds every frame.
"""
from pathlib import Path
import json
import math
import random
import pygame
from buildings import BUILDINGS, BUILDING_BY_ID
from npc import NPC

TILE = 32
ROOT = Path(__file__).resolve().parent
MAP_DIR = ROOT / "maps"


def _blank_map(map_id, name, width, height, tile="grass0"):
    return {"id": map_id, "name": name, "tile_size": TILE,
            "tiles": [[tile for _ in range(width)] for _ in range(height)],
            "solids": [[0 for _ in range(width)] for _ in range(height)],
            "objects": [], "interactables": [], "npcs": [], "spawn": [width * 16, height * 16]}


def _paint(data, x, y, w, h, tile, solid=None):
    for row in range(max(0, y), min(len(data["tiles"]), y + h)):
        for col in range(max(0, x), min(len(data["tiles"][0]), x + w)):
            data["tiles"][row][col] = tile
            if solid is not None:
                data["solids"][row][col] = int(solid)


def _object(data, name, x, y, category="props", solid=True, collision=None):
    # Footprints match the original PNG artwork; tree canopies remain walkable.
    footprints = {"tree": (24, 80, 16, 12), "cherry_tree": (30, 80, 20, 12),
                  "bench": (6, 20, 52, 10), "lamp": (10, 52, 12, 10),
                  "fountain": (8, 24, 80, 36), "noticeboard": (7, 48, 48, 14),
                  "sign": (12, 34, 10, 12), "bike_rack": (3, 22, 58, 9)}
    if category == "props" and name in footprints:
        collision = footprints[name]
    obj = {"asset": f"{category}/{name}.png", "x": int(x), "y": int(y), "solid": solid}
    if collision:
        obj["collision"] = list(collision)
    data["objects"].append(obj)
    return obj


def _interact(data, item_id, label, x, y, kind="activity", target=None, w=44, h=32):
    entry = {"id": item_id, "label": label, "kind": kind, "x": x - w // 2,
             "y": y - h // 2, "w": w, "h": h}
    if target:
        entry["target"] = target
    data["interactables"].append(entry)


def _npc(data, npc_id, name, x, y, wander=False, direction="down", sprite=None, radius=64):
    data["npcs"].append({"id": npc_id, "name": name, "x": x, "y": y,
                         "wander": wander, "direction": direction, "radius": radius,
                         "sprite": sprite or f"npcs/{npc_id}.png"})


def _campus_map():
    rng = random.Random(9001)
    data = _blank_map("campus", "Rosewood University · Campus", 64, 44)
    for y in range(44):
        for x in range(64):
            data["tiles"][y][x] = rng.choices(("grass0", "grass1", "grass2"), (7, 2, 1))[0]
    # A wide connected path network provides alternate routes around every garden.
    for x, y, w, h in ((2, 20, 60, 3), (2, 38, 60, 3), (16, 2, 3, 39),
                        (40, 2, 3, 39), (2, 2, 60, 2), (2, 2, 2, 39), (60, 2, 2, 39)):
        _paint(data, x, y, w, h, "path0")
    # Plaza with contrasting paving and a central ornamental fountain.
    _paint(data, 23, 16, 18, 12, "path1")
    _paint(data, 26, 18, 12, 8, "path0")
    for building in BUILDINGS:
        gx, gy = building.x // TILE, building.y // TILE
        _paint(data, gx, gy, 8, 7, "grass0", 1)
        data["objects"].append(building.as_object())
        data["interactables"].append(building.as_interaction())
        door_x, door_y = building.door_position
        if building.y < 500:
            _paint(data, door_x // TILE - 1, (building.y + 224) // TILE, 3,
                   23 - (building.y + 224) // TILE, "path1", 0)
        else:
            _paint(data, door_x // TILE - 1, (building.y + 224) // TILE, 3,
                   39 - (building.y + 224) // TILE, "path1", 0)
            # Side approach connects south-facing entrances back to the main promenade.
            _paint(data, gx - 2, 22, 2, 17, "path0", 0)
        _object(data, "sign", building.x - 24, building.y + 224, collision=(4, 22, 24, 10))
        for dx in (0, 224):
            _object(data, "flowers", building.x + dx, building.y + 228, solid=False)
            _object(data, "lamp", building.x + dx, building.y + 270, collision=(9, 43, 12, 10))
        for dx in (0, 48, 176, 224):
            _object(data, "bush", building.x + dx, building.y + 200, solid=False)
    _object(data, "fountain", 976, 624, collision=(10, 40, 74, 46))
    # A koi pond and garden make the eastern walk feel different from the plaza.
    _paint(data, 53, 17, 6, 8, "water", 1)
    for x, y in ((52, 17), (58, 16), (59, 21), (53, 25), (51, 23)):
        _object(data, "rocks", x * TILE, y * TILE, collision=(5, 14, 28, 12))
    # Border trees form an intentional campus edge rather than a blank grass sea.
    for x in range(0, 64, 3):
        _object(data, "cherry_tree" if x % 2 else "tree", x * TILE - 8, -20,
                collision=(22, 59, 22, 17))
        _object(data, "tree", x * TILE - 8, 42 * TILE - 24, collision=(22, 59, 22, 17))
    for y in range(5, 42, 3):
        _object(data, "tree", -28, y * TILE - 28, collision=(22, 59, 22, 17))
        _object(data, "cherry_tree", 62 * TILE, y * TILE - 28, collision=(22, 59, 22, 17))
    # Six distinct planted pockets between the main campus routes.
    clusters = [(5, 15), (21, 7), (34, 9), (47, 14), (6, 25), (23, 30), (46, 28), (55, 39), (33, 40)]
    for index, (gx, gy) in enumerate(clusters):
        for dx, dy in ((0, 0), (2, 1), (0, 3)):
            px, py = (gx + dx) * TILE, (gy + dy) * TILE
            if 0 <= gy + dy < 44 and data["tiles"][gy + dy][gx + dx].startswith("grass"):
                _object(data, "cherry_tree" if index % 2 else "tree", px - 16, py - 28,
                        collision=(22, 59, 22, 17))
        for dx in range(4):
            _object(data, "flowers", (gx + dx) * TILE, (gy + 4) * TILE, solid=False)
    for x, y in ((10, 18), (20, 19), (45, 19), (57, 27), (12, 36), (36, 37), (47, 37)):
        _object(data, "bench", x * TILE, y * TILE, collision=(3, 25, 54, 16))
    _interact(data, "rest", "Rest on the garden bench", 10 * TILE + 30, 18 * TILE + 44)
    # Central society plaza: banners, stalls, noticeboards and benches.
    _object(data, "stall", 758, 738, collision=(4, 49, 86, 25))
    _object(data, "stall", 1154, 738, collision=(4, 49, 86, 25))
    _object(data, "banner", 748, 526, collision=(6, 40, 10, 14))
    _object(data, "banner", 1242, 526, collision=(6, 40, 10, 14))
    _object(data, "noticeboard", 674, 610, collision=(5, 38, 50, 14))
    _object(data, "noticeboard", 1302, 608, collision=(5, 38, 50, 14))
    _interact(data, "festival", "Visit the society stalls", 804, 828)
    _interact(data, "group", "Meet your project group", 1184, 704)
    for x, y in ((21, 17), (21, 24), (44, 17), (44, 24), (14, 8), (43, 8), (14, 30), (43, 31)):
        _object(data, "lamp", x * TILE, y * TILE, collision=(9, 43, 12, 10))
        _object(data, "flowers", x * TILE - 28, y * TILE + 34, solid=False)
    for x, y in ((12, 13), (36, 12), (57, 12), (12, 37), (36, 36), (57, 36)):
        _object(data, "bike_rack", x * TILE, y * TILE, collision=(3, 22, 58, 12))
    for x, y in ((20, 23), (43, 23), (20, 36), (59, 37), (5, 19)):
        _object(data, "bin", x * TILE, y * TILE, collision=(4, 22, 22, 13))
    # Café terrace is an extra social space, with room to walk between tables.
    for x, y in ((7, 25), (10, 25), (13, 25)):
        _object(data, "table", x * TILE, y * TILE, collision=(5, 22, 48, 20))
    for x, y in ((4, 24), (15, 24), (47, 26), (58, 27), (20, 12), (38, 13)):
        _object(data, "bush", x * TILE, y * TILE, collision=(2, 20, 28, 10))
    _npc(data, "nina", "Nina", 455, 443, True, radius=40)
    _npc(data, "maya", "Maya", 424, 840, True, radius=50)
    _npc(data, "leo", "Leo", 1150, 630, False)
    _npc(data, "professor", "Dr. Rowan", 1008, 420, True, radius=48)
    for index, x, y in ((1, 1370, 672), (2, 1510, 1238), (3, 550, 1170),
                        (4, 1940, 940), (5, 1380, 340), (6, 680, 294), (7, 1110, 810), (8, 117, 680)):
        _npc(data, f"student_{index}", "Student", x, y, True,
             sprite=f"npcs/student{1 + index % 3}.png", radius=100)
    data["spawn"] = [480, 392]
    return data


def _interior_map(building):
    data = _blank_map(building.id, building.name, 26, 18, "wood" if building.id in ("library", "cafe") else "floor")
    # Solid outer walls and a recessed doorway at the bottom.
    _paint(data, 0, 0, 26, 2, "wall", 1)
    _paint(data, 0, 0, 1, 18, "wall", 1)
    _paint(data, 25, 0, 1, 18, "wall", 1)
    _paint(data, 0, 17, 26, 1, "wall", 1)
    _paint(data, 12, 16, 2, 2, "floor", 0)
    _paint(data, 11, 12, 4, 4, "carpet", 0)
    _object(data, "exit_door", 384, 496, "interiors", False)
    _interact(data, "exit", "Exit to campus", 416, 542, "exit", "campus", 64, 30)
    data["spawn"] = [416, 485]
    # Details recur coherently while every room has an individual layout.
    for x in (48, 728):
        _object(data, "plant", x, 68, "interiors", collision=(8, 28, 22, 15))
    _object(data, "poster", 650, 20, "interiors", False)
    _object(data, "poster", 178, 20, "interiors", False)
    if building.id == "library":
        for x in (60, 200, 570, 710):
            for y in (100, 210):
                _object(data, "bookshelf", x, y, "interiors", collision=(2, 28, 59, 28))
        for x, y in ((105, 355), (255, 355), (520, 355), (675, 355)):
            _object(data, "desk", x, y, "interiors", collision=(2, 20, 59, 25))
            _object(data, "computer", x + 16, y - 12, "interiors", False)
            _object(data, "chair", x + 18, y + 51, "interiors", False)
        _object(data, "reception", 338, 83, "interiors", collision=(0, 22, 94, 28))
        _object(data, "printer", 688, 282, "interiors", collision=(3, 22, 25, 18))
        _npc(data, "librarian", "Librarian", 387, 159)
        _npc(data, "leo", "Leo", 560, 425)
        _interact(data, "study", "Use computer · Work on Python project", 140, 411)
        _interact(data, "study", "Use computer · Work on Python project", 290, 411)
        _interact(data, "group", "Join the project group", 550, 434)
    elif building.id == "lecture_hall":
        _object(data, "board", 303, 44, "interiors", False)
        _object(data, "projector", 400, 145, "interiors", False)
        _object(data, "desk", 365, 108, "interiors", collision=(2, 20, 59, 25))
        for y in (235, 313, 391):
            for x in (100, 170, 240, 505, 575, 645):
                _object(data, "chair", x, y, "interiors", collision=(2, 14, 27, 18))
        _npc(data, "professor", "Dr. Rowan", 435, 190)
        _npc(data, "student_lecture", "Student", 184, 290, sprite="npcs/student2.png", direction="up")
        _interact(data, "lecture", "Attend the COMP9001 lecture", 416, 229)
    elif building.id == "health_centre":
        _object(data, "reception", 300, 120, "interiors", collision=(0, 22, 94, 28))
        _object(data, "sofa", 90, 275, "interiors", collision=(3, 23, 60, 23))
        _object(data, "sofa", 90, 350, "interiors", collision=(3, 23, 60, 23))
        _object(data, "desk", 583, 250, "interiors", collision=(2, 20, 59, 25))
        _object(data, "computer", 599, 236, "interiors", False)
        for x in (220, 290, 360):
            _object(data, "chair", x, 320, "interiors", collision=(2, 14, 27, 18))
        _object(data, "plant", 672, 390, "interiors", collision=(8, 28, 22, 15))
        _npc(data, "receptionist", "Health Reception", 348, 108)
        _npc(data, "student_waiting", "Student", 251, 365, sprite="npcs/student3.png")
        _interact(data, "health", "Speak to health reception", 348, 190)
    elif building.id == "student_centre":
        _object(data, "reception", 302, 119, "interiors", collision=(0, 22, 94, 28))
        _object(data, "noticeboard", 80, 100, "props", collision=(3, 36, 55, 15))
        _object(data, "noticeboard", 654, 100, "props", collision=(3, 36, 55, 15))
        for x, y in ((80, 293), (80, 367), (650, 293), (650, 367)):
            _object(data, "sofa", x, y, "interiors", collision=(3, 23, 60, 23))
        _object(data, "desk", 521, 217, "interiors", collision=(2, 20, 59, 25))
        _object(data, "computer", 537, 205, "interiors", False)
        _npc(data, "support", "Student Support", 350, 108)
        _npc(data, "nina", "Nina", 590, 399)
        _interact(data, "support", "Ask Student Support for guidance", 350, 188)
    elif building.id == "cafe":
        _object(data, "coffee_counter", 272, 85, "interiors", collision=(0, 34, 126, 28))
        _object(data, "board", 462, 40, "interiors", False)
        for x, y in ((100, 240), (275, 300), (530, 260), (675, 370)):
            _object(data, "table", x, y, "props", collision=(5, 22, 48, 20))
            _object(data, "chair", x + 16, y + 52, "interiors", False)
        _object(data, "sofa", 80, 406, "interiors", collision=(3, 23, 60, 23))
        _npc(data, "barista", "Café Worker", 334, 95)
        _npc(data, "maya", "Maya", 569, 328)
        _interact(data, "cafe", "Order at Petal & Bean", 335, 188)
        _interact(data, "cafe", "Sit with Maya", 570, 354)
    elif building.id == "career_hub":
        _object(data, "reception", 303, 105, "interiors", collision=(0, 22, 94, 28))
        for x, y in ((96, 240), (596, 240), (96, 365), (596, 365)):
            _object(data, "showcase", x, y, "interiors", collision=(2, 22, 60, 24))
        _object(data, "desk", 355, 300, "interiors", collision=(2, 20, 59, 25))
        _object(data, "computer", 371, 288, "interiors", False)
        _npc(data, "adviser", "Career Adviser", 351, 94)
        _npc(data, "student_network", "Student", 550, 430, True, sprite="npcs/student1.png", radius=40)
        _interact(data, "career", "Meet the career adviser", 350, 179)
        _interact(data, "career", "Explore the project showcase", 625, 310)
    return data


def ensure_maps():
    """Create the original map JSON if missing, without replacing user edits."""
    MAP_DIR.mkdir(parents=True, exist_ok=True)
    sources = [("campus", _campus_map)]
    sources.extend((building.id, lambda b=building: _interior_map(b)) for building in BUILDINGS)
    for name, builder in sources:
        path = MAP_DIR / f"{name}.json"
        if not path.exists():
            path.write_text(json.dumps(builder(), indent=2), encoding="utf-8")


class World:
    """Map ownership, collision, proximity interactions and cached pixel scenery."""

    def __init__(self, assets):
        ensure_maps()
        self.assets = assets
        self.map_id = "campus"
        self.map_name = "Campus"
        self.npcs = []
        self.objects = []
        self.interactables = []
        self.solid_rects = []
        self.campus_return_positions = {b.id: b.door_position for b in BUILDINGS}
        self.background = None
        self.load("campus")

    def load(self, map_id):
        if map_id not in {"campus", *BUILDING_BY_ID.keys()}:
            map_id = "campus"
        with (MAP_DIR / f"{map_id}.json").open(encoding="utf-8") as handle:
            data = json.load(handle)
        self.map_id = map_id
        self.map_name = data["name"]
        self.tiles = data["tiles"]
        self.solids = data["solids"]
        self.width = len(self.tiles[0]) * TILE
        self.height = len(self.tiles) * TILE
        self.spawn = tuple(data["spawn"])
        self.npcs = [NPC(entry, self.assets) for entry in data["npcs"]]
        self.interactables = []
        for entry in data["interactables"]:
            interaction = dict(entry)
            interaction["rect"] = pygame.Rect(entry["x"], entry["y"], entry["w"], entry["h"])
            self.interactables.append(interaction)
        self.objects, self.solid_rects = [], []
        for entry in data["objects"]:
            obj = dict(entry)
            try:
                obj["image"] = self.assets.image(entry["asset"])
            except (FileNotFoundError, pygame.error, KeyError):
                continue
            obj["rect"] = obj["image"].get_rect(topleft=(obj["x"], obj["y"]))
            obj["sort_y"] = obj["rect"].bottom
            self.objects.append(obj)
            if obj.get("solid"):
                custom = obj.get("collision")
                if custom:
                    x, y, w, h = custom
                    self.solid_rects.append(pygame.Rect(obj["x"] + x, obj["y"] + y, w, h))
                else:
                    rect = obj["rect"]
                    self.solid_rects.append(pygame.Rect(rect.x + rect.width // 4, rect.bottom - 14, max(12, rect.width // 2), 12))
        self.background = pygame.Surface((self.width, self.height)).convert()
        for y, row in enumerate(self.tiles):
            for x, tile in enumerate(row):
                try:
                    self.background.blit(self.assets.image(f"tiles/{tile}.png"), (x * TILE, y * TILE))
                except (FileNotFoundError, pygame.error, KeyError):
                    self.background.fill((130, 167, 126), (x * TILE, y * TILE, TILE, TILE))
        self._mini_bases = {}
        return self.spawn

    def is_blocked(self, rect):
        if rect.left < 0 or rect.top < 0 or rect.right > self.width or rect.bottom > self.height:
            return True
        # Every cell touched by the feet must be walkable: a real 2D collision grid.
        left, right = max(0, rect.left // TILE), min(len(self.solids[0]) - 1, (rect.right - 1) // TILE)
        top, bottom = max(0, rect.top // TILE), min(len(self.solids) - 1, (rect.bottom - 1) // TILE)
        for y in range(top, bottom + 1):
            for x in range(left, right + 1):
                if self.solids[y][x]:
                    return True
        return any(rect.colliderect(obstacle) for obstacle in self.solid_rects)

    def move(self, rect, dx, dy):
        result = rect.copy()
        for axis, delta in ((0, dx), (1, dy)):
            test = result.move(delta if axis == 0 else 0, delta if axis == 1 else 0)
            if not self.is_blocked(test):
                result = test
        return result

    def nearest_interaction(self, player_rect):
        centre = pygame.Vector2(player_rect.center)
        nearby = []
        for interaction in self.interactables + [npc.interaction() for npc in self.npcs]:
            rect = interaction["rect"]
            closest = pygame.Vector2(max(rect.left, min(centre.x, rect.right)), max(rect.top, min(centre.y, rect.bottom)))
            distance = centre.distance_to(closest)
            if distance <= 43:
                # Interactable desks win over the receptionist behind them.
                priority = 0 if interaction["kind"] in ("activity", "door", "exit") else 8
                nearby.append((distance + priority, interaction))
        return min(nearby, key=lambda pair: pair[0])[1] if nearby else None

    def return_position(self, map_id):
        x, y = self.campus_return_positions.get(map_id, (480, 392))
        return x, y + 25

    def update(self, dt):
        for npc in self.npcs:
            npc.update(dt, self)

    def draw(self, surface, camera, player):
        surface.fill((38, 42, 53))
        surface.blit(self.background, (-round(camera.offset.x), -round(camera.offset.y)))
        viewport = pygame.Rect(round(camera.offset.x) - 160, round(camera.offset.y) - 160,
                               surface.get_width() + 320, surface.get_height() + 320)
        ordered = []
        for obj in self.objects:
            if obj["rect"].colliderect(viewport):
                ordered.append((obj["sort_y"], 0, obj))
        for npc in self.npcs:
            if viewport.collidepoint(npc.pos):
                ordered.append((npc.pos.y, 1, npc))
        ordered.append((player.pos.y, 2, player))
        for _, kind, item in sorted(ordered, key=lambda item: (item[0], item[1])):
            if kind == 0:
                surface.blit(item["image"], (round(item["x"] - camera.offset.x), round(item["y"] - camera.offset.y)))
            else:
                item.draw(surface, camera)

    def mini_map(self, size=(300, 200), player_pos=(0, 0)):
        """A cached overview reuses actual map tiles and the campus façades."""
        size = tuple(size)
        width, height = 64 * TILE, 44 * TILE
        if size not in self._mini_bases:
            if self.map_id == "campus":
                base = self.background.copy()
                for obj in self.objects:
                    if obj.get("type") == "building":
                        base.blit(obj["image"], obj["rect"])
            else:
                with (MAP_DIR / "campus.json").open(encoding="utf-8") as handle:
                    campus = json.load(handle)
                base = pygame.Surface((width, height))
                for y, row in enumerate(campus["tiles"]):
                    for x, tile in enumerate(row):
                        base.blit(self.assets.image(f"tiles/{tile}.png"), (x * TILE, y * TILE))
                for building in BUILDINGS:
                    base.blit(self.assets.image(f"buildings/{building.id}.png"), (building.x, building.y))
            self._mini_bases[size] = pygame.transform.scale(base, size)
        mini = self._mini_bases[size].copy()
        # Numbered building badges match the phone legend even at small scale.
        for number, building in enumerate(BUILDINGS, 1):
            bx = int((building.x + building.width // 2) / width * size[0])
            by = int((building.y + 110) / height * size[1])
            pygame.draw.circle(mini, (68, 51, 65), (bx, by), 9)
            digit = self.assets.font(11, True).render(str(number), True, (255, 247, 229))
            mini.blit(digit, digit.get_rect(center=(bx, by)))
        marker = player_pos if self.map_id == "campus" else self.campus_return_positions[self.map_id]
        x = int(marker[0] / width * size[0])
        y = int(marker[1] / height * size[1])
        pygame.draw.circle(mini, (48, 39, 65), (x, y), 5)
        pygame.draw.circle(mini, (255, 232, 174), (x, y), 3)
        return mini
