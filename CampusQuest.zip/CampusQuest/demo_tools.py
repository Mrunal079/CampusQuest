"""Optional presentation entry points; normal New Game always starts at Chapter 1.

These routes use the same action rules as real play. They prepare an isolated
sample journey so a three-minute presentation can begin at a later chapter.
"""
from game_state import GameState

DEMO_ROUTES = {
    1: ['visit_library', 'visit_lecture_hall', 'study'],
    2: ['study', 'rest'],
    3: ['group_message', 'group_continue'],
    4: ['health', 'rest'],
    5: ['support_submit', 'wait', 'wait', 'wait', 'health', 'support_attach', 'wait', 'wait'],
    6: ['revision', 'revision', 'quiz', 'rest', 'exam'],
    7: ['money_shift', 'budget', 'festival'],
    8: ['career_resume', 'career_network', 'career_interview'],
}


def prepare_chapter(game, chapter):
    """Open a pre-played example; the CLI uses a separate demo save slot."""
    state = GameState(demo_mode=True)
    for previous in range(1, chapter):
        for action in DEMO_ROUTES[previous]:
            result = state.perform(action)
            if not result['ok']:
                raise RuntimeError(f'Demo preparation failed: {action}: {result["text"]}')
            if state.events.pending:
                state.resolve_event(state.events.pending, 0)
        if not state.chapter_complete:
            raise RuntimeError(f'Demo chapter {previous} did not complete.')
        state.next_chapter()
    game.state = state
    game.conversations.clear()
    game.puzzle = None
    game.puzzle_return_phone = None
    game.mode = 'play'
    game.phone.open = False
    game.dialogue.close()
    game.event_queue.clear()
    game.toasts.clear()
    game.chapter_campus_return = False
    game.last_message_count = len(state.messages)
    destination = {1:'library',2:'library',3:'student_centre',4:'health_centre',
                   5:'health_centre',6:'library',7:'cafe',8:'career_hub'}[chapter]
    game.world.load('campus')
    game.player.teleport(*game.world.return_position(destination))
    game.camera.update(game.player,(game.world.width,game.world.height),0,snap=True)
    state.visit('campus')
    game.dialogue.show(f'Chapter {chapter} / {state.chapter_title}',
                      'PRESENTATION JOURNEY / This sample uses data/demo_save.json. Your normal save is separate.\n'+state.chapter_description,
                      [('FIND MY NEXT MOVE','')])
