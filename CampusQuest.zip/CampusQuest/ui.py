"""Image-backed RPG interface: HUD, dialogue, phone and chapter rewards."""
import math
import pygame
from buildings import BUILDINGS
from settings import INK, MUTED, CREAM, PINK, SAGE, BLUE, GOLD

APP_NAMES = [('quests', 'Quests'), ('timetable', 'Timetable'), ('assignments', 'Assignments'),
             ('support', 'Student Support'), ('stats', 'My wellbeing'), ('map', 'Campus map'),
             ('messages', 'Messages'), ('inventory', 'Inventory'), ('save', 'Save game')]


def wrap(text, font, width):
    lines = []
    for paragraph in str(text).split('\n'):
        line = ''
        for word in paragraph.split(' '):
            candidate = (line + ' ' + word).strip()
            if font.size(candidate)[0] <= width:
                line = candidate
            else:
                if line:
                    lines.append(line)
                line = word
                while font.size(line)[0] > width and len(line) > 1:
                    cut = len(line) - 1
                    while cut > 1 and font.size(line[:cut])[0] > width:
                        cut -= 1
                    lines.append(line[:cut])
                    line = line[cut:]
        lines.append(line)
    return lines


class UI:
    def __init__(self, assets):
        self.assets = assets
        self.panels = {}

    def text(self, surface, text, pos, size=16, color=INK, bold=False, center=False):
        img = self.assets.font(size, bold).render(str(text), True, color)
        rect = img.get_rect(center=pos) if center else img.get_rect(topleft=pos)
        surface.blit(img, rect)
        return rect

    def paragraph(self, surface, text, pos, width, size=15, color=INK, gap=4, max_lines=None):
        font = self.assets.font(size)
        lines = wrap(text, font, width)
        if max_lines and len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = lines[-1].rstrip(' .') + '...'
        for i, line in enumerate(lines):
            self.text(surface, line, (pos[0], pos[1] + i * (font.get_linesize() + gap)), size, color)
        return len(lines) * (font.get_linesize() + gap)

    def panel(self, surface, rect, selected=False, button=False):
        rect = pygame.Rect(rect)
        key = (rect.size, selected, button)
        if key not in self.panels:
            name = 'button_selected' if selected else ('button' if button else 'panel')
            source = self.assets.image(f'ui/{name}.png')
            edge = min(8, source.get_width() // 3, source.get_height() // 3, rect.w // 3, rect.h // 3)
            sw, sh = source.get_size()
            result = pygame.Surface(rect.size, pygame.SRCALPHA)
            sx = (0, edge, sw - edge)
            sy = (0, edge, sh - edge)
            ws = (edge, sw - 2 * edge, edge)
            hs = (edge, sh - 2 * edge, edge)
            dx = (0, edge, rect.w - edge)
            dy = (0, edge, rect.h - edge)
            dw = (edge, rect.w - 2 * edge, edge)
            dh = (edge, rect.h - 2 * edge, edge)
            for row in range(3):
                for col in range(3):
                    section = source.subsurface((sx[col], sy[row], ws[col], hs[row]))
                    result.blit(pygame.transform.scale(section, (dw[col], dh[row])), (dx[col], dy[row]))
            self.panels[key] = result
        surface.blit(self.panels[key], rect)
        return rect

    def icon(self, surface, name, pos, size=24):
        source = self.assets.image(f'icons/{name}.png')
        surface.blit(pygame.transform.scale(source, (size, size)), pos)

    def button(self, surface, rect, label, selected=False, enabled=True, size=15):
        rect = self.panel(surface, rect, selected=selected and enabled, button=True)
        color = CREAM if selected and enabled else (INK if enabled else MUTED)
        self.text(surface, label, rect.center, size, color, True, True)
        return rect

    def bar(self, surface, rect, value, color=SAGE, maximum=100):
        rect = pygame.Rect(rect)
        pygame.draw.rect(surface, (213, 207, 200), rect, border_radius=3)
        fill = rect.copy()
        fill.w = max(0, int(rect.w * max(0, min(maximum, value)) / maximum))
        if fill.w:
            pygame.draw.rect(surface, color, fill, border_radius=3)
            if fill.h > 4:
                pygame.draw.line(surface, tuple(min(255, c + 28) for c in color), (fill.x+2, fill.y+1), (fill.right-2, fill.y+1))

    def dim(self, surface, alpha=140):
        shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        shade.fill((35, 32, 48, alpha))
        surface.blit(shade, (0, 0))

    def hud(self, surface, game):
        state = game.state
        self.panel(surface, (16, 14, 304, 61))
        self.text(surface, f'CHAPTER {state.chapter}  /  8', (30, 23), 11, PINK, True)
        self.text(surface, state.chapter_title, (30, 40), 19, INK, True)
        self.panel(surface, (16, 81, 260, 39))
        for i, name in enumerate(('health', 'energy', 'focus')):
            x = 25 + 83 * i
            self.icon(surface, name, (x, 91), 19)
            self.bar(surface, (x + 23, 95, 49, 8), state.stats[name], [PINK, GOLD, BLUE][i])
        self.panel(surface, (745, 14, 199, 61))
        self.text(surface, state.day_name.upper(), (762, 23), 11, MUTED, True)
        self.text(surface, state.time_label, (762, 40), 19, INK, True)
        self.icon(surface, 'clock', (905, 33), 25)
        self.panel(surface, (795, 84, 149, 34))
        self.text(surface, 'TAB  /  PHONE', (810, 93), 12, INK, True)
        self.panel(surface, (795, 122, 149, 30))
        self.text(surface, 'B  /  CHALLENGES', (806, 131), 10, INK, True)
        remaining = [q for q in state.objectives if not q.get('completed') and not q.get('optional')]
        quest = remaining[0] if remaining else {'title': 'Chapter ready to finish!'}
        self.panel(surface, (16, 450, 345, 74))
        self.icon(surface, 'quests', (29, 465), 27)
        self.text(surface, 'YOUR NEXT MOVE', (66, 461), 10, PINK, True)
        self.paragraph(surface, quest['title'], (66, 478), 276, 14, max_lines=2)
        label = self.assets.font(13, True).render(game.world.map_name, True, INK)
        self.panel(surface, (936-label.get_width()-20, 497, label.get_width()+28, 27))
        surface.blit(label,(936-label.get_width()-7,503))
        if state.stats['health'] < 45:
            self.text(surface, 'Feeling unwell. Support and rest are available.', (480, 124), 13, CREAM, True, True)

    def dialogue(self, surface, dialogue):
        self.dim(surface, 65)
        choices = dialogue.choices
        height = 170 + len(choices) * 29
        y = max(95, 526 - height)
        self.panel(surface, (32, y, 896, height))
        portrait = self.assets.image(f'portraits/{dialogue.portrait}.png')
        surface.blit(pygame.transform.scale(portrait, (96, 96)), (49, y + 23))
        self.text(surface, dialogue.speaker, (162, y + 19), 19, PINK, True)
        if dialogue.topic:
            self.text(surface, dialogue.topic[:34], (650,y+23), 11, MUTED)
        self.paragraph(surface, dialogue.text[:int(dialogue.visible)], (162, y + 47), 735, 15, max_lines=4)
        dialogue.choice_rects = []
        start = y + 139
        for i, choice in enumerate(choices):
            rect = (158, start + i * 29, 741, 27)
            self.button(surface, rect, ('>  ' if i == dialogue.selected else '   ') + choice.label,
                        selected=i == dialogue.selected, size=13)
            dialogue.choice_rects.append(pygame.Rect(rect))
        back_label = 'ESC back' if dialogue.back_action else 'ESC close'
        self.text(surface, 'UP / DOWN   ENTER continue / choose   '+back_label, (52, y + height - 20), 10, MUTED)
        if len(dialogue.pages)>1:
            self.text(surface,f'PAGE {dialogue.page_index+1}/{len(dialogue.pages)}  /  LEFT previous',(657,y+height-20),10,MUTED)

    def prompt(self, surface, text, t):
        width = min(500, self.assets.font(15, True).size(text)[0] + 50)
        rect = self.panel(surface, (480 - width // 2, 398 + int(math.sin(t*4)*2), width, 38))
        self.text(surface, text, rect.center, 15, INK, True, True)

    def toast(self, surface, toast, index=0):
        title, text, timer, icon = toast
        rect = (600, 136 + index * 77, 344, 70)
        self.panel(surface, rect)
        self.icon(surface, icon, (613, rect[1] + 20), 28)
        self.text(surface, title, (651, rect[1]+11), 13, PINK, True)
        self.paragraph(surface, text, (651, rect[1]+31), 276, 12, max_lines=2)


class Phone:
    """A navigation stack ensures Escape always goes back exactly one screen."""
    def __init__(self):
        self.open = False
        self.stack = ['home']
        self.selected = 0
        self.scroll = 0
        self.max_scroll = 0
        self.targets = []
        self.animation = 0.0
        self.frame = pygame.Rect(489, 24, 433, 493)

    @property
    def screen(self):
        return self.stack[-1]

    def show(self, screen='home'):
        self.open = True
        self.stack = ['home'] if screen == 'home' else ['home', screen]
        self.selected = 0
        self.scroll = 0
        self.animation = 0

    def back(self):
        if len(self.stack) > 1:
            self.stack.pop()
            self.scroll = 0
            self.selected = 0
        else:
            self.open = False

    def navigate(self, screen):
        self.stack.append(screen)
        self.selected = 0
        self.scroll = 0

    def update(self, dt):
        self.animation = min(1, self.animation + dt * 7)

    def dispatch(self, action):
        if action == 'back':
            self.back()
            return None
        if action.startswith('app:'):
            self.navigate(action[4:])
            return None
        return action

    def handle(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_b,pygame.K_F3):
                if self.screen != 'challenges':
                    self.navigate('challenges')
                return None
            if event.key in (pygame.K_ESCAPE, pygame.K_TAB):
                self.back()
                return None
            if event.key in (pygame.K_DOWN, pygame.K_s, pygame.K_RIGHT, pygame.K_d):
                step = 3 if self.screen == 'home' and event.key in (pygame.K_DOWN, pygame.K_s) else 1
                self.selected = (self.selected + step) % max(1, len(self.targets))
                self._reveal_selected()
            if event.key in (pygame.K_UP, pygame.K_w, pygame.K_LEFT, pygame.K_a):
                step = 3 if self.screen == 'home' and event.key in (pygame.K_UP, pygame.K_w) else 1
                self.selected = (self.selected - step) % max(1, len(self.targets))
                self._reveal_selected()
            if event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e) and self.targets:
                self.selected = min(self.selected, len(self.targets) - 1)
                return self.dispatch(self.targets[self.selected][1])
            if event.key == pygame.K_PAGEDOWN:
                self.scroll = min(self.max_scroll, self.scroll + 160)
            if event.key == pygame.K_PAGEUP:
                self.scroll = max(0, self.scroll - 160)
        if event.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self.max_scroll, self.scroll - event.y * 36))
        if event.type == pygame.MOUSEMOTION:
            for i, (rect, action) in enumerate(self.targets):
                if self._target_hit(i, rect, event.pos):
                    self.selected = i
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, (rect, action) in enumerate(self.targets):
                if self._target_hit(i, rect, event.pos):
                    return self.dispatch(action)
        return None

    def _target_hit(self, index, rect, pos):
        if not rect.collidepoint(pos):
            return False
        if self.screen == 'home' or index == 0:
            return True
        return pygame.Rect(self.frame.x + 20, self.frame.y + 94, 393, 346).collidepoint(pos)

    def _reveal_selected(self):
        if self.screen == 'home' or not self.targets:
            return
        rect = self.targets[self.selected][0]
        if rect.y < 121:
            self.scroll = max(0, self.scroll - (121 - rect.y))
        elif rect.bottom > 467:
            self.scroll = min(self.max_scroll, self.scroll + rect.bottom - 467)

    def draw(self, surface, game):
        ui = game.ui
        state = game.state
        ui.dim(surface, 125)
        offset = int((1-self.animation)**2 * 510)
        canvas = pygame.Surface((433, 493), pygame.SRCALPHA)
        ui.panel(canvas, (0, 0, 433, 493))
        # A raster phone bezel and home indicator surround all application screens.
        pygame.draw.rect(canvas, INK, (182, 10, 69, 5), border_radius=2)
        pygame.draw.rect(canvas, INK, (180, 477, 73, 4), border_radius=2)
        ui.text(canvas, state.time_label, (24, 21), 10, MUTED, True)
        ui.text(canvas, 'CAMPUS / CONNECTED', (270, 21), 9, SAGE, True)
        self.targets = []
        x0, y0 = self.frame.x + offset, self.frame.y
        if self.screen == 'home':
            ui.text(canvas, 'Your campus, in your pocket.', (25, 49), 19, INK, True)
            ui.text(canvas, 'Take one next step.', (25, 77), 13, MUTED)
            for i, (name, label) in enumerate(APP_NAMES):
                col, row = i % 3, i // 3
                rect = pygame.Rect(23 + col*131, 112+row*100, 124, 91)
                ui.panel(canvas, rect, selected=i == self.selected, button=True)
                ui.icon(canvas, name, (rect.centerx-18, rect.y+12), 36)
                ui.text(canvas, label, (rect.centerx, rect.y+66), 11, INK, True, True)
                self.targets.append((rect.move(x0, y0), 'app:'+name))
            rect = ui.button(canvas,(24,417,385,32),'PLAY A CAMPUS CHALLENGE',self.selected==9,size=12)
            self.targets.append((rect.move(x0,y0),'app:challenges'))
            ui.text(canvas, 'Arrows + Enter / click     ESC closes phone', (30, 459), 10, MUTED)
            self.max_scroll = 0
        else:
            label = dict(APP_NAMES).get(self.screen, self.screen.title())
            if self.screen.startswith('contact:'):
                label='Conversation topics'
            elif self.screen.startswith('transcript:'):
                label='Saved explanation'
            ui.text(canvas, label, (25, 49), 23, INK, True)
            rect = ui.button(canvas, (316, 45, 92, 30), '< BACK', self.selected == 0, size=12)
            self.targets.append((rect.move(x0, y0), 'back'))
            viewport = pygame.Rect(20, 94, 393, 346)
            canvas.set_clip(viewport)
            y = 99 - self.scroll
            self._origin = (x0, y0)
            self._canvas = canvas
            self._ui = ui
            y = self.draw_content(game, y)
            self.selected = min(self.selected, max(0, len(self.targets) - 1))
            self.max_scroll = max(0, y + self.scroll - 435)
            self.scroll = min(self.scroll, self.max_scroll)
            canvas.set_clip(None)
            if self.max_scroll:
                pygame.draw.rect(canvas, (217, 207, 201), (416, 103, 3, 329), border_radius=1)
                thumb = max(28, int(329*346/(346+self.max_scroll)))
                top = 103 + int((329-thumb)*self.scroll/max(1,self.max_scroll))
                pygame.draw.rect(canvas, PINK, (416, top, 3, thumb), border_radius=1)
            ui.text(canvas, 'ESC = back   /   scroll for more', (26, 451), 11, MUTED)
        surface.blit(canvas, (x0, y0))

    def line(self, text, y, color=INK, size=14, bold=False):
        h = self._ui.paragraph(self._canvas, text, (30, y), 365, size, color)
        return y + h + 8

    def heading(self, text, y):
        self._ui.text(self._canvas, text, (30, y), 12, PINK, True)
        return y + 25

    def action(self, label, action, y):
        rect = pygame.Rect(29, y, 374, 36)
        selected = len(self.targets) == self.selected
        self._ui.button(self._canvas, rect, label, selected, size=12)
        # Keep offscreen targets so keyboard selection can scroll to them.
        self.targets.append((rect.move(*self._origin), action))
        return y + 43

    def draw_content(self, game, y):
        state, ui, s = game.state, self._ui, self._canvas
        if self.screen == 'quests':
            y = self.heading(f'CHAPTER {state.chapter} / {state.chapter_title.upper()}', y)
            y = self.line(state.chapter_description, y, MUTED, 13)
            y = self.action('Take a break / campus challenges', 'app:challenges', y)
            for q in state.objectives:
                ui.icon(s, 'star' if q.get('completed') else 'quests', (29,y+1), 22)
                h = ui.paragraph(s, q['title'], (62,y), 332, 14)
                y += max(28,h+3)
                y = self.line(q.get('description',''), y, MUTED, 12)
                target = max(1, q.get('target',1))
                ui.bar(s, (31,y,369,7), q.get('progress',0), SAGE, target)
                y += 23
                y = self.line('COMPLETE' if q.get('completed') else f"Progress: {int(q.get('progress',0))} / {target}", y, SAGE if q.get('completed') else MUTED, 11)
            y = self.action('View chapter journey', 'chapters', y+5)
        elif self.screen == 'challenges':
            y = self.line('A different kind of next move: play, solve and recharge. H gives a hint; Escape lets you leave.', y, MUTED, 13)
            descriptions = {
                'memory': 'Match eight pairs of campus cards with Maya. A completed round restores energy and eases stress.',
                'route': 'Mix six customer orders at Petal & Bean. Read the recipe tickets, manage the queue and build a serving streak.',
                'code': 'Reorder Python statements in three rounds. Solving the Logic Lab makes real project progress.',
            }
            for record in state.challenge_summary:
                y = self.heading(record['title'].upper(), y)
                y = self.line(descriptions[record['kind']], y, INK, 13)
                caption = f"Best: {record['best']}/3 stars  /  Completed: {record['attempts']}"
                y = self.line(caption, y, MUTED, 11)
                y = self.line('Daily reward available' if record['reward_available'] else 'Practice again; daily reward already collected', y, SAGE, 11)
                y = self.action('PLAY / ' + record['title'].upper(), 'puzzle:'+record['kind'], y)
                y += 12
            y = self.line('Finish all three to earn a Campus Challenge Badge. Records and rewards are saved with your journey.', y, MUTED, 12)
        elif self.screen == 'timetable':
            y = self.line('Fictional timetable. Walking pauses the clock; activities advance it.', y, MUTED, 12)
            schedules = [('10:00', 'COMP9001 lecture', 'Lecture Theatre'), ('13:00', 'Project group meeting', 'Library / project table'),
                         ('16:00', 'Society welcome stall', 'Campus plaza'), ('17:00', 'Career conversations', 'Career & Innovation Hub')]
            for time, title, place in schedules:
                y = self.heading(time + '  /  ' + state.day_name.upper(), y)
                y = self.line(title, y, INK, 16)
                y = self.line(place, y, MUTED, 12)
            y = self.line('These are story prompts, not real bookings. Activities remain available so you can recover and explore.',y,MUTED,12)
        elif self.screen == 'assignments':
            for key, a in state.assignments.items():
                y = self.line(a['title'], y, INK, 16)
                ui.bar(s, (31,y,369,10), a['progress'], BLUE)
                y += 19
                y = self.line(f"{int(a['progress'])}% complete  /  Due: {a['due']}",y,MUTED,12)
                y += 12
            y = self.line('Visit a library computer to work. Revision and the practice exam unlock in Chapter 6.',y,MUTED,12)
        elif self.screen == 'support':
            y = self.heading('SPECIAL CONSIDERATION / FICTIONAL STORY',y)
            y = self.line('This is a simplified game process, not university policy or a real application.',y,MUTED,12)
            y = self.line(state.support_status.replace('_',' '), y, PINK, 17)
            stages = ['DRAFT','SUBMITTED','UNDER REVIEW','MORE INFORMATION REQUIRED','APPROVED']
            for status in stages:
                mark = '> ' if status == state.support_status else '   '
                y = self.line(mark+status, y, SAGE if status == state.support_status else MUTED,11)
            if state.chapter < 5:
                y = self.line('The request becomes available in Chapter 5. Visit the Health Centre when the health storyline begins.',y,MUTED,13)
            else:
                if state.support_status == 'DRAFT':
                    y = self.action('Submit request with supporting document','support_submit',y)
                elif state.support_status == 'MORE INFORMATION REQUIRED':
                    y = self.line('Visit the Health Centre for a follow-up note, then attach it here.',y,INK,13)
                    y = self.action('Attach follow-up information','support_attach',y)
                y = self.action('Check application status','support_check',y)
                if state.support_status not in ('DRAFT','APPROVED'):
                    y = self.action('Wait a little / check for a reply','wait',y)
            y = self.action('Read student services guide','services',y)
            y = self.action('Review my budget','budget',y)
        elif self.screen == 'stats':
            portrait = 'student_tired' if state.stats['health'] < 45 or state.stats['energy'] < 25 else 'student_happy'
            s.blit(pygame.transform.scale(ui.assets.image(f'portraits/{portrait}.png'), (64,64)), (30,y))
            ui.text(s,'How are you doing?',(111,y+8),17,INK,True)
            ui.text(s,'One useful next step.',(111,y+34),13,MUTED)
            y += 76
            y = self.line('A snapshot, not a score of your worth. Rest and support are useful choices.',y,MUTED,12)
            y = self.action('Play a refreshing break puzzle','app:challenges',y)
            for i, (name, value) in enumerate(state.stats.items()):
                icon = name if name in ['health','energy','focus','stress','social','money','career'] else 'star'
                ui.icon(s,icon,(30,y),24)
                ui.text(s,name.title(),(65,y+1),14,INK,True)
                ui.text(s,f'${value}' if name=='money' else str(value),(340,y+1),14,INK,True)
                y += 29
                if name != 'money':
                    ui.bar(s,(65,y,330,7),value,PINK if name=='stress' else SAGE)
                    y += 18
            y = self.line('Higher stress makes work harder. Low health slows movement; it never ends your game.',y,MUTED,12)
            y = self.action('Take a free rest / 2 hours','rest',y)
            y = self.action('Review my budget','budget',y)
        elif self.screen == 'map':
            mini = game.world.mini_map(size=(365,230), player_pos=game.player.pos)
            s.blit(mini, (32,y))
            y += 243
            y = self.heading('YOU ARE HERE / ' + game.world.map_name.upper(),y)
            for num, building in enumerate(BUILDINGS,1):
                y = self.line(f'{num}. {building.name}',y,INK,13)
            y = self.line('Approach a doorway, then press E. Leave interiors through their exit door.',y,MUTED,12)
        elif self.screen == 'messages':
            y = self.action('Read my conversation journal','app:conversations',y)
            if not state.messages:
                y = self.line('No messages yet. Your campus story is just beginning.',y,MUTED)
            for message in reversed(state.messages[-16:]):
                sender = message.get('from',message.get('sender','Campus'))
                y = self.heading(str(sender).upper(),y)
                y = self.line(message.get('text',''),y,INK,13)
                y += 8
        elif self.screen == 'conversations':
            y = self.line('Saved explanations from the people you have spoken with. Reading and asking questions do not spend story time.',y,MUTED,12)
            records=[entry for entry in state.history if isinstance(entry,dict) and entry.get('action')=='conversation']
            if not records:
                y = self.line('Talk to a student or staff member, then ask about a topic. Their explanations will appear here.',y,INK,14)
            names=list(dict.fromkeys(entry.get('npc','Campus conversation') for entry in records))
            for name in names:
                count=sum(entry.get('npc')==name for entry in records)
                y = self.line(f'{count} saved topics',y,MUTED,11)
                y = self.action(name,'app:contact:'+name,y)
        elif self.screen.startswith('contact:'):
            name=self.screen.split(':',1)[1]
            y = self.heading(name.upper(),y)
            records=[entry for entry in state.history if isinstance(entry,dict) and entry.get('action')=='conversation' and entry.get('npc')==name]
            for entry in reversed(records):
                y = self.action(entry.get('title','A question'),'app:transcript:'+entry['topic'],y)
        elif self.screen.startswith('transcript:'):
            topic=self.screen.split(':',1)[1]
            record=next((entry for entry in reversed(state.history) if isinstance(entry,dict) and entry.get('action')=='conversation' and entry.get('topic')==topic),None)
            if record:
                y = self.heading(record.get('npc','Campus conversation').upper(),y)
                y = self.line(record.get('title','A question'),y,PINK,16)
                y = self.line(record.get('text',''),y,INK,14)
        elif self.screen == 'inventory':
            if not state.inventory:
                y = self.line('Your backpack is ready for the journey. Story items will appear here.',y,MUTED)
            for item in state.inventory:
                ui.icon(s,'document' if 'Document' in item or 'Note' in item else 'inventory',(30,y),30)
                h=ui.paragraph(s,str(item),(73,y+4),320,15)
                y += max(44,h+12)
            y = self.line('Supporting documents are fictional story items and stay within this local game.',y,MUTED,12)
        elif self.screen == 'save':
            y = self.heading('KEEP YOUR NEXT MOVE',y)
            y = self.line('Save your location, chapter, wellbeing, assignments, inventory, messages and support request.',y,INK,15)
            y = self.action('Save this journey','save',y+8)
            y = self.line('One local save slot. New Game does not replace your save until you choose Save. Chapter transitions also save automatically.',y,MUTED,12)
            y = self.line('Save file: data/save.json',y,MUTED,12)
        return y
