"""Small, presentation-friendly configuration for Campus Quest."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
ASSET_DIR = BASE_DIR / 'assets'
MAP_DIR = BASE_DIR / 'maps'
SAVE_PATH = BASE_DIR / 'data' / 'save.json'
INTERNAL_SIZE = (960, 540)
WINDOW_SIZE = (1280, 720)
FPS = 60
TILE_SIZE = 32
PLAYER_SPEED = 148
DEMO_MODE = True
SOUND_ENABLED = True
TITLE = 'Campus Quest: Find Your Next Move'

INK = (68, 51, 65)
MUTED = (119, 111, 118)
CREAM = (255, 247, 229)
PINK = (213, 116, 142)
SAGE = (105, 151, 124)
BLUE = (116, 155, 177)
GOLD = (217, 169, 80)
