"""ENTRY POINT: run python3 main.py. Install requirements.txt first.

Desktop Pygame GUI with optional WAV playback; requires pygame-ce and Pillow.
Run locally outside Ed. See README.txt for precise installation instructions.
"""
import argparse
import os
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description='Campus Quest: Find Your Next Move')
    parser.add_argument('--headless',action='store_true',help='Use SDL dummy drivers for automated checks')
    parser.add_argument('--frames',type=int,help='Exit after this many frames')
    parser.add_argument('--scene',choices=['title','campus','library','phone','complete','memory','route','cafe','code'],default='title',help='Open a visual review scene')
    parser.add_argument('--screenshot',type=Path,help='Write an internal-resolution PNG after the run')
    parser.add_argument('--demo-chapter',type=int,choices=range(1,9),help='Start an isolated presentation journey at a chosen chapter')
    args=parser.parse_args()
    if args.headless:
        os.environ['SDL_VIDEODRIVER']='dummy'
        os.environ['SDL_AUDIODRIVER']='dummy'
    os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
    try:
        import pygame
    except ImportError:
        raise SystemExit('Pygame is missing. Run: python3 -m pip install -r requirements.txt')
    from asset_generator import generate_assets
    generate_assets()
    from game import Game
    demo_save = Path(__file__).resolve().parent / 'data' / 'demo_save.json' if args.demo_chapter else None
    game=Game(headless=args.headless,save_path=demo_save)
    if args.scene!='title':
        game.new_game()
        game.dialogue.close()
        if args.scene=='library':
            spawn=game.world.load('library')
            game.player.teleport(*spawn)
            game.camera.update(game.player,(game.world.width,game.world.height),0,snap=True)
        elif args.scene=='phone':
            game.phone.show()
        elif args.scene=='complete':
            game.state.stars['1']=[3,3,3,2]
            game.mode='complete'
        elif args.scene in ('memory','route','cafe','code'):
            game.start_challenge('route' if args.scene == 'cafe' else args.scene)
    if args.demo_chapter:
        from demo_tools import prepare_chapter
        prepare_chapter(game,args.demo_chapter)
    try:
        game.run(args.frames)
        if args.screenshot:
            args.screenshot.parent.mkdir(parents=True,exist_ok=True)
            pygame.image.save(game.canvas,str(args.screenshot))
    finally:
        pygame.quit()


if __name__=='__main__':
    main()
