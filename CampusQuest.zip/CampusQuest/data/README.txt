Campus Quest creates save.json here when you save or complete/advance a chapter.
Optional --demo-chapter presentation journeys use demo_save.json instead.
No pre-existing saved story is required. Continue activates after the first save.
