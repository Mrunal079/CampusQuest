# Verification record

Verified on 1 November 2026 on this macOS host with Anaconda Python 3.12.7,
pygame-ce 2.5.8 / SDL 2.32.10 and Pillow 10.4.0.

- All Python files passed compileall syntax checks.
- **70 automated tests passed** in the final project directory.
- A real native Pygame window ran for 180 frames and exited successfully.
- The final entry point also ran 60 headless frames from outside the project
  directory and wrote screenshots/final_title.png with no exception.
- Title, campus, library, dialogue, phone, map, health reception, wellbeing,
  support workflow and chapter rewards were rendered to PNGs and inspected.

The test suites cover:

- Full eight-chapter completion via state rules and via actual UI dialogue choices.
- All eight isolated presentation chapter starts and subsequent completion.
- Normalised movement, blocked movement and all six building entrances/exits.
- Traversable paths to every mapped activity using the real collision grid.
- Escape priority, phone navigation, scrollable screens and student-service topics.
- Five support statuses, the required document and requested follow-up note.
- Free recovery when money and energy are zero.
- Chapter replay, star retention, pending encounters and all 17 event choices.
- Save/continue exact position and state, chapter-arrival autosave and corrupt saves.
- Rejection of invalid player coordinates without damaging the running game.

Commands:

```bash
python3 -m compileall -q .
python3 -m unittest discover -s tests -v
python3 main.py --headless --frames 60
```

The project targets 60 FPS; this is a target, not a hardware performance guarantee.
Windows launch instructions are included but Windows was not available for testing.
See README.md for the bounded story/scheduling mechanics and known limitations.

## Building-sign readability update

All six facade signs now use larger high-contrast lettering drawn at final PNG
resolution. Their unchanged 256 x 224 dimensions preserve doors and collisions.
The actual campus was rendered after regeneration and all six signs were
visually checked; screenshots/building_signs.png shows the updated artwork.

## Playable challenges update

- Added memory matching, a collect-and-route maze and three-round Python
  statement-ordering challenges, with mouse/keyboard controls, hints and replay.
- All 53 tests pass, including eight actual-game challenge integration checks,
  nine pure puzzle checks, fourteen reward/study checks and the original 22.
- Verified daily rewards, real-completion checks, cancellation, old-save
  compatibility, saved best scores, the badge and continued support timers.
- All eight existing story chapters still pass their original progression tests.
- Rendered and visually reviewed all puzzle screens, the phone entry points
  and the study-efficiency preview. A native Mac puzzle window ran 180 frames
  successfully; screenshots/native_memory.png records the rendered frame.
- No extra dependencies were introduced.

## Branching conversation update

- Added 110 authored conversation nodes with examples and follow-up questions,
  including section-by-section resume help and response-specific interview feedback.
- Named students have individual topics. Staff explain their services before the
  player explicitly chooses an activity. Reading does not change resources or time.
- All 65 tests pass, including 12 conversation checks and all existing story,
  exploration, phone, save, puzzle and reward checks.
- Every authored topic was rendered with the real dialogue font; each page fits
  within four lines and the available width. Mouse/keyboard paging and follow-up
  selection, previous-topic navigation, and paused NPC movement were checked.
- Verified first-read journal entries, existing-save compatibility, save/continue,
  chapter-replay retention and story-dependent support explanations.
- Rendered eight conversation/journal screens and visually reviewed the resume
  menu, paged examples, follow-up choices and conversation journal. These current
  checks used SDL's dummy display; the native-window checks above predate this update.
- No extra dependencies or save-schema changes were introduced.

## Cafe Rush replacement

- Replaced Rainy-Day Relay with Petal & Bean: Cafe Rush. Memory Break and Logic
  Lab retain their existing models, controls and rewards.
- Six customers, three active tickets, four visible recipes, ingredient quantities,
  cup editing, customer selection, patience timers and serving streaks are playable
  using the mouse or keyboard. Timers start with the first ingredient or help.
- Late customers retain their requests, so every round remains finishable.
  Wrong recipes clear the cup and permit retry; hints prepare a recipe without
  completing the round or claiming a reward.
- All 70 tests pass. Checks include 16 seeded rounds solved using ingredients,
  wrong quantities, serving in a different pouring order, undo/clear, queue
  replenishment, patience expiry, deterministic restart and completed-state guards.
- Actual game input checks cover mouse/keyboard serving, explicit reward claims,
  cancellation without stat changes and Jun's conversation entry/return path.
- Existing challenge records use their previous internal save key. Badge progress,
  daily reward limits, all eight chapters and saved conversations continue to pass.
- Rendered and visually inspected the initial counter, a filled cup during play,
  completion stars and refreshed phone challenge screen using SDL's dummy display.
- Refreshed instructions and release ZIP; no extra dependencies were introduced.
