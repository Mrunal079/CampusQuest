"""Readable, image-backed break challenges for the Campus Quest world.

The screen owns presentation and input only. The puzzle models contain the rules,
and the game awards a reward only after the player explicitly claims a result.
"""
from pathlib import Path

import pygame

from puzzles import MemoryPuzzle, CafePuzzle, CodePuzzle
from settings import INK, MUTED, CREAM, PINK, SAGE, BLUE, GOLD


CHALLENGES = {
    'memory': ("Maya's Memory Break", 'Take a breath. Find the pairs. Get back to your next move.', 'social'),
    'route': ('Petal & Bean: Cafe Rush', 'Mix the drinks. Watch the queue. Keep your serving streak alive!', 'energy'),
    'code': ('Library Logic Lab', 'A scrambled mini-program. Your logic puts it back together.', 'assignments'),
}
REWARDS = {
    'memory': ('A proper little reset', 'Recover energy, ease stress and reconnect before your next quest.'),
    'route': ('Ready for a focused session', 'Build focus and earn a bonus for your next study session.'),
    'code': ('One step closer to submission', 'Earn project progress and focus by rescuing the program.'),
}
PALE_SAGE = (225, 236, 219)
PALE_PINK = (247, 225, 225)
PALE_BLUE = (222, 235, 236)


class PuzzleScreen:
    """Modal challenge with mouse and keyboard controls; never changes the world."""

    def __init__(self, kind, assets, ui, seed=0):
        if kind not in CHALLENGES:
            raise ValueError(f'Unknown challenge: {kind}')
        self.kind = kind
        self.assets = assets
        self.ui = ui
        self.seed = seed
        self.model = {'memory': MemoryPuzzle, 'route': CafePuzzle, 'code': CodePuzzle}[kind](seed=seed)
        self.cursor = 0
        self.result_selected = 0
        self.claimed = False
        self.reward_available = True
        self.time = 0.0
        self.targets = [(pygame.Rect(800, 39, 96, 34), 'cancel')]
        self._scaled = {}
        self._mono = {}

    def _image(self, surface, path, rect):
        rect = pygame.Rect(rect)
        key = (path, rect.size)
        if key not in self._scaled:
            self._scaled[key] = pygame.transform.scale(self.assets.image(path), rect.size)
        surface.blit(self._scaled[key], rect)

    def _button(self, surface, rect, label, action, selected=False, size=13):
        result = self.ui.button(surface, rect, label, selected=selected, size=size)
        self.targets.append((result, action))
        return result

    def _reset(self):
        self.model.reset()
        self.cursor = 0
        self.result_selected = 0
        self.claimed = False
        self.assets.sound('click')

    def _dispatch(self, action):
        if action == 'cancel':
            return {'action': 'cancel'}
        if action == 'claim' and self.model.complete and not self.claimed:
            self.claimed = True
            return {'action': 'complete', 'kind': self.kind,
                    'score': self.model.score, 'hints': self.model.hints}
        if self.claimed:
            return None
        if action == 'reset':
            self._reset()
        elif action == 'hint' and not self.model.complete:
            self.model.hint()
            self.assets.sound('notification')
        elif action == 'check' and not self.model.complete:
            if self.model.check():
                self.assets.sound('success')
            else:
                self.assets.sound('click')
        elif self.kind == 'route' and not self.model.complete:
            if action.startswith('ingredient:'):
                if self.model.add(int(action.split(':')[1])):
                    self.assets.sound('click')
            elif action.startswith('order:'):
                self.model.select_order(int(action.split(':')[1]))
                self.assets.sound('click')
            elif action == 'serve':
                self.assets.sound('success' if self.model.serve() else 'click')
            elif action == 'undo':
                self.model.undo()
            elif action == 'clear':
                self.model.clear()
        elif action.startswith('card:') and not self.model.complete:
            index = int(action.split(':')[1])
            self.cursor = index
            if self.model.select(index):
                self.assets.sound('success' if self.model.complete else 'click')
        return None

    def handle(self, event):
        """Return a cancel/claimed result, otherwise keep the challenge open."""
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            return {'action': 'cancel'}
        if self.claimed:
            return None
        if event.type == pygame.MOUSEMOTION:
            for rect, action in self.targets:
                if rect.collidepoint(event.pos):
                    if action.startswith('card:'):
                        self.cursor = int(action.split(':')[1])
                    elif self.model.complete and action in ('claim', 'reset', 'cancel'):
                        self.result_selected = ('claim', 'reset', 'cancel').index(action)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, action in reversed(self.targets):
                if rect.collidepoint(event.pos):
                    return self._dispatch(action)
        if event.type != pygame.KEYDOWN:
            return None
        key = event.key
        if key == pygame.K_r:
            self._reset()
            return None
        if self.model.complete:
            if key in (pygame.K_LEFT, pygame.K_UP):
                self.result_selected = (self.result_selected - 1) % 3
            elif key in (pygame.K_RIGHT, pygame.K_DOWN):
                self.result_selected = (self.result_selected + 1) % 3
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                return self._dispatch(('claim', 'reset', 'cancel')[self.result_selected])
            return None
        if key == pygame.K_h:
            return self._dispatch('hint')
        if self.kind == 'route':
            if key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
                return self._dispatch(f'ingredient:{key - pygame.K_1}')
            if key in (pygame.K_LEFT, pygame.K_RIGHT):
                step = -1 if key == pygame.K_LEFT else 1
                self.model.select_order((self.model.selected + step) % len(self.model.queue))
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                return self._dispatch('serve')
            elif key == pygame.K_BACKSPACE:
                return self._dispatch('undo')
            elif key in (pygame.K_DELETE, pygame.K_c):
                return self._dispatch('clear')
        elif self.kind == 'memory':
            if key == pygame.K_LEFT:
                self.cursor = (self.cursor // 4) * 4 + (self.cursor - 1) % 4
            elif key == pygame.K_RIGHT:
                self.cursor = (self.cursor // 4) * 4 + (self.cursor + 1) % 4
            elif key == pygame.K_UP:
                self.cursor = (self.cursor - 4) % 16
            elif key == pygame.K_DOWN:
                self.cursor = (self.cursor + 4) % 16
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                return self._dispatch(f'card:{self.cursor}')
        else:
            if key in (pygame.K_UP, pygame.K_w):
                self.cursor = (self.cursor - 1) % len(self.model.lines)
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.cursor = (self.cursor + 1) % len(self.model.lines)
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                return self._dispatch(f'card:{self.cursor}')
            elif key == pygame.K_c:
                return self._dispatch('check')
        return None

    def update(self, dt):
        self.time += dt
        was_complete = self.model.complete
        if not self.claimed:
            self.model.update(dt)
        if self.model.complete and not was_complete:
            self.assets.sound('success')

    def _metric(self, surface, x, y, value, caption, icon):
        self.ui.panel(surface, (x, y, 132, 57), button=True)
        self.ui.icon(surface, icon, (x + 10, y + 14), 24)
        self.ui.text(surface, value, (x + 43, y + 7), 19, INK, True)
        self.ui.text(surface, caption.upper(), (x + 43, y + 32), 9, MUTED, True)

    def _side_heading(self, surface, heading, subtitle):
        self.ui.panel(surface, (582, 117, 314, 329))
        self.ui.text(surface, 'YOUR CHALLENGE', (601, 132), 10, PINK, True)
        self.ui.text(surface, heading, (601, 151), 20, INK, True)
        self.ui.text(surface, subtitle, (601, 179), 12, MUTED)

    def _side_actions(self, surface, y=399):
        self._button(surface, (601, y, 132, 30), 'H  /  Hint', 'hint')
        self._button(surface, (744, y, 132, 30), 'R  /  Restart', 'reset')

    def _footer(self, surface, text):
        pygame.draw.line(surface, (222, 209, 197), (65, 459), (895, 459))
        self.ui.text(surface, text, (65, 473), 11, MUTED)
        seconds = int(self.model.elapsed)
        self.ui.icon(surface, 'clock', (813, 470), 18)
        self.ui.text(surface, f'{seconds // 60}:{seconds % 60:02d}', (838, 472), 12, MUTED, True)

    def _draw_memory(self, surface):
        model = self.model
        preview = model.preview_remaining > 0
        label = 'LOOK CLOSELY - REMEMBER THE BOARD' if preview else 'TURN TWO CARDS. FIND THEIR MATCH.'
        self.ui.text(surface, label, (76, 117), 10, PINK, True)
        for index, name in enumerate(model.cards):
            row, col = divmod(index, 4)
            rect = pygame.Rect(76 + col * 120, 139 + row * 75, 108, 65)
            matched = index in model.matched
            visible = matched or preview or index in model.revealed
            self.ui.panel(surface, rect, selected=not visible, button=True)
            if visible:
                if matched:
                    pygame.draw.rect(surface, PALE_SAGE, rect.inflate(-10, -10), border_radius=5)
                self.ui.icon(surface, name, (rect.centerx - 19, rect.y + 8), 38)
                self.ui.text(surface, name.title(), (rect.centerx, rect.bottom - 12), 10,
                             SAGE if matched else INK, True, True)
                if matched:
                    self.ui.text(surface, '+', (rect.right - 16, rect.y + 5), 14, SAGE, True)
            else:
                self.ui.icon(surface, 'inventory', (rect.centerx - 16, rect.y + 10), 32)
                self.ui.text(surface, 'CAMPUS QUEST', (rect.centerx, rect.bottom - 13), 8, CREAM, True, True)
            if index == self.cursor:
                pygame.draw.rect(surface, GOLD, rect.inflate(4, 4), 3, border_radius=8)
            self.targets.append((rect, f'card:{index}'))
        self._side_heading(surface, 'Find all 8 pairs', 'A little play. A little breathing room.')
        self._metric(surface, 601, 206, f'{len(model.matched) // 2} / 8', 'pairs found', 'star')
        self._metric(surface, 744, 206, str(model.moves), 'turns taken', 'clock')
        self.ui.bar(surface, (602, 279, 273, 9), len(model.matched), SAGE, maximum=16)
        instructions = ('The opening preview gives you a head start.\n'
                        'Flip two cards at a time to find a pair.\n'
                        'Fewer turns and hints earn more stars.')
        self.ui.paragraph(surface, instructions, (602, 303), 270, 13, gap=5)
        if preview:
            self.ui.text(surface, f'Preview: {model.preview_remaining:.1f}s', (602, 373), 12, PINK, True)
        else:
            self.ui.text(surface, f'Hints used: {model.hints}  |  H reveals the board', (602, 373), 11, MUTED)
        self._side_actions(surface)
        self._footer(surface, 'ARROWS  Move cursor     ENTER  Turn card     H  Hint     R  Restart     ESC  Leave')

    def _draw_cafe(self, surface):
        model = self.model
        colours = [(116, 76, 53), (244, 224, 191), (164, 104, 74), (174, 216, 228)]
        self.ui.text(surface, 'CHOOSE A TICKET. MIX ITS RECIPE. SERVE WITH A SMILE.',
                     (76, 117), 10, PINK, True)
        for index, order in enumerate(model.queue):
            rect = pygame.Rect(76 + index * 162, 140, 150, 120)
            self.ui.panel(surface, rect, button=True)
            if index == model.selected:
                pygame.draw.rect(surface, GOLD, rect.inflate(4, 4), 3, border_radius=7)
            self._image(surface, 'portraits/' + order['portrait'] + '.png',
                        (rect.x + 9, rect.y + 9, 30, 30))
            self.ui.text(surface, order['name'], (rect.x + 47, rect.y + 12), 14, INK, True)
            self.ui.text(surface, order['drink'], (rect.x + 10, rect.y + 45), 13, INK, True)
            recipe = model.recipes[order['drink']]
            for slot, ingredient in enumerate(recipe):
                chip = pygame.Rect(rect.x + 10 + slot * 44, rect.y + 69, 40, 21)
                pygame.draw.rect(surface, colours[ingredient], chip, border_radius=4)
                self.ui.text(surface, model.ingredients[ingredient], chip.center, 9,
                             CREAM if ingredient in (0, 2) else INK, True, True)
            remaining = order['patience']
            tint = SAGE if remaining > 20 else GOLD if remaining > 10 else PINK
            self.ui.bar(surface, (rect.x + 10, rect.y + 100, 104, 6), remaining,
                        tint, maximum=model.patience_limit)
            self.ui.text(surface, str(max(1, int(remaining)))+'s',
                         (rect.right - 31, rect.y + 96), 10, MUTED)
            self.targets.append((rect, f'order:{index}'))

        self.ui.panel(surface, (76, 281, 474, 165))
        self.ui.text(surface, 'YOUR CUP', (91, 292), 10, PINK, True)
        # Ingredient layers show exactly what is in the cup; this is puzzle state.
        cup = pygame.Rect(103, 320, 70, 68)
        pygame.draw.ellipse(surface, INK, (160, 330, 29, 38), 4)
        pygame.draw.rect(surface, (252, 244, 224), cup, border_radius=9)
        for index, ingredient in enumerate(model.cup):
            layer = pygame.Rect(cup.x + 5, cup.bottom - 8 - (index + 1) * 17, cup.w - 10, 16)
            pygame.draw.rect(surface, colours[ingredient], layer, border_radius=3)
        pygame.draw.rect(surface, INK, cup, 3, border_radius=9)
        self.ui.text(surface, f'{len(model.cup)} / 3 ingredients', (138, 393), 10, MUTED, False, True)
        self.ui.text(surface, 'INGREDIENTS / PRESS 1-4 OR CLICK', (213, 293), 9, MUTED, True)
        for index, name in enumerate(model.ingredients):
            rect = pygame.Rect(212 + (index % 2) * 166, 315 + (index // 2) * 43, 158, 35)
            self._button(surface, rect, f'{index + 1}  {name}', f'ingredient:{index}', size=13)
            pygame.draw.circle(surface, colours[index], (rect.right - 15, rect.centery), 6)
        self._button(surface, (90, 410, 210, 26), 'SPACE  /  Serve selected', 'serve', selected=True, size=12)
        self._button(surface, (310, 410, 99, 26), 'Undo', 'undo', size=12)
        self._button(surface, (419, 410, 116, 26), 'Clear cup', 'clear', size=12)
        self._side_heading(surface, 'Six cups. One rush.', 'A practice shift at Petal & Bean.')
        self._metric(surface, 601, 206, f'{model.served} / 6', 'served', 'social')
        self._metric(surface, 744, 206, str(model.streak), 'streak', 'star')
        self.ui.paragraph(surface, 'Recipes stay on the tickets. Quantities matter; pouring order does not. Pick any ticket and serve its three-ingredient recipe.',
                          (602, 280), 271, 12, gap=3)
        self.ui.paragraph(surface, model.feedback, (602, 350), 271, 12,
                          PINK if model.mistakes or model.late else MUTED, gap=3, max_lines=3)
        self._side_actions(surface)
        self._footer(surface, '1-4  Add    LEFT/RIGHT  Ticket    SPACE  Serve    BACKSPACE  Undo    H  Help    ESC  Leave')

    def _code_font(self, size=14):
        if size not in self._mono:
            choices = [Path('/System/Library/Fonts/Menlo.ttc'),
                       Path('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'),
                       Path('C:/Windows/Fonts/consola.ttf')]
            found = next((path for path in choices if path.is_file()), None)
            self._mono[size] = pygame.font.Font(str(found) if found else None, size)
        return self._mono[size]

    def _draw_code(self, surface):
        model = self.model
        self.ui.text(surface, f'RESCUE {model.round_index + 1} OF 3', (76, 117), 10, PINK, True)
        self.ui.paragraph(surface, model.prompt, (76, 138), 470, 14, gap=3, max_lines=2)
        n = len(model.lines)
        height = min(43, 248 // max(1, n))
        gap = 6
        start_y = 188
        for index, line in enumerate(model.lines):
            rect = pygame.Rect(76, start_y + index * height, 470, height - gap)
            selected = index == model.selected
            self.ui.panel(surface, rect, selected=selected, button=True)
            if index == self.cursor:
                pygame.draw.rect(surface, GOLD, rect.inflate(4, 4), 2, border_radius=6)
            self.ui.text(surface, f'{index + 1:02}', (87, rect.y + 10), 10, CREAM if selected else MUTED, True)
            font = self._code_font()
            # Keep significant indentation: these are ordered cards, not an editor.
            image = font.render(line, True, CREAM if selected else INK)
            # Fit glyphs by font size instead of blurring a stretched text image.
            size = 14
            while image.get_width() > 410 and size > 10:
                size -= 1
                image = self._code_font(size).render(line, True, CREAM if selected else INK)
            surface.blit(image, (118, rect.centery - image.get_height() // 2))
            self.targets.append((rect, f'card:{index}'))
        self._side_heading(surface, 'Put logic in order', 'Select two cards to swap their places.')
        self._metric(surface, 601, 206, f'{model.round_index + 1} / 3', 'mini-program', 'assignments')
        self._metric(surface, 744, 206, str(model.moves), 'swaps made', 'focus')
        self.ui.paragraph(surface, '1  Select a line.\n2  Select another line to swap.\n3  Check the order when ready.',
                          (603, 281), 272, 13, gap=5)
        feedback = model.feedback or 'Indentation belongs to each card.'
        self.ui.paragraph(surface, feedback, (603, 354), 272, 12,
                          PINK if model.feedback else MUTED, gap=3, max_lines=2)
        self._button(surface, (601, 399, 132, 30), 'C  /  Check order', 'check', selected=True, size=12)
        self._button(surface, (744, 399, 132, 30), 'H  /  Hint', 'hint')
        self._footer(surface, 'UP / DOWN  Move     ENTER  Select / swap     C  Check     H  Hint     R  Restart     ESC  Leave')

    def _draw_complete(self, surface):
        model = self.model
        self.ui.panel(surface, (194, 118, 572, 325))
        self.ui.text(surface, 'CHALLENGE COMPLETE', (480, 140), 11, PINK, True, True)
        for index in range(3):
            x = 418 + index * 45
            if index < model.score:
                self.ui.icon(surface, 'star', (x, 164), 36)
            else:
                ghost = pygame.Surface((36, 36), pygame.SRCALPHA)
                self.ui.icon(ghost, 'star', (0, 0), 36)
                ghost.set_alpha(65)
                surface.blit(ghost, (x, 164))
        heading, reward = REWARDS[self.kind]
        if not self.reward_available:
            heading = 'A little practice, a personal best'
            reward = 'Today\'s reward is collected. Save your record; rewards return on a later story day.'
        self.ui.text(surface, heading, (480, 226), 24, INK, True, True)
        self.ui.paragraph(surface, reward, (250, 252), 460, 15, gap=4)
        seconds = int(model.elapsed)
        summary = f'{model.moves} {"turns" if self.kind == "memory" else "serves" if self.kind == "route" else "swaps"}'
        self.ui.text(surface, f'{summary}    /    {model.hints} hints    /    {seconds // 60}:{seconds % 60:02d}',
                     (480, 317), 12, MUTED, False, True)
        claim_label = 'CLAIM REWARD  +  RETURN TO CAMPUS' if self.reward_available else 'SAVE RESULT  +  RETURN TO CAMPUS'
        self._button(surface, (286, 345, 388, 41), claim_label, 'claim',
                     selected=self.result_selected == 0, size=14)
        self._button(surface, (286, 395, 187, 30), 'R  /  Replay', 'reset',
                     selected=self.result_selected == 1, size=12)
        self._button(surface, (487, 395, 187, 30), 'Leave without reward', 'cancel',
                     selected=self.result_selected == 2, size=12)
        self._footer(surface, 'ENTER  Claim reward     ARROWS  Choose a button     R  Replay     ESC  Leave')

    def draw(self, surface):
        """Draw over the existing campus view at the 960 x 540 internal size."""
        self.ui.dim(surface, 184)
        self.ui.panel(surface, (40, 20, 880, 500))
        self.targets = []
        title, subtitle, icon = CHALLENGES[self.kind]
        self.ui.icon(surface, icon, (65, 43), 34)
        self.ui.text(surface, title, (111, 39), 28, INK, True)
        self.ui.text(surface, subtitle, (66, 81), 14, MUTED)
        self._button(surface, (800, 39, 96, 34), 'ESC  /  Back', 'cancel', size=12)
        pygame.draw.line(surface, (222, 209, 197), (65, 107), (895, 107))
        if self.model.complete:
            self._draw_complete(surface)
        elif self.kind == 'memory':
            self._draw_memory(surface)
        elif self.kind == 'route':
            self._draw_cafe(surface)
        else:
            self._draw_code(surface)
