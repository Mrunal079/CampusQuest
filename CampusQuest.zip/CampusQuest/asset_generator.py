"""Campus Quest's original procedural pixel artwork.

All pixels are authored here with Pillow primitives; no downloaded assets, game
rips, or external art are used. Run this file to reconstruct the asset folder.
Pillow is used by the asset check/generator at launch and is listed in requirements.txt.
"""
from pathlib import Path
import json
import math
import random
import struct
import wave
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
ASSET_DIR = ROOT / 'assets'
NEAREST = Image.Resampling.NEAREST
P = dict(ink='#343d45', ink2='#565d60', cream='#fff2d5', ivory='#fffae9',
         sage='#84a48a', sage_dark='#507766', sage_light='#b6c9a4',
         rose='#dc8e9f', pink='#f0b7ba', darkpink='#b96b83',
         stone='#dbbda1', stone_light='#f1d8b6', stone_dark='#b9957e',
         roof='#647582', rooflight='#84939a', blue='#91b8bd',
         wood='#a87858', woodlight='#c8986b', gold='#e7bb67',
         grass='#9fbb8c', grass_dark='#82a67e', grass_light='#b5c99b')
FONT_DIR = Path('/System/Library/Fonts/Supplemental')

def font(size, bold=False):
    for path in [FONT_DIR / ('Courier New Bold.ttf' if bold else 'Courier New.ttf'),
                 Path('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf')]:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()

def canvas(w, h, bg=None):
    im = Image.new('RGBA', (w, h), bg or (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)

def write(path, im, force=False):
    path = ASSET_DIR / path
    path.parent.mkdir(parents=True, exist_ok=True)
    if force or not path.exists():
        im.save(path)
    return path

def txt(d, xy, s, size=7, fill=None, anchor='mm', bold=True):
    d.text(xy, s, font=font(size,bold), fill=fill or P['ink'], anchor=anchor,
           stroke_width=0)

def brick(d, rect, base=None, seed=0):
    x0,y0,x1,y1=rect
    d.rectangle(rect, fill=base or P['stone'])
    rng=random.Random(seed)
    shades=[P['stone_dark'], '#cdaa90', '#e6cbae', '#d6b397']
    for y in range(y0+1,y1,6):
        d.line((x0,y,x1,y), fill='#c3a18a')
        for x in range(x0-(7 if (y//6)%2 else 0),x1,14):
            if x>=x0:
                d.line((x,y,x,y+5),fill='#c3a18a')
            if rng.random()<.3:
                d.line((max(x+2,x0),y+2,min(x+9,x1),y+2),fill=rng.choice(shades))

def window(d,x,y,w=12,h=22,lit=True,arch=True):
    d.rectangle((x-2,y+1,x+w+2,y+h+2), fill=P['stone_dark'])
    if arch:
        d.rounded_rectangle((x-1,y-2,x+w+1,y+h+1),radius=w//2,fill=P['stone_light'])
        d.rounded_rectangle((x+1,y,x+w-1,y+h),radius=max(2,w//2-2),fill=P['ink'])
    else:
        d.rectangle((x-1,y-1,x+w+1,y+h+1),fill=P['stone_light'])
        d.rectangle((x+1,y+1,x+w-1,y+h),fill=P['ink'])
    d.rectangle((x+2,y+5,x+w-2,y+h-2),fill='#bcd5cc' if not lit else '#e9d6a1')
    d.rectangle((x+2,y+5,x+w-2,y+9),fill='#8fb0ac' if not lit else '#d4ba7e')
    d.line((x+w//2,y+2,x+w//2,y+h),fill=P['ink'],width=1)
    d.line((x+1,y+h//2+2,x+w-1,y+h//2+2),fill=P['ink'],width=1)
    d.line((x+3,y+10,x+5,y+8),fill='#fff5d7')
    d.rectangle((x-2,y+h+1,x+w+2,y+h+3),fill=P['stone_light'])

def doorway(d,x=64,y=104,color=None):
    d.rectangle((x-10,y-25,x+10,y-1),fill=P['stone_light'])
    d.rounded_rectangle((x-8,y-27,x+8,y-1),radius=7,fill=P['ink'])
    d.rectangle((x-6,y-18,x+6,y-1),fill=color or P['wood'])
    d.rectangle((x-5,y-17,x-1,y-9),fill='#9db8b3')
    d.rectangle((x+1,y-17,x+5,y-9),fill='#9db8b3')
    d.line((x,y-18,x,y-1),fill=P['ink'])
    d.point((x-2,y-6),fill=P['gold']); d.point((x+2,y-6),fill=P['gold'])
    d.rectangle((x-13,y-1,x+13,y+1),fill='#e7d2b2')
    d.rectangle((x-15,y+2,x+15,y+3),fill='#c8b198')

def building(kind):
    im,d=canvas(128,112)
    d.ellipse((6,94,122,111),fill=(44,57,50,55))
    # Wings, facade, and three-dimensional side wall.
    d.rectangle((9,43,118,102),fill=P['ink'])
    brick(d,(11,44,115,101),seed=len(kind))
    d.polygon([(108,43),(118,38),(118,98),(108,102)],fill='#b99680')
    d.rectangle((10,40,116,44),fill=P['stone_light'])
    d.rectangle((11,95,115,100),fill=P['stone_dark'])
    d.line((12,95,114,95),fill='#f1d8b6')
    # Roof has layered tiles, ridge, gutters, and dormer details.
    d.polygon([(7,40),(20,20),(105,20),(120,40)],fill=P['ink'])
    d.polygon([(10,39),(22,22),(104,22),(117,39)],fill=P['roof'])
    for y in range(25,39,4):
        d.line((20-(y-25)//2,y,106+(y-25)//2,y),fill='#566872')
        for x in range(20,110,10):
            d.line((x+(y%3),y-2,x+(y%3)-1,y),fill=P['rooflight'])
    d.rectangle((20,19,105,21),fill=P['rooflight'])
    d.line((9,40,119,40),fill=P['ink'],width=2)
    d.rectangle((24,12,30,26),fill='#b58e79'); d.rectangle((22,11,32,14),fill='#e5c8a7')
    d.rectangle((91,12,97,26),fill='#b58e79'); d.rectangle((89,11,99,14),fill='#e5c8a7')
    for x in (18,37,78,97):
        window(d,x,52,11,24,lit=(x in (37,78)))
    # Frieze and entry.
    d.rectangle((47,43,78,77),fill=P['stone_light'])
    d.rectangle((49,46,76,76),fill='#d4b59a')
    for x in (46,78):
        d.rectangle((x,78,x+3,102),fill=P['stone_light'])
        d.rectangle((x-1,76,x+4,79),fill='#f5debf')
    doorway(d)
    titles={'library':'LIBRARY','lecture_hall':'LECTURES','student_centre':'STUDENT HUB',
            'health_centre':'WELLBEING','cafe':'CAMPUS CAFE','career_hub':'CAREERS'}
    # Central identity towers differ by building.
    if kind=='library':
        d.rectangle((46,13,81,43),fill=P['ink'])
        brick(d,(48,14,79,42),seed=10)
        d.polygon([(43,15),(64,1),(85,15)],fill=P['ink'])
        d.polygon([(47,13),(64,3),(81,13)],fill=P['roof'])
        d.ellipse((55,19,72,36),fill=P['stone_light'],outline=P['stone_dark'])
        d.ellipse((58,22,69,33),fill=P['cream'],outline=P['ink'])
        d.line((64,24,64,28,67,30),fill=P['ink'])
        d.rectangle((54,55,72,68),fill=P['sage_dark'])
        d.line((63,57,63,66),fill=P['cream'])
        d.line((56,59,61,60,61,65,56,64,56,59),fill=P['cream'])
        d.line((65,60,70,59,70,64,65,65),fill=P['cream'])
    elif kind=='lecture_hall':
        d.polygon([(41,43),(64,29),(87,43)],fill=P['stone_light'],outline=P['ink'])
        d.polygon([(49,41),(64,33),(79,41)],fill='#d2b396')
        for x in (49,75):
            d.rectangle((x,46,x+3,73),fill=P['stone_light'])
        d.rectangle((54,50,73,64),fill=P['sage_dark'])
        d.polygon([(53,52),(64,47),(75,52),(64,57)],fill=P['gold'])
        d.line((74,53,74,60),fill=P['gold'])
    elif kind=='student_centre':
        d.rectangle((47,19,80,39),fill=P['stone_light'],outline=P['ink'])
        d.rectangle((50,22,77,36),fill=P['sage'])
        for x,col in [(56,P['pink']),(64,P['cream']),(72,P['gold'])]:
            d.ellipse((x-2,25,x+2,29),fill=col)
            d.rectangle((x-3,30,x+3,34),fill=col)
        for x in (18,98):
            d.rectangle((x,79,x+11,92),fill=P['rose'])
            txt(d,(x+6,85),'U',8,P['cream'])
    elif kind=='health_centre':
        d.rectangle((49,17,78,39),fill=P['ivory'],outline=P['stone_dark'])
        d.rectangle((60,21,67,35),fill=P['sage_dark'])
        d.rectangle((56,25,71,31),fill=P['sage_dark'])
        for x in (16,98):
            d.rectangle((x,81,x+14,89),fill=P['sage'])
            d.line((x+2,85,x+5,85,x+6,82,x+8,88,x+10,84,x+12,85),fill=P['ivory'])
    elif kind=='cafe':
        # Striped awning and flower boxes.
        d.rectangle((8,44,119,46),fill=P['ink'])
        for x in range(10,116,8):
            col=P['sage'] if (x//8)%2 else P['cream']
            d.polygon([(x,46),(x+7,46),(x+9,54),(x-2,54)],fill=col)
            d.rectangle((x-2,54,x+9,57),fill=col)
        d.rectangle((47,58,78,72),fill=P['cream'],outline=P['wood'])
        d.rectangle((57,60,67,66),fill=P['wood'])
        d.arc((64,60,71,66),270,90,fill=P['wood'],width=2)
        d.line((55,68,69,68),fill=P['wood'])
        for x in (18,96):
            d.rectangle((x,83,x+15,89),fill=P['wood'])
            for fx in range(x+2,x+15,4):
                d.ellipse((fx,79,fx+3,83),fill=P['pink'])
                d.point((fx+1,80),fill=P['gold'])
    elif kind=='career_hub':
        d.rectangle((50,17,77,39),fill=P['stone_light'],outline=P['ink'])
        d.rectangle((56,24,71,34),fill=P['sage_dark'])
        d.rectangle((60,21,67,25),outline=P['sage_dark'],width=2)
        d.line((56,28,71,28),fill=P['gold'])
        for x in (17,98):
            d.rectangle((x,80,x+13,91),fill=P['roof'])
            d.line((x+3,87,x+6,83,x+9,87),fill=P['cream'])
    # Main sign, wall lanterns, ivy and planting.
    d.rectangle((39,70,88,77),fill=P['sage_dark'],outline=P['ink'])
    txt(d,(64,73.5),titles[kind],5,P['cream'])
    for x in (37,89):
        d.line((x,82,x,87),fill=P['ink'])
        d.rectangle((x-2,84,x+2,89),fill=P['gold'],outline=P['ink'])
    for x,y in [(12,66),(11,74),(13,82),(113,73),(114,82),(111,90)]:
        d.line((x,y,x+2,y+9),fill=P['sage_dark'])
        d.ellipse((x-2,y-1,x+2,y+2),fill=P['sage'])
        d.ellipse((x+1,y+3,x+5,y+6),fill=P['sage_dark'])
    for x in (20,103):
        d.rectangle((x-5,97,x+5,103),fill=P['wood'])
        d.ellipse((x-5,91,x+5,98),fill=P['sage_dark'])
        d.ellipse((x-3,89,x+3,96),fill=P['sage'])
    im = im.resize((256,224),NEAREST)
    building_nameplate(im, kind)
    return im


def building_nameplate(image, kind):
    """Draw readable signs at final resolution, not as enlarged 5px lettering."""
    names = {
        'library': ['Main Library'],
        'lecture_hall': ['Lecture Theatre'],
        'student_centre': ['Student Centre'],
        'health_centre': ['Health Centre'],
        'cafe': ['Petal & Bean Cafe'],
        'career_hub': ['Career &', 'Innovation Hub'],
    }
    lines = names[kind]
    face = font(17 if len(lines) == 1 else 15, bold=True)
    widths = [face.getbbox(line)[2] - face.getbbox(line)[0] for line in lines]
    width = max(128, max(widths) + 22)
    height = 25 if len(lines) == 1 else 37
    left = (image.width - width) // 2
    top = 162 - height
    draw = ImageDraw.Draw(image)
    # Framed sage enamel is part of the facade, with high-contrast cream text.
    draw.rectangle((left + 2, top + 2, left + width + 2, top + height + 2), fill=(35, 37, 38, 125))
    draw.rectangle((left, top, left + width, top + height), fill=P['ink'])
    draw.rectangle((left + 1, top + 1, left + width - 1, top + height - 1), fill=P['stone_light'])
    draw.rectangle((left + 3, top + 3, left + width - 3, top + height - 3), fill='#36594a')
    for row, line in enumerate(lines):
        centre_y = top + (height // 2 if len(lines) == 1 else 11 + row * 15)
        draw.text((image.width // 2, centre_y), line, font=face, fill='#fff9e8', anchor='mm')

def tiles():
    result={}
    for i in range(3):
        im,d=canvas(32,32,P['grass']);rng=random.Random(100+i)
        for j in range(31):
            x,y=rng.randrange(32),rng.randrange(32)
            d.line((x,y,x+1,y-2),fill=rng.choice([P['grass_dark'],P['grass_light'],'#a9c095']))
        if i==2:
            for x,y in [(6,9),(22,23)]:
                d.line((x,y,x,y+3),fill=P['sage_dark'])
                d.point((x,y-1),fill=P['cream']); d.point((x+1,y),fill=P['cream'])
        result['grass'+str(i)]=im
    for i in range(2):
        im,d=canvas(32,32,'#d9c7a4'); rng=random.Random(i)
        for y in range(0,32,8):
            for x in range(-8 if y%16 else 0,32,16):
                d.rectangle((x,y,x+15,y+7),fill=rng.choice(['#ddccae','#e5d5b7','#d6c3a1']),outline='#c9b795')
                d.line((x+1,y+1,x+14,y+1),fill='#ecdfc4')
        result['path'+str(i)]=im
    im,d=canvas(32,32,'#7eafb0')
    for y in (4,13,23):
        d.line((2,y,11,y,13,y-1,21,y-1),fill='#b3d2ca')
        d.line((16,y+4,27,y+4),fill='#699d9f')
    result['water']=im
    im,d=canvas(32,32,'#eadbc2')
    for x in (0,16,31):d.line((x,0,x,31),fill='#d5c3a5')
    for y in (0,16,31):d.line((0,y,31,y),fill='#d5c3a5')
    d.rectangle((2,2,14,14),outline='#f2e7d0')
    result['floor']=im
    im,d=canvas(32,32,'#b38c69')
    for y in (0,8,16,24):
        d.line((0,y,31,y),fill='#8e6b53');d.line((0,y+1,31,y+1),fill='#cda780')
        for x in (4+(y%3)*5,25):d.line((x,y+3,x+4,y+3),fill='#a47c5f')
    d.line((12,0,12,7),fill='#8e6b53'); d.line((23,16,23,23),fill='#8e6b53')
    result['wood']=im
    im,d=canvas(32,32,'#a77680')
    for x in range(0,32,4):
        for y in range(0,32,4):d.point((x,y),fill='#b88a91'); d.point((x+2,y+2),fill='#966773')
    result['carpet']=im
    im,d=canvas(32,32,'#e1cfb1')
    for y in (0,10,20,31):
        d.line((0,y,31,y),fill='#bba68d')
        for x in range((y//10%2)*8,32,16):d.line((x,y,x,y+9),fill='#bba68d')
    result['wall']=im
    return result

def prop(name):
    dims={'tree':(64,96),'cherry_tree':(80,96),'bush':(48,32),'flowers':(32,32),
          'bench':(64,32),'lamp':(32,64),'fountain':(96,64),'sign':(32,48),'bike_rack':(64,32),
          'noticeboard':(64,64),'stall':(96,80),'table':(64,48),'rocks':(32,32),'bin':(32,32),'banner':(32,64)}
    w,h=dims[name]; im,d=canvas(w//2,h//2);w//=2;h//=2
    d.ellipse((2,h-6,w-2,h-1),fill=(44,57,50,55))
    if name in ('tree','cherry_tree'):
        d.polygon([(w//2-3,h-5),(w//2-3,19),(w//2+3,19),(w//2+4,h-5)],fill='#715845')
        d.line((w//2,h-8,w//2,19),fill='#ac8560',width=2)
        d.line((w//2,29,w//2-7,22),fill='#715845',width=3)
        cols=['#486f60','#64886a','#87a77b','#a1ba88'] if name=='tree' else ['#b9758e','#d991a6','#eeb2bf','#f7d0d0']
        for x,y,r,c in [(w//2,17,15,0),(w//2-8,17,10,1),(w//2+8,19,10,1),(w//2,9,10,2),(w//2-5,9,8,2),(w//2+5,9,7,3)]:
            d.ellipse((max(0,x-r),max(0,y-r),min(w-1,x+r),y+r),fill=cols[c])
        rng=random.Random(3)
        for i in range(65):
            x=rng.randrange(3,w-3);y=rng.randrange(4,29)
            if im.getpixel((x,y))[3]:d.rectangle((x,y,x+1,y+1),fill=cols[rng.choice([1,2,3])])
    elif name=='bush':
        for x,y in [(6,9),(13,7),(20,10)]:
            d.ellipse((x-6,y-5,x+6,y+5),fill=P['sage_dark'])
            d.ellipse((x-4,y-5,x+3,y+1),fill=P['sage'])
        for x in (5,12,19):d.rectangle((x,6,x+1,7),fill=P['sage_light'])
    elif name=='flowers':
        d.rectangle((2,12,14,15),fill=P['wood'])
        for x,y in [(4,6),(8,4),(12,7),(6,9)]:
            d.line((x,y,x,12),fill=P['sage_dark'])
            d.ellipse((x-2,y-2,x+2,y+2),fill=P['pink'] if x%3 else P['gold'])
            d.point((x,y),fill=P['cream'])
    elif name=='bench':
        for y in (3,7,11):d.rectangle((2,y,29,y+2),fill=P['woodlight'],outline=P['wood'])
        for x in (5,26):
            d.rectangle((x,9,x+1,15),fill=P['ink'])
            d.line((x-2,7,x-2,12,x+3,12),fill=P['ink'])
    elif name=='lamp':
        d.rectangle((7,11,8,30),fill=P['ink'])
        d.rectangle((5,29,10,31),fill=P['ink2'])
        d.rectangle((4,4,11,11),fill=P['gold'],outline=P['ink'])
        d.polygon([(3,4),(7,1),(12,4)],fill=P['ink'])
        d.line((7,5,7,10),fill=P['cream'])
        d.rectangle((6,12,9,13),fill=P['ink'])
    elif name=='fountain':
        d.ellipse((2,10,45,30),fill=P['ink2'])
        d.ellipse((3,9,44,27),fill=P['stone_light'],outline=P['stone_dark'])
        d.ellipse((7,12,40,24),fill='#83b4b7')
        d.ellipse((11,14,36,22),outline='#c8e0d1')
        d.rectangle((21,8,26,20),fill=P['stone_dark'])
        d.ellipse((15,5,32,12),fill=P['stone_light'],outline=P['stone_dark'])
        d.line((24,1,24,8),fill='#d2eadb',width=2)
        d.arc((13,1,24,18),180,270,fill='#b6dcd5')
        d.arc((24,1,36,18),270,360,fill='#b6dcd5')
    elif name=='sign':
        d.rectangle((7,6,9,23),fill=P['wood'])
        d.rectangle((1,3,14,12),fill=P['sage_dark'],outline=P['cream'])
        d.line((4,7,11,7,9,5),fill=P['cream']);d.line((9,9,11,7),fill=P['cream'])
    elif name=='bike_rack':
        for x in (2,12,22):d.arc((x,3,x+8,14),180,360,fill=P['ink2'],width=2)
        d.line((2,8,2,14),fill=P['ink2'],width=2);d.line((30,8,30,14),fill=P['ink2'],width=2)
        d.ellipse((8,7,15,14),outline=P['roof']); d.ellipse((20,7,27,14),outline=P['roof'])
        d.line((12,11,17,5,23,11,12,11,15,6),fill=P['rose'])
    elif name=='noticeboard':
        d.rectangle((4,5,6,30),fill=P['wood']); d.rectangle((25,5,27,30),fill=P['wood'])
        d.rectangle((1,3,30,24),fill=P['woodlight'],outline=P['ink'])
        d.rectangle((3,5,28,22),fill='#c5ab83')
        for x,y,c in [(5,7,P['cream']),(15,6,P['pink']),(19,14,'#b2c7ad'),(6,15,'#d3dbcf')]:
            d.rectangle((x,y,x+6,y+7),fill=c);d.point((x+3,y+1),fill=P['rose'])
            d.line((x+1,y+3,x+5,y+3),fill=P['ink2'])
    elif name=='stall':
        d.rectangle((5,12,7,37),fill=P['wood']);d.rectangle((40,12,42,37),fill=P['wood'])
        d.rectangle((4,25,43,37),fill=P['woodlight'],outline=P['wood'])
        d.rectangle((2,22,45,26),fill=P['cream'],outline=P['wood'])
        d.polygon([(1,12),(9,2),(38,2),(46,12)],fill=P['sage_dark'])
        for x in range(2,45,8):
            d.polygon([(x+4,3),(x+9,3),(x+12,12),(x+4,12)],fill=P['cream'])
        d.rectangle((1,12,46,15),fill=P['sage_dark'])
        for x,c in [(11,P['pink']),(21,P['gold']),(31,P['sage'])]:
            d.rectangle((x,19,x+5,22),fill=c)
        txt(d,(24,31),'CLUBS',6,P['cream'])
    elif name=='table':
        d.rectangle((7,13,10,22),fill=P['wood']);d.rectangle((23,13,26,22),fill=P['wood'])
        d.ellipse((2,3,30,17),fill=P['wood'],outline=P['ink2'])
        d.ellipse((2,2,30,14),fill=P['woodlight'])
        d.rectangle((11,5,17,9),fill=P['cream'])
        d.rectangle((19,5,22,8),fill=P['ivory']);d.point((20,5),fill=P['wood'])
    elif name=='rocks':
        d.polygon([(1,13),(4,7),(10,6),(14,12),(13,15),(3,15)],fill='#8e9a92',outline='#64746c')
        d.line((4,8,9,7,11,10),fill='#bec6b5')
    elif name=='bin':
        d.rectangle((4,5,12,14),fill=P['sage_dark'],outline=P['ink2'])
        d.rectangle((3,3,13,5),fill=P['sage'])
        for x in (6,10):d.line((x,7,x,12),fill=P['sage'])
    elif name=='banner':
        d.rectangle((2,1,3,31),fill=P['ink2'])
        d.polygon([(4,3),(14,3),(14,22),(9,19),(4,22)],fill=P['rose'])
        d.line((5,5,13,5),fill=P['pink']);txt(d,(9,11),'Q',9,P['cream'])
    return im.resize((w*2,h*2),NEAREST)

def furniture(name):
    dims={'bookshelf':(64,64),'desk':(64,48),'computer':(32,32),'reception':(96,48),'chair':(32,32),
          'sofa':(64,48),'plant':(32,48),'projector':(32,32),'board':(96,64),'coffee_counter':(96,64),
          'poster':(32,48),'showcase':(64,64),'printer':(32,32),'exit_door':(64,64)}
    w,h=dims[name]; im,d=canvas(w//2,h//2);w//=2;h//=2
    if name=='bookshelf':
        d.rectangle((1,1,30,30),fill=P['wood'],outline=P['ink2'])
        for y in (4,15):
            d.rectangle((3,y,28,y+9),fill='#705545')
            rng=random.Random(y)
            for x in range(4,28,3):
                hei=rng.randrange(5,9);col=rng.choice([P['sage'],P['rose'],P['blue'],P['gold'],'#e8d4b3'])
                d.rectangle((x,y+9-hei,x+1,y+8),fill=col);d.point((x,y+7),fill=P['cream'])
        d.rectangle((0,0,31,2),fill=P['woodlight'])
    elif name in ('desk','reception','coffee_counter'):
        d.rectangle((2,h//2,w-3,h-2),fill=P['wood'],outline=P['ink2'])
        d.rectangle((1,h//2-4,w-2,h//2+2),fill=P['woodlight'],outline=P['wood'])
        d.line((3,h//2-3,w-4,h//2-3),fill=P['stone_light'])
        if name=='desk':
            d.rectangle((6,5,15,9),fill=P['cream']);d.line((7,7,13,7),fill=P['blue'])
            d.rectangle((23,4,26,9),fill=P['sage_dark']);d.point((24,3),fill=P['rose'])
            d.rectangle((7,16,23,20),outline='#8b624d')
        elif name=='reception':
            d.rectangle((31,2,43,10),fill=P['ink']);d.rectangle((32,3,42,8),fill=P['blue'])
            d.rectangle((36,10,39,12),fill=P['ink2'])
            d.rectangle((8,9,21,11),fill=P['cream']);txt(d,(14,19),'i',8,P['cream'])
            d.rectangle((22,7,27,11),fill=P['woodlight'])
            d.line((24,8,24,3),fill=P['sage_dark'])
            d.ellipse((21,1,25,5),fill=P['sage'])
            d.ellipse((24,2,28,6),fill=P['sage_light'])
            d.line((5,18,8,18),fill=P['gold'])
        else:
            d.rectangle((5,3,19,11),fill=P['ink2']);d.rectangle((7,4,16,8),fill=P['rooflight'])
            d.rectangle((23,7,28,12),fill=P['ivory']);d.arc((27,8,31,12),270,90,fill=P['ivory'])
            d.line((24,6,25,4,24,2),fill='#d9ccb5')
            d.rectangle((7,9,10,12),fill=P['ivory'])
            d.rectangle((12,9,15,12),fill=P['ivory'])
            d.line((17,5,17,9),fill=P['gold'])
            d.rectangle((34,6,42,11),fill=P['gold']); d.line((35,7,40,7),fill=P['wood'])
            txt(d,(24,25),'COFFEE',6,P['cream'])
    elif name=='computer':
        d.rectangle((2,1,13,10),fill=P['ink']);d.rectangle((3,2,12,8),fill=P['blue'])
        d.line((4,3,8,3),fill='#d8ece1');d.line((4,5,10,5),fill=P['cream'])
        d.rectangle((7,10,9,12),fill=P['ink2']);d.rectangle((4,12,12,13),fill=P['ink'])
        d.rectangle((1,14,14,15),fill=P['ink2'])
    elif name=='chair':
        d.rectangle((4,9,5,15),fill=P['wood']);d.rectangle((11,9,12,15),fill=P['wood'])
        d.rounded_rectangle((3,1,12,8),radius=2,fill=P['sage_dark'],outline=P['ink2'])
        d.rectangle((3,8,13,11),fill=P['sage']);d.line((5,3,10,3),fill=P['sage_light'])
    elif name=='sofa':
        d.rounded_rectangle((1,4,30,20),radius=3,fill=P['sage_dark'],outline=P['ink2'])
        d.rectangle((5,5,26,12),fill=P['sage']);d.line((16,6,16,16),fill=P['sage_dark'])
        d.rectangle((4,13,27,17),fill=P['sage_light']);d.rectangle((2,10,5,19),fill=P['sage'])
        d.rectangle((27,10,30,19),fill=P['sage']);d.rectangle((4,21,6,23),fill=P['wood'])
        d.rectangle((25,21,27,23),fill=P['wood']);d.rectangle((7,8,12,12),fill=P['pink'])
        d.line((8,8,11,11),fill='#f8d0cc')
        d.rectangle((20,8,25,12),fill='#e6d7b7')
        d.point((22,10),fill=P['gold'])
        d.line((8,16,13,16),fill='#c4d2b4')
    elif name=='plant':
        d.polygon([(4,16),(12,16),(11,23),(5,23)],fill=P['woodlight'],outline=P['wood'])
        for x,y in [(3,6),(9,2),(11,9),(5,11)]:
            d.line((8,17,x+2,y+2),fill=P['sage_dark'])
            d.ellipse((x,y,x+4,y+6),fill=P['sage'])
        d.line((8,4,8,17),fill=P['sage_dark'])
    elif name=='projector':
        d.rectangle((2,5,13,11),fill=P['cream'],outline=P['ink2'])
        d.ellipse((9,7,12,10),fill=P['blue'],outline=P['ink'])
        for x in (4,6):d.line((x,7,x,9),fill=P['roof'])
    elif name=='board':
        d.rectangle((3,1,44,25),fill=P['wood'],outline=P['ink2'])
        d.rectangle((5,3,42,22),fill=P['sage_dark'])
        txt(d,(24,8),'TODAY',6,P['cream'])
        for y in (13,17):d.line((9,y,35-y//3,y),fill=P['cream'])
        d.rectangle((2,24,45,26),fill=P['woodlight']);d.rectangle((6,27,8,31),fill=P['wood'])
        d.rectangle((39,27,41,31),fill=P['wood'])
    elif name=='poster':
        d.rectangle((2,1,13,22),fill=P['woodlight'],outline=P['ink2'])
        d.rectangle((3,2,12,21),fill=P['cream']);d.rectangle((4,4,11,11),fill=P['rose'])
        d.polygon([(5,10),(8,5),(11,10)],fill=P['gold'])
        for y in (14,17,19):d.line((5,y,10,y),fill=P['sage_dark'])
    elif name=='showcase':
        d.rectangle((2,3,29,26),fill=P['wood'],outline=P['ink2'])
        d.rectangle((4,5,27,23),fill=P['blue'])
        d.line((5,7,13,7),fill='#d2e3d6');d.line((16,5,16,23),fill=P['cream'])
        d.rectangle((9,17,22,20),fill=P['woodlight']);d.polygon([(13,17),(14,10),(18,10),(19,17)],fill=P['gold'])
        d.arc((10,9,21,15),0,180,fill=P['gold'],width=2)
    elif name=='printer':
        d.rectangle((4,1,12,7),fill=P['cream'],outline=P['ink2'])
        d.rectangle((1,5,14,12),fill=P['rooflight'],outline=P['ink2'])
        d.rectangle((4,10,12,15),fill=P['ivory']);d.line((5,12,10,12),fill=P['blue'])
        d.point((11,7),fill=P['sage_light'])
    elif name=='exit_door':
        d.rectangle((5,1,26,31),fill=P['stone_dark'],outline=P['ink'])
        d.rectangle((7,3,24,31),fill=P['wood']);d.rectangle((9,5,22,19),fill=P['blue'])
        d.line((10,6,21,6),fill='#d4e3d8');d.rectangle((8,23,23,30),outline='#855d4a')
        d.point((22,22),fill=P['gold']);d.rectangle((9,0,22,4),fill=P['sage_dark'])
        txt(d,(16,2),'EXIT',4,P['cream'])
    return im.resize((w*2,h*2),NEAREST)

PEOPLE = {
 'student':('#e4a18f','#513b36','#a15d74','#f2c8bf','#5b627c'),
 'maya':('#bd8268','#382f31','#718f75','#ddd6af','#5a6671'),
 'leo':('#e1b18c','#765b3f','#c99564','#f0dfc6','#586d77'),
 'nina':('#f0c3ac','#3c3940','#91a2b8','#f3e1cf','#72596f'),
 'tutor':('#d4a17e','#4a4542','#6f8390','#ece1c9','#5a5d6a'),
 'librarian':('#e3b8a0','#8b8a83','#a27b8b','#f2e6ce','#5c5b6c'),
 'receptionist':('#b47b61','#3d3431','#7c9b8c','#ede4d1','#666477'),
 'support':('#dfb79b','#805d49','#b69bb2','#f3dfca','#5b6773'),
 'adviser':('#c99778','#51413a','#879fa0','#e7dbbd','#5e686b'),
 'barista':('#d6a585','#4b3830','#b78c6b','#dfc99e','#5d655a'),
 'student1':('#d3a17e','#544334','#90a281','#ead7b2','#6d7186'),
 'student2':('#a96f59','#302e35','#bf8398','#eac6c0','#605f7b'),
 'student3':('#eac6a7','#a77750','#8da4b4','#efe0c6','#6d637d')}

def sprite_frame(name,direction,frame):
    im,d=canvas(16,24)
    skin,hair,shirt,light,pants=PEOPLE[name]
    is_girl=name not in ('leo','tutor','adviser','student1','student3')
    walk=[0,-1,0,1][frame];bob=1 if frame in (1,3) else 0
    # Ground shadow stays fixed; silhouette changes by direction.
    d.ellipse((3,21,13,23),fill=(37,45,43,45))
    if direction in (2,3):
        face=1 if direction==3 else -1
        d.rectangle((5,15+bob,10,20),fill=pants)
        d.rectangle((5+walk,19,7+walk,22),fill=pants)
        d.rectangle((9-walk,19,11-walk,22),fill=pants)
        d.rectangle((5+walk,22,8+walk,23),fill=P['cream'])
        d.rectangle((9-walk,22,12-walk,23),fill=P['cream'])
        d.rectangle((5,10+bob,10,16+bob),fill=shirt)
        # backpack on rear side
        bx=3 if face==1 else 10
        d.rounded_rectangle((bx,11+bob,bx+3,17+bob),radius=1,fill='#b88e72',outline='#765c50')
        d.rectangle((7+face*3,12+bob,8+face*3,17+bob+walk//2),fill=skin)
        d.ellipse((4,2+bob,11,11+bob),fill=hair)
        d.rectangle((7 if face==1 else 4,5+bob,12 if face==1 else 9,10+bob),fill=skin)
        d.rectangle((12 if face==1 else 3,7+bob,12 if face==1 else 3,8+bob),fill=skin)
        d.point((10 if face==1 else 5,7+bob),fill=P['ink'])
        d.line((5,3+bob,9,3+bob),fill='#785348')
        if is_girl:d.rectangle((4 if face==1 else 10,7+bob,6 if face==1 else 12,14+bob),fill=hair)
        if name=='student':d.rectangle((5 if face==1 else 10,4+bob,6 if face==1 else 11,5+bob),fill=P['pink'])
    else:
        d.rectangle((5,15+bob,10,19),fill=pants)
        d.rectangle((5,19+walk,7,22+walk),fill=pants)
        d.rectangle((9,19-walk,11,22-walk),fill=pants)
        d.rectangle((4,22+walk,7,23+walk),fill=P['cream'])
        d.rectangle((9,22-walk,12,23-walk),fill=P['cream'])
        d.rectangle((4,11+bob,11,16+bob),fill=shirt)
        d.line((5,11+bob,10,11+bob),fill=light)
        d.rectangle((3,12+bob,4,17+bob+walk),fill=skin)
        d.rectangle((12,12+bob,13,17+bob-walk),fill=skin)
        # full back hair and bag visible while walking north
        d.rounded_rectangle((4,2+bob,11,10+bob),radius=3,fill=hair)
        if direction==0:
            d.rectangle((5,5+bob,10,10+bob),fill=skin)
            d.rectangle((5,4+bob,7,5+bob),fill=hair)
            d.point((6,7+bob),fill=P['ink']);d.point((9,7+bob),fill=P['ink'])
            d.point((6,6+bob),fill=P['cream']);d.point((9,6+bob),fill=P['cream'])
            d.line((7,10+bob,8,10+bob),fill='#ad756a')
            if is_girl:
                d.rectangle((3,5+bob,4,13+bob),fill=hair);d.rectangle((11,5+bob,12,13+bob),fill=hair)
            # backpack straps
            d.line((5,12+bob,5,15+bob),fill='#b88e72');d.line((10,12+bob,10,15+bob),fill='#b88e72')
        else:
            d.line((5,4+bob,9,4+bob),fill='#785348')
            if is_girl:d.rectangle((3,6+bob,12,12+bob),fill=hair)
            d.rounded_rectangle((5,12+bob,11,18+bob),radius=1,fill='#b88e72',outline='#765c50')
            d.rectangle((6,15+bob,10,17+bob),outline='#d4b18b')
        if name=='student':d.rectangle((10,4+bob,12,5+bob),fill=P['pink'])
        if name in ('tutor','librarian','adviser') and direction==0:
            d.rectangle((5,6+bob,7,8+bob),outline=P['ink2']);d.rectangle((9,6+bob,11,8+bob),outline=P['ink2'])
    return im.resize((32,48),NEAREST)

def spritesheet(name):
    out=Image.new('RGBA',(128,192))
    for direction in range(4):
        for frame in range(4):out.alpha_composite(sprite_frame(name,direction,frame),(frame*32,direction*48))
    return out

def portrait(name,expression='normal'):
    skin,hair,shirt,light,pants=PEOPLE[name]
    im,d=canvas(48,48)
    # soft circular backdrop, shoulder silhouette, long hair, then face.
    d.ellipse((2,2,45,45),fill='#efe2c9')
    d.ellipse((5,5,42,42),fill='#d9ded0')
    d.polygon([(5,47),(7,38),(17,33),(31,33),(41,38),(44,47)],fill=P['ink'])
    d.polygon([(7,47),(9,39),(18,35),(30,35),(39,39),(42,47)],fill=shirt)
    d.rectangle((21,28,27,37),fill=skin)
    d.polygon([(17,35),(22,38),(24,43),(26,38),(31,35),(28,34),(24,37),(20,34)],fill=light)
    d.rounded_rectangle((11,5,36,34),radius=11,fill=hair)
    girl=name not in ('leo','tutor','adviser','student1','student3')
    if girl:
        d.rectangle((10,20,15,41),fill=hair);d.rectangle((32,18,37,41),fill=hair)
        d.line((12,24,12,37),fill='#745046');d.line((35,24,35,38),fill='#745046')
    d.ellipse((15,10,33,33),fill=skin)
    # neck shadow, ear, and softly shaded cheeks.
    d.rectangle((22,32,26,34),fill='#b17c6d')
    d.ellipse((13,21,16,26),fill=skin);d.ellipse((32,21,35,26),fill=skin)
    d.rectangle((17,26,19,27),fill='#dc9c92');d.rectangle((29,26,31,27),fill='#dc9c92')
    d.polygon([(14,19),(14,12),(19,7),(30,8),(34,14),(33,22),(29,14),(27,16),(24,12),(21,17),(18,15)],fill=hair)
    d.line((16,11,21,8,28,9),fill='#78564b',width=2)
    # anime-ish expressive eyes with highlights, all original drawn pixels
    if expression=='happy':
        d.line((18,23,20,21,22,23),fill=P['ink']);d.line((27,23,29,21,31,23),fill=P['ink'])
        d.arc((22,27,27,30),0,180,fill='#985d61')
    elif expression=='tired':
        d.line((18,23,22,23),fill=P['ink']);d.line((27,23,31,23),fill=P['ink'])
        d.line((19,25,22,25),fill='#b48987');d.line((27,25,30,25),fill='#b48987')
        d.line((23,29,26,29),fill='#985d61')
    else:
        for x in (19,28):
            d.rectangle((x-1,21,x+2,24),fill='#ffefdf');d.rectangle((x,21,x+1,24),fill=P['ink'])
            d.point((x,21),fill=P['cream']);d.line((x-1,20,x+2,20),fill=hair)
        d.line((23,29,26,29),fill='#985d61');d.point((24,27),fill='#c38b77')
    if name=='student':
        d.rectangle((31,14,36,16),fill=P['pink']);d.point((33,13),fill=P['rose'])
        d.line((11,39,13,47),fill='#be9673',width=2);d.line((36,39,34,47),fill='#be9673',width=2)
    if name in ('tutor','librarian','adviser'):
        d.rectangle((17,20,23,25),outline=P['ink2']);d.rectangle((26,20,32,25),outline=P['ink2'])
        d.line((23,22,26,22),fill=P['ink2'])
    return im.resize((96,96),NEAREST)

def icon(name):
    im,d=canvas(16,16)
    c=P['cream'];green=P['sage_dark'];pink=P['rose'];ink=P['ink'];gold=P['gold']
    if name=='health':
        d.polygon([(8,13),(2,7),(2,4),(4,2),(6,2),(8,4),(10,2),(12,2),(14,4),(14,7)],fill=pink,outline=P['darkpink'])
        d.line((4,7,6,7,7,5,9,10,10,7,12,7),fill=c)
    elif name=='energy':
        d.polygon([(9,1),(3,9),(7,9),(6,15),(13,6),(9,6)],fill=gold,outline='#b68a44')
    elif name=='focus':
        for r in (6,3):d.ellipse((8-r,8-r,8+r,8+r),outline=green)
        d.line((1,8,15,8),fill=green);d.line((8,1,8,15),fill=green);d.ellipse((6,6,10,10),fill=pink)
    elif name=='stress':
        d.arc((2,3,14,14),180,360,fill=pink,width=2);d.line((8,8,11,5),fill=ink,width=2)
        for x in (3,8,13):d.point((x,3),fill=gold)
    elif name=='social':
        for x,y in [(5,5),(11,6)]:
            d.ellipse((x-2,y-3,x+2,y+1),fill=pink if x==5 else green)
            d.rounded_rectangle((x-3,y+3,x+3,y+7),2,fill=pink if x==5 else green)
    elif name=='money':
        d.ellipse((2,2,14,14),fill=gold,outline='#b68a44');txt(d,(8,8),'$',11,P['cream'])
    elif name in ('quests','assignments','document'):
        d.rectangle((3,2,12,14),fill=c,outline=ink)
        d.rectangle((6,1,10,3),fill=green)
        for y in (6,9,12):
            d.line((6,y,10,y),fill=green);d.point((4,y),fill=pink)
    elif name=='timetable':
        d.rectangle((1,3,14,14),fill=c,outline=ink);d.rectangle((1,3,14,6),fill=pink)
        d.line((4,1,4,4),fill=ink);d.line((11,1,11,4),fill=ink)
        for x,y in [(4,9),(8,9),(11,9),(4,12),(8,12)]:d.rectangle((x,y,x+1,y+1),fill=green)
    elif name=='support':
        d.rounded_rectangle((1,2,14,11),3,fill=green);d.polygon([(4,10),(4,15),(9,10)],fill=green)
        txt(d,(8,7),'?',10,c)
    elif name=='stats':
        for x,h,col in [(2,5,green),(6,9,pink),(10,12,gold)]:d.rectangle((x,14-h,x+2,14),fill=col)
    elif name=='map':
        d.polygon([(1,3),(5,1),(10,3),(14,1),(14,13),(10,15),(5,13),(1,15)],fill=P['sage_light'],outline=green)
        d.line((5,2,5,12),fill=c);d.line((10,4,10,14),fill=c)
        d.ellipse((6,5,11,10),fill=pink);d.polygon([(7,9),(9,12),(11,8)],fill=pink)
    elif name=='messages':
        d.rectangle((1,3,14,13),fill=c,outline=green);d.line((1,3,8,9,14,3),fill=green)
        d.ellipse((10,0,15,5),fill=pink)
    elif name=='inventory':
        d.rounded_rectangle((3,4,13,15),3,fill=gold,outline=P['wood'])
        d.arc((5,1,11,7),180,360,fill=P['wood'],width=2)
        d.rectangle((5,9,11,13),outline=P['wood']);d.point((8,10),fill=c)
    elif name=='save':
        d.rectangle((2,1,13,14),fill=green,outline=ink);d.rectangle((4,2,10,6),fill=c)
        d.rectangle((4,9,11,13),fill=c);d.line((6,11,9,11),fill=P['rose'])
    elif name=='star':
        d.polygon([(8,1),(10,5),(15,6),(11,9),(12,14),(8,12),(4,14),(5,9),(1,6),(6,5)],fill=gold,outline='#b68a44')
    elif name=='career':
        d.rectangle((2,5,14,14),fill=P['wood'],outline=ink);d.rectangle((5,2,11,6),outline=P['wood'],width=2)
        d.line((2,9,14,9),fill=gold);d.rectangle((7,8,9,10),fill=c)
    elif name=='clock':
        d.ellipse((1,1,14,14),fill=c,outline=green,width=2);d.line((8,4,8,8,11,10),fill=green)
    elif name=='arrow':
        d.polygon([(2,6),(9,6),(9,2),(15,8),(9,14),(9,10),(2,10)],fill=green)
    return im.resize((32,32),NEAREST)

def ui_panel(kind):
    im,d=canvas(48,48)
    if kind=='panel':
        d.rounded_rectangle((1,2,46,47),radius=6,fill=(42,48,44,65))
        d.rounded_rectangle((0,0,45,44),radius=3,fill=P['cream'],outline='#937965',width=1)
        d.rounded_rectangle((3,3,42,41),radius=2,outline='#fffbed')
        for x,y in [(5,5),(40,5),(5,39),(40,39)]:d.point((x,y),fill=P['gold'])
    else:
        col=P['sage_dark'] if kind=='button_selected' else P['sage']
        d.rounded_rectangle((1,3,46,47),3,fill='#486453')
        d.rounded_rectangle((0,0,45,43),3,fill=col,outline=P['sage_dark'],width=1)
        d.line((6,3,39,3),fill=P['sage_light'])
        d.line((5,40,40,40),fill='#66836d')
    return im.resize((96,96),NEAREST)

def title_logo():
    im,d=canvas(520,142)
    # High-resolution title deliberately stays legible while decorative art is pixel crisp.
    titlefont=font(57,True)
    text='CAMPUS QUEST'
    bbox=d.textbbox((0,0),text,font=titlefont); tw=bbox[2]-bbox[0]
    x=(520-tw)//2
    d.text((x+2,14),text,font=titlefont,fill='#5b6d5b',stroke_width=5,stroke_fill='#5b6d5b')
    d.text((x,8),text,font=titlefont,fill=P['cream'],stroke_width=2,stroke_fill=P['wood'])
    d.line((62,89,458,89),fill=P['gold'],width=2)
    txt(d,(260,113),'FIND YOUR NEXT MOVE',20,P['ink'])
    for x in (41,479):
        d.polygon([(x,80),(x+3,87),(x+10,90),(x+3,93),(x,100),(x-3,93),(x-10,90),(x-3,87)],fill=P['gold'])
    return im

def title_scene():
    # Low resolution scene doubled for consistent pixel edges.
    im,d=canvas(480,270,'#e8e4ce')
    for y in range(150):
        t=y/150
        c=tuple(int(a*(1-t)+b*t) for a,b in zip((184,210,201),(248,229,192)))
        d.line((0,y,480,y),fill=c)
    d.ellipse((352,30,405,83),fill='#fff0c4')
    # Stacked cloud puffs.
    for x,y in [(45,31),(210,42),(400,19)]:
        for dx,dy,r in [(0,0,10),(13,-4,15),(28,0,11)]:d.ellipse((x+dx-r,y+dy-r,x+dx+r,y+dy+r),fill='#f6ebd4')
    d.polygon([(0,133),(45,112),(86,125),(133,110),(180,133),(245,114),(302,130),(369,112),(422,128),(480,113),(480,190),(0,190)],fill='#a9bba0')
    d.rectangle((0,153,480,270),fill=P['grass'])
    # pavement perspective with brick pattern
    d.polygon([(207,157),(275,157),(402,270),(82,270)],fill='#ddccab')
    for y in (172,192,219,253):d.line((207-(y-157)*1.1,y,275+(y-157)*1.1,y),fill='#c8b593')
    for x in (150,240,330):d.line((241+(x-240)*.12,160,x,270),fill='#c8b593')
    d.rectangle((0,192,480,208),fill='#deccaa')
    for y in (193,200,207):d.line((0,y,480,y),fill='#c6b390')
    # Panorama of architecture.
    im.alpha_composite(building('lecture_hall').resize((160,140),NEAREST),(16,55))
    im.alpha_composite(building('library').resize((192,168),NEAREST),(149,27))
    im.alpha_composite(building('cafe').resize((144,126),NEAREST),(332,70))
    for x,y,name in [(0,120,'tree'),(420,120,'cherry_tree'),(125,132,'tree'),(305,141,'cherry_tree')]:
        pic=prop(name);im.alpha_composite(pic,(x,y))
    for x,y in [(65,217),(375,219),(16,193),(441,215)]:
        im.alpha_composite(prop('flowers'),(x,y))
    im.alpha_composite(prop('fountain'),(194,180))
    im.alpha_composite(prop('bench'),(74,195));im.alpha_composite(prop('bench'),(349,197))
    im.alpha_composite(prop('lamp'),(164,166));im.alpha_composite(prop('lamp'),(291,166))
    im.alpha_composite(prop('banner'),(34,158));im.alpha_composite(prop('banner'),(411,159))
    for name,x,y in [('maya',132,212),('leo',322,206),('nina',362,180)]:
        im.alpha_composite(sprite_frame(name,0,0).resize((24,36),NEAREST),(x,y))
    # Foreground petals and dappled grass, without visual noise in menu centre.
    rng=random.Random(92)
    for i in range(120):
        x,y=rng.randrange(480),rng.randrange(218,270)
        if x<85 or x>400:
            d.line((x,y,x+1,y-2),fill=rng.choice([P['grass_light'],P['grass_dark']]))
    # subtle foreground vignette only on bottom rim
    return im.resize((960,540),NEAREST)

def title_character():
    # A larger, more detailed original pixel character in 3/4 pose.
    im,d=canvas(120,170)
    skin='#e4a18f'; hair='#513b36'
    d.ellipse((18,155,109,168),fill=(35,49,43,45))
    # backpack behind figure
    d.rounded_rectangle((69,73,107,126),radius=10,fill='#97735f',outline=P['ink'],width=2)
    d.rounded_rectangle((80,91,105,119),radius=5,fill='#b48c6c',outline='#785949')
    d.rectangle((86,94,99,96),fill=P['gold']);d.rectangle((89,96,94,99),fill=P['wood'])
    # Legs and sneakers
    d.polygon([(40,112),(64,112),(60,150),(44,150)],fill='#62677e')
    d.polygon([(65,111),(83,114),(79,153),(64,153)],fill='#50576e')
    d.line((47,120,47,143),fill='#818396',width=3);d.line((70,121,69,147),fill='#73778a',width=2)
    d.rounded_rectangle((35,148,60,160),radius=4,fill=P['cream'],outline='#675952',width=2)
    d.rounded_rectangle((62,150,89,162),radius=4,fill=P['cream'],outline='#675952',width=2)
    d.line((37,157,58,157),fill=P['rose'],width=2);d.line((65,159,86,159),fill=P['rose'],width=2)
    for x,y in [(46,151),(48,153),(73,153),(75,155)]:d.line((x,y,x+7,y),fill='#b78f88')
    # hair back and body cardigan
    d.rounded_rectangle((30,14,85,93),radius=23,fill=hair,outline=P['ink'],width=2)
    d.polygon([(38,71),(58,65),(77,68),(91,84),(83,121),(36,119),(27,87)],fill='#a15d74',outline=P['ink'])
    d.polygon([(49,70),(60,79),(70,70),(68,118),(48,118)],fill='#f1d3bb')
    d.line((44,79,45,114),fill='#c78391',width=3);d.line((75,80,75,114),fill='#c78391',width=2)
    d.rectangle((36,102,44,109),outline='#784854');d.rectangle((77,102,85,109),outline='#784854')
    # arms, notebook, and phone
    d.polygon([(29,82),(36,84),(37,112),(30,120),(23,115),(26,96)],fill='#a15d74',outline=P['ink'])
    d.ellipse((25,110,34,123),fill=skin,outline='#ab756b')
    d.rectangle((20,93,41,114),fill='#91a99a',outline=P['ink'],width=2)
    d.rectangle((24,95,39,111),fill='#b9cbb0');d.line((25,99,36,99),fill=P['cream'])
    d.line((25,103,34,103),fill=P['cream'])
    d.polygon([(82,82),(91,85),(99,105),(93,112),(84,100)],fill='#a15d74',outline=P['ink'])
    d.ellipse((88,102,98,115),fill=skin,outline='#ab756b')
    # face
    d.ellipse((39,25,78,68),fill=skin,outline='#b77c6d')
    d.ellipse((35,44,43,56),fill=skin);d.ellipse((75,44,82,55),fill=skin)
    d.polygon([(35,40),(37,22),(48,15),(69,18),(81,30),(79,46),(70,33),(63,37),(58,29),(50,39),(46,34),(40,44)],fill=hair)
    d.line((39,25,47,20,59,20),fill='#7a5447',width=3)
    d.line((33,51,34,77,39,87),fill='#704b42',width=3)
    d.line((79,51,81,75,77,84),fill='#704b42',width=3)
    # eyes
    for x in (47,66):
        d.rectangle((x-2,44,x+5,51),fill='#fff0df')
        d.rectangle((x,44,x+3,51),fill=P['ink']);d.rectangle((x,44,x+1,46),fill=P['cream'])
        d.line((x-3,43,x+5,43),fill=hair,width=2)
    d.line((44,39,51,38),fill=hair);d.line((65,38,72,40),fill=hair)
    d.rectangle((43,54,48,56),fill='#dd8f8c');d.rectangle((69,54,74,56),fill='#dd8f8c')
    d.line((59,51,58,55,60,55),fill='#b77c6d')
    d.arc((54,57,65,63),0,180,fill='#975665',width=2)
    # pink bow clip and straps
    d.polygon([(72,28),(80,24),(82,30),(79,34)],fill=P['pink'],outline=P['darkpink'])
    d.polygon([(79,29),(87,27),(87,35),(80,34)],fill=P['pink'],outline=P['darkpink'])
    d.rectangle((78,29,81,33),fill=P['rose'])
    d.line((40,76,36,99),fill='#bc9675',width=4);d.line((82,77,87,97),fill='#bc9675',width=4)
    d.line((40,77,37,97),fill='#e1c09c')
    return im.resize((240,340),NEAREST)

def sound(path,freq,duration=.09,kind='sine',force=False):
    target=ASSET_DIR/'audio'/path;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and not force:return
    rate=22050;vals=[]
    for i in range(int(rate*duration)):
        t=i/rate; env=min(t/.008,1)*max(0,1-t/duration)
        phase=2*math.pi*freq*t
        sample=math.sin(phase) if kind=='sine' else (1 if math.sin(phase)>0 else -1)*.45
        vals.append(struct.pack('<h',int(sample*env*7000)))
    with wave.open(str(target),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(b''.join(vals))

def generate_assets(force=False):
    """Reconstruct missing original assets; existing custom assets are preserved."""
    for name,im in tiles().items():write('tiles/'+name+'.png',im,force)
    for name in ['library','lecture_hall','student_centre','health_centre','cafe','career_hub']:
        write('buildings/'+name+'.png',building(name),force)
    for name in ['tree','cherry_tree','bush','flowers','bench','lamp','fountain','sign','bike_rack','noticeboard','stall','table','rocks','bin','banner']:
        write('props/'+name+'.png',prop(name),force)
    for name in ['bookshelf','desk','computer','reception','chair','sofa','plant','projector','board','coffee_counter','poster','showcase','printer','exit_door']:
        write('interiors/'+name+'.png',furniture(name),force)
    write('player/student.png',spritesheet('student'),force)
    for name in PEOPLE:
        if name!='student':write('npcs/'+name+'.png',spritesheet(name),force)
    for name in ['student','maya','leo','nina','tutor','librarian','receptionist','support','adviser','barista']:
        write('portraits/'+name+'.png',portrait(name),force)
    write('npcs/professor.png',spritesheet('tutor'),force)
    write('portraits/professor.png',portrait('tutor'),force)
    for expression in ['tired','happy']:
        write('portraits/student_'+expression+'.png',portrait('student',expression),force)
    for name in ['health','energy','focus','stress','social','money','quests','timetable','assignments','support','stats','map','messages','inventory','save','document','star','career','clock','arrow']:
        write('icons/'+name+'.png',icon(name),force)
    for name in ['panel','button','button_selected']:write('ui/'+name+'.png',ui_panel(name),force)
    im,d=canvas(160,280)
    d.rounded_rectangle((2,2,157,277),18,fill=P['ink'],outline='#82908b',width=3)
    d.rounded_rectangle((8,12,151,264),12,fill='#f4ead4')
    d.rounded_rectangle((54,8,105,19),6,fill=P['ink'])
    d.line((60,270,100,270),fill='#82908b',width=3)
    write('ui/phone.png',im,force)
    write('ui/title_logo.png',title_logo(),force)
    write('ui/title_background.png',title_scene(),force)
    write('ui/title_character.png',title_character(),force)
    for name,freq,dur in [('click.wav',650,.045),('step.wav',165,.035),('success.wav',880,.18),('notification.wav',740,.12),('door.wav',280,.13),('error.wav',180,.14)]:
        sound(name,freq,dur,force=force)
    for alias in ['quest.wav','item.wav']:
        target=ASSET_DIR/'audio'/alias
        if force or not target.exists():
            target.write_bytes((ASSET_DIR/'audio'/'success.wav').read_bytes())
    files=[]
    for path in sorted(ASSET_DIR.rglob('*')):
        if path.is_file() and path.name!='manifest.json':
            entry={'path':str(path.relative_to(ASSET_DIR))}
            if path.suffix=='.png':
                with Image.open(path) as im:entry.update(width=im.width,height=im.height)
            files.append(entry)
    manifest={'title':'Campus Quest original pixel asset pack','author':'Procedurally drawn for this project',
              'license':'Original project artwork; no third-party artwork used',
              'sprite_layout':{'cell':[32,48],'columns':['idle','walk1','walk2','walk3'],'rows':['down','up','left','right']},
              'building_door_anchor':[128,208],'files':files}
    (ASSET_DIR/'manifest.json').write_text(json.dumps(manifest,indent=2))
    return ASSET_DIR

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--force',action='store_true',help='regenerate all original artwork')
    args=parser.parse_args()
    generate_assets(args.force)
    print('Campus Quest assets ready:',ASSET_DIR)
