# Campus Quest: Find Your Next Move

An original, local, single-player university-life RPG written in Python and Pygame.
Explore Rosewood University as a young female student, enter buildings, meet classmates,
and make decisions about study, rest, money, friendship and asking for support.

The eight chapters have required and optional quests, four-category star rewards,
chapter checkpoints, three playable challenges, branching conversations and a complete ending. It is a turn-based life simulation inside
a smoothly explored campus: walking does not consume story time; activities do.

## Installation

Python 3.12 is recommended. Open a terminal **inside this folder**:

```bash
python3 -m pip install -r requirements.txt
python3 main.py
```

Dependencies are `pygame-ce` (imported as `pygame`) and Pillow. The 99 original PNGs
and eight original sound effects are already included. No account, server, API key,
network connection or separately created sprite file is needed to play after installation.

### macOS / Anaconda

If using Anaconda, activate the environment first:

```bash
conda activate base
cd "/Users/mrunalthakur/Documents/ChatGPT/COMP9001 Assignment 2/CampusQuest"
python3 -m pip install -r requirements.txt
python3 main.py
```

The project was tested with the following Python 3.12 interpreter on this Mac:

```bash
/opt/anaconda3/bin/python3 -m pip install -r requirements.txt
/opt/anaconda3/bin/python3 main.py
```

If `python3` belongs to a different environment, use that interpreter for both
installation and running. Do not install classic `pygame` alongside `pygame-ce`;
they provide the same import name. Sound is optional and missing audio hardware
will not prevent the game from running.

### Windows

Extract the project, open a terminal in its folder, and run:

```powershell
py -3.12 -m pip install -r requirements.txt
py -3.12 main.py
```

Windows instructions are provided; the actual runtime checks were performed on macOS.

## Controls

| Input | Action |
|---|---|
| WASD / arrow keys | Smooth movement |
| E | Interact near a person, activity or door |
| Tab | Open phone; while in the phone, return one screen |
| Escape | Return to the previous conversation topic; close other dialogue; go back one phone screen; pause/resume exploration |
| Up / Down + Enter | Select dialogue or menu choices |
| Enter / Space / E during an explanation | Reveal text, then continue reading the next page |
| Left / Page Up during an explanation | Reread the previous page |
| Mouse | Select phone apps and menu/dialogue choices |
| Mouse wheel / Page Up / Page Down | Scroll phone screens |
| F5 | Quick save |
| F2 | Open chapter journal |
| B / F3 | Open campus challenges (B avoids macOS function-key shortcuts) |
| N | Return to chapter rewards after choosing Campus on the reward screen |

**Exit an interior through its physical exit door at the bottom. Escape never teleports you.**
The active interaction prompt appears when you are close enough. Phone navigation
always has a Back button and Escape returns exactly one screen.

## Playable chapters

| Chapter | Required progress |
|---|---|
| 1. First Day | Enter the Library and Lecture Theatre; use a library computer once |
| 2. Deadline Rush | Reach 40% Python progress; rest or have a snack |
| 3. Group Project Chaos | Respond to the late teammate; reach 40% group contribution |
| 4. Health Disruption | Consult the practitioner, receive a document, rest |
| 5. Special Consideration | Submit, wait for review, obtain and attach a follow-up note, receive a result |
| 6. Exam Season | Revise to 60%, complete the practice quiz and exam, rest |
| 7. Money Matters | Complete a casual shift, review a budget, attend a free event |
| 8. Career Quest | Resume review, networking conversation and practice interview |

The phone contains detailed objectives. Optional friendship objectives reward
exploration. Required quests award stars and unlock the next chapter. Star categories
are health management, academic progress, wellbeing and social life; the best earned
ratings are retained on replay. A current chapter can be replayed from its start
checkpoint. Earlier chapters remain in the journal as completed records.

## Campus and activities

- **Main Library:** computers, project work, revision, group study, librarian and Leo.
- **Lecture Theatre:** lecture, tutor guidance, Chapter 6 practice assessments.
- **Health Centre:** consultation, recovery and fictional supporting documents.
- **Student Centre:** support guide, budget planning, support phone and group meeting.
- **Petal & Bean Cafe:** snacks, coffee, time with Maya and a later casual shift.
- **Career & Innovation Hub:** resume review, appointment, networking and interview.
- **Campus plaza:** free society event, noticeboards, stalls and a paid setup shift.
- **Garden bench:** free rest, budget review and waiting for a response.

The campus is 64 x 44 tiles (2048 x 1408 pixels). Each interior is a separate
26 x 18 tile map. The six buildings have different PNG facades, connected paths
and reachable doors. Decorative objects, collision footprints and wandering NPCs
are loaded from the map data, not rebuilt each frame.

## Phone

Quests, Timetable, Assignments, Student Support, My Wellbeing, Campus Map,
Messages, Inventory and Save Game. The map has numbered building markers and a
current-position marker. The wellbeing screen shows a character expression,
detailed stats and a free-rest action. The timetable is a fictional story guide,
not a real calendar integration or a strict appointment booking system.

## Conversations, examples and follow-up questions

Campus residents have individual names, interests and guided conversations. Choose
a question, read the explanation, then ask a follow-up or return to an earlier
topic. There are 110 authored conversation nodes across classmates, lecturers,
library staff, health reception, student support, the cafe and career services.

For example, enter the **Career & Innovation Hub** and talk to **Imani**:

1. Choose **I need help with my resume**.
2. Choose **Projects and experience** to discuss useful evidence.
3. Ask for the before-and-after project example.
4. Continue reading, then ask another question or return to the section menu.
5. Choose **Review a sample together** when ready for the actual game activity.

Other resume topics include the opening profile, education/skills and tailoring.
Interview and introduction practice offer different player replies and specific
feedback. Dr. Rowan discusses functions, arrays, testing and assessments; Casey
explains fictional support requests and next steps. Student conversations cover
commuting, debugging, societies, group work, budgeting and presenting.

Reading and asking questions do not spend story time or grant stats. An explicit
activity, such as a review session, still uses the normal resource/time rules and
offers a return to the conversation afterward. People stop wandering while a
conversation is open. Long explanations have readable pages instead of hidden text.

Use **Enter** to reveal/continue, **Up/Down + Enter** or the mouse to choose a
question, **Left** to reread a page and **Escape** to go back one topic. Escape
at the first topic ends the conversation.

First-read explanations are saved once in **Phone > Messages > Conversation
journal**. Select a person, then a topic to reread the full explanation. These
records survive save/continue and replaying the current chapter. The conversations
use authored choices and examples; they do not accept unrestricted typed chat or
analyse a personal resume.

## Playable challenges and more meaningful study

Press **B** while exploring, choose **Play a Campus Challenge** at the bottom of
phone home, or interact with the appropriate campus character/location. F3 also
works when function keys are available.

| Challenge | What you actually play | First completion each story day |
|---|---|---|
| Maya's Memory Break | Flip cards and match eight pairs; opening preview and optional hints | +12 energy, -10 stress, +6 social; 20 story minutes |
| Petal & Bean: Cafe Rush | Mix drinks for six customers, manage their patience and build a serving streak | +8 focus, +5 confidence, -4 stress, +5 next-study progress boost; 15 minutes |
| Library Logic Lab | Swap Python statement cards into dependency order across three rounds | +12–16 project progress by stars, +5 focus, -3 stress, -5 energy; 45 minutes |

Memory is also available at the cafe or from Maya, Cafe Rush from Jun's shift
conversation or the society stalls, and the Logic Lab at library computers or from the librarian. They are
optional; the eight main story chapters retain their original completion paths.

- **Arrows + Enter / mouse:** memory cards and code-card selection/swapping.
- **Cafe Rush:** click a customer ticket or press Left/Right to choose it. Add
  ingredients with **1–4** or the mouse; **Space / Enter** serves the selected
  customer. **Backspace** undoes one ingredient; **C** or Clear Cup empties it.
  Match the three quantities on the ticket; pouring order does not matter.
  There are four recipes and six customers, with three tickets active initially.
  Read first: patience only starts decreasing after the first ingredient or hint.
  Late customers retry their order; mistakes affect stars, with no game-over lock.
  **H** asks Jun to prepare the selected recipe; you still choose to serve it.
- **C:** check the code order. All three rounds must be repaired.
- **H:** a helpful preview, recipe preparation or code correction; hints affect stars.
- **R:** restart the current puzzle. **Escape:** leave, with no story penalty.
- After solving, explicitly **claim the result** to apply the activity and reward.
  Opening, making mistakes, restarting and leaving never change story resources.
- Replays improve saved personal records but cannot repeatedly farm daily rewards.
  Completed replay activities still take their advertised story time.
- Complete all three to receive a **Campus Challenge Badge** in your inventory.
  Best scores, completion counts and daily eligibility are saved in JSON.
- Unfinished puzzle boards are session-only; leaving or closing the app discards
  the board. Previously claimed results remain in a saved journey.

Study now has an explicit efficiency calculation. At the library, the dialogue
previews the next session's progress before spending time. High focus adds 4;
high stress subtracts 5; low energy subtracts 4; feeling unwell subtracts 3.
A Cafe Rush reward or a 15-minute planning action prepares a nonstacking +5 boost
for the next successful study session. Minimum progress is 8 and project totals
are capped at 100. Normal starting conditions retain the original study pace.

Cafe Rush compares ingredient quantities using Counter collections. Its queue,
patience timers, serving streak and star rating are independent of the renderer.
The legacy internal `route` save identifier retains earlier challenge records;
all player-facing screens use Cafe Rush. Code cards are checked against authored
dependency orders; the game never executes user-entered code.

## Health and student-support storyline

Chapter 4 starts with lower health and energy and slightly slower movement.
Visiting the practitioner grants a **Supporting Document**. During Chapter 5:

1. Phone > Student Support > submit the request.
2. Do other activities, or choose Wait. Time-based messages move the request
   from SUBMITTED to UNDER REVIEW to MORE INFORMATION REQUIRED.
3. Revisit the Health Centre to collect a **Follow-up Note**.
4. Attach it in the support app, then let more story time pass.
5. Read the fictional approval message and complete the chapter.

These processes, services, documents and outcomes are **fictional game mechanics**.
They do not describe actual university policy, health advice or real applications.
There is no external submission or data collection.

## Events, wellbeing and money

Seventeen seeded encounters include rain, free food, a busy computer room, a lost
student card, a delayed shuttle, society invitations and feedback. Events offer
choices and show effects. A pending encounter survives saving; pressing Escape
can defer it until after another action.

Health, energy, focus, stress, social connection, confidence and career are clamped
to 0–100; money cannot become negative. Purchases and demanding activities check
resources before applying effects. Free rest, free events and support remain
available, so low energy or money does not create a permanent failure state.
The ending rewards a workable plan rather than finishing every possible activity.

## Project structure

```text
CampusQuest/
  main.py              # Entry point, headless/screenshot/presentation options
  settings.py          # Demo mode, sizes, palette, paths
  game.py              # Game loop, states, activity routing and transitions
  game_state.py        # Pure-Python story rules, stats, time and checkpoints
  assets.py            # Cached image/font/sound loading
  asset_generator.py   # Rebuild original PNGs and WAV effects with Pillow
  player.py            # Frame-independent movement, animation and camera
  world.py             # 2D maps, collision, depth sorting and minimap
  buildings.py         # Building data and physical entrances
  npc.py               # Characters, animation and wandering
  dialogue.py          # Branching dialogue and keyboard/mouse selection
  conversations.py     # Authored topics, follow-ups, Back stack and saved journal
  ui.py                # PNG-backed HUD, phone, menus and reward presentation
  quests.py            # Quest and QuestManager
  events.py            # Event and EventManager
  save_system.py       # Validated atomic JSON saving
  demo_tools.py        # Isolated later-chapter presentation journeys
  puzzles.py           # Pure-Python memory, cafe queue and code puzzle rules
  puzzle_ui.py         # Interactive puzzle screens, input and result claiming
  requirements.txt
  README.txt           # Tutor installation, entry point and GUI/dependency declarations
  README.md
  PADLET_POST.txt      # Ready-to-paste description and presentation plan
  CREATED_FILES.txt    # Exact list of files in the submission archive
  assets/              # Original art, effects and manifest
  maps/                # Seven readable JSON tile maps
  data/                # Save files created during play
  screenshots/         # Actual rendered game captures
  tests/               # State/persistence and Pygame integration tests
```

## Advanced Python concepts

### Object-oriented programming

`Game` coordinates the interface and world. `GameState` owns the rules without
importing Pygame, so its behavior can be tested independently. `Player`, `Camera`,
`NPC`, `World` and `Building` describe exploration. `Quest` / `QuestManager`,
`Event` / `EventManager`, `Phone`, `DialogueManager`, `Assets` and `SaveManager`
encapsulate their own data and operations. Composition connects them; unnecessary
inheritance is avoided.

Example: the UI sends `state.perform('study')`; the state checks energy, updates
assignment progress, applies stat changes, advances time and recalculates quests.
The renderer then displays the returned result without duplicating those rules.

### Multidimensional arrays

Every JSON map stores a `tiles[row][column]` array and a matching
`solids[row][column]` collision array. World loading draws each tile into a cached
background. Movement checks the cells touched by the student's feet and then
checks furniture footprints. Arrays therefore drive both environment rendering
and the actual movement rules. They are not included only for demonstration.

### Other concepts

Lists, dictionaries, dataclasses, functions, modules, file I/O, JSON serialisation,
exception handling, delta time, state management and deterministic random events.
Confirm the assessment's official advanced-topic classification with the tutor.

## Save system

Normal play uses `data/save.json`. Saving includes position, map, direction,
chapter, stats, time, assignment progress, inventory, support status/timers,
messages, quests, relationships, pending events, stars, unlocked chapters and the
current chapter-start checkpoint, plus read conversation topics and their journal.
Temporary files and atomic replacement protect
an existing save from a failed write. Invalid saves produce a readable message.
Continue is enabled only when the selected save file exists.

New Game does not erase a save immediately. Explicit saving and chapter completion
or advancement update the selected slot. F5 and Phone > Save also save at any time.
Presentation journeys use **data/demo_save.json**, keeping normal progress separate.

## Presentation mode / three-minute demo

`DEMO_MODE = True` in `settings.py` gives shorter objectives and support delays.
Normal mode is also playable by setting it to False.

**First-chapter demonstration:**

- **0:00–0:25:** title screen, premise and smooth movement; speak with Nina.
- **0:25–1:10:** enter the Library and work at a computer; show the result.
- **1:10–1:45:** press B, show a short memory round or mix an order in Cafe Rush, and explain how a break affects study. Use a hint if useful.
- **1:45–2:25:** leave through the door; enter the Lecture Theatre and unlock rewards.
- **2:25–3:00:** show stars, explain the two arrays and the OOP action flow; save.

To demonstrate the distinctive health/support story instead, prepare a sample:

```bash
python3 main.py --demo-chapter 4
```

You start outside the Health Centre. Consult the practitioner, rest in
Phone > My Wellbeing, and choose Next Chapter. Submit the support request; choose
Wait three times, revisit reception, attach the note, then wait twice. The exact
number depends on any other time-consuming activities. Show the messages and
chapter rewards. This uses a separate demo save and does not modify normal play.

## Tests and visual review

```bash
python3 -m compileall -q .
python3 -m unittest discover -s tests -v
python3 main.py --headless --frames 60
```

The tests use isolated temporary saves and SDL's dummy display for actual Pygame
integration checks. They cover all eight chapters, support statuses, dialogue
choices, movement/collision, all six building portals, every map's interaction
reachability, phone navigation, save/continue, replay, random event choices,
corrupt-save handling and rendered screens. Further tests solve all three puzzles
through actual mouse/keyboard input, verify hint/reset/cancel behavior, prevent
duplicate rewards, and check challenge records in both new and older saves.
Conversation tests follow resume and interview branches, verify individual student
profiles, render every authored topic, check page lengths and Back navigation,
and preserve the conversation journal through save/continue and chapter replay.

Capture a real rendered frame:

```bash
python3 main.py --headless --scene campus --frames 15 --screenshot screenshots/campus.png
python3 main.py --headless --scene library --frames 15 --screenshot screenshots/library.png
python3 main.py --headless --scene phone --frames 15 --screenshot screenshots/phone.png
python3 main.py --headless --scene memory --frames 15 --screenshot screenshots/memory_in_game.png
python3 main.py --headless --scene cafe --frames 15 --screenshot screenshots/cafe_rush.png
```

## Original artwork and optional sound

All game-specific artwork is procedurally authored in `asset_generator.py` and
saved as PNGs. Actual gameplay loads/caches these images: tiles, building facades,
furniture, 4-direction/4-frame sprite sheets, portraits, icons, nine-slice panels
and the illustrated title scene. Pygame primitives are limited to interface bars,
markers, particles and overlays. Rendering uses nearest-neighbor scaling.

The 99 PNGs and eight short WAV effects are original; no assets or music from
Pokemon, Stardew Valley or other games were copied. System fonts are used at
runtime and are not redistributed. Rebuild missing artwork automatically at launch,
or regenerate everything explicitly:

```bash
python3 asset_generator.py --force
```

## Known limitations

- A compact original game made for an assessment, with eight authored chapters;
  it is not a large commercial RPG or a real university planning application.
- Real timetables, clubs, services, bookings and email are not connected.
- Conversations use predefined questions and authored responses. Career examples
  are general learning material; they do not review uploaded personal documents.
- The timetable gives story context; missed appointments and real academic
  penalties are not simulated. Support approval is a scripted fictional outcome.
- Assessments are activities with progress and preparation rules, rather than
  full Python exercises or exam-question minigames.
- Only the current chapter has a replay checkpoint; older journal entries are
  records. There is one normal save slot and one presentation slot.
- Optional Chapters 9–10 and extra buildings from the initial brief are not included.
- Original art is programmatically drawn pixel art, not hand-animated production
  artwork. No background music; short effects are optional.
- Pygame targets 60 FPS, but hardware/display performance varies. Windows and
  other operating systems have not been interactively verified.

## Submission archive

The sibling CampusQuest.zip is the complete playable submission with all Python
files, tests, PNG/WAV assets, JSON maps, requirements and documentation. Review
screenshots stay in the local screenshots/ folder and are excluded from this ZIP
to keep it below Ed's 2 MB limit. Personal saves and caches are excluded too.
README.txt provides the tutor-facing entry point and dependency declarations.
PADLET_POST.txt contains the post text and a three-minute presentation plan.
