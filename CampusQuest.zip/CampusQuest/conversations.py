"""Authored, branching campus conversations with examples and follow-up questions.

Topics are data, not network requests. Reading a topic is free; only an explicitly
chosen activity changes story time/resources. The controller remembers a stack
for Back and records first-read explanations in the saved conversation journal.
"""
from dataclasses import dataclass, field


@dataclass
class ConversationNode:
    speaker: str
    portrait: str
    title: str
    text: object
    choices: list = field(default_factory=list)


STUDENT_PROFILES = {
    'student_1': ('Riya', 'leo', 'commuting', 'I commute, so my timetable has a secret extra column: getting here.', [
        ('How do you plan the journey?', 'I put travel beside the class, including a buffer for the part that often goes wrong. A gap that looks free on a timetable may already belong to the bus. I keep one small offline task for a delay, rather than trying to do a whole assignment on my phone.'),
        ('What if the bus is late?', 'I check what is genuinely urgent, let the relevant person know if I will miss a meeting, and adjust the next step. Yesterday I reviewed a question on the bus and drafted my group message after arriving. I did not have to rescue the whole day at once.')]),
    'student_2': ('Omar', 'leo', 'societies', 'I am trying a society event today. My plan is to meet one person, not become best friends with the whole room.', [
        ('How do you start a conversation?', 'I start with something shared: "Is this your first event?" or "What brought you along?" Then I ask a follow-up about their answer. A small conversation counts. I can also leave after a short visit; attending does not have to take the entire afternoon.'),
        ('What do you say about your project?', 'I use three pieces: who it helps, what the player does, and one interesting decision. For example: "It is a campus game about making your next move when plans change." After that I ask what kind of project they are making, rather than delivering my entire presentation.')]),
    'student_3': ('Tess', 'maya', 'debugging', 'My computer works. My code and I are still negotiating.', [
        ('How do you find a bug?', 'I write down what I expected and what actually happened. Then I try the smallest input that still reproduces the difference. If I change five things at once, I cannot tell which one helped. A tiny test case is often more useful than staring at the whole program.'),
        ('What do you ask a tutor?', 'I bring the relevant few lines, the input, the exact error and what I have tried. "This list should gain an item, but it stays empty" gives us somewhere to begin. Asking for an explanation helps me fix similar bugs later.')]),
    'student_4': ('Alex', 'nina', 'finding support', 'I transferred here. I have become very good at asking which desk I actually need.', [
        ('How do you ask the right question?', 'I say what I am trying to achieve, what is blocking me, and whether there is a date involved. Then I ask who handles that question. "I need help understanding an assessment-support request" is clearer than trying to explain every university problem in one breath.'),
        ('What if the first office cannot help?', 'I ask for the next contact or the name of the service, and write it down before leaving. In this fictional campus, Student Support is a useful starting point. Being redirected is part of finding the right person, not proof that I asked a bad question.')]),
    'student_5': ('Jules', 'maya', 'presenting', 'I am practising my presentation out loud. The trees are a very patient audience.', [
        ('How do you fit three minutes?', 'I choose one problem, one short demonstration and one explanation of the programming. I rehearse the transitions too: the time spent opening a menu is still presentation time. I keep a screenshot ready in case the live demonstration is slow.'),
        ('How do you make the opening interesting?', 'I open with the situation the audience recognises, then show the game responding. "Your assignment is due and support has not replied" creates a question. A long feature list makes it harder for people to know what to watch.')]),
    'student_6': ('Sam', 'nina', 'limited time', 'Today is a shorter campus day for me. I am choosing a finishable piece of work.', [
        ('How do you choose a small task?', 'I turn "do the assignment" into an action I can finish: write one function, inspect one error, or draft the first paragraph. I decide what "done for this session" means before starting. That gives me an honest stopping point when I need to leave.'),
        ('What if your energy changes?', 'I keep a demanding task and a lighter alternative. If I cannot do the first one, I can still organise notes or write the question I need answered. Sometimes resting is the useful next step. My plan is something I adjust, not a test I have failed.')]),
    'student_7': ('Priya', 'maya', 'group work', 'Our group finally replaced "someone should do that" with actual names and next steps.', [
        ('What makes a useful group message?', 'I include the task, the owner, the next check-in and a question if something is unclear. For example: "I can draft the save/load explanation by Thursday. Can you confirm who is checking the examples?" That is easier to answer than a vague message about everyone being behind.'),
        ('What if someone is missing?', 'I check in without guessing why they are absent, record what the available members can do, and ask for guidance if the problem persists. A conversation about the work is more productive than deciding someone does not care before hearing from them.')]),
    'student_8': ('Ben', 'leo', 'a tight budget', 'I am enjoying the campus stalls. Looking around is within my budget.', [
        ('How do you plan spending?', 'I separate the costs I need to cover from the money I can choose to spend. Then I leave a small buffer where possible. In the game, the budget action and a casual shift help the Money Matters chapter; a free event gives a social option without a purchase.'),
        ('Do I need to buy coffee to socialise?', 'No. I ask whether someone wants to sit outside or walk to a free stall. At this cafe you can sit with Maya without buying anything. The interesting part is the conversation, not whether we both have a drink.')]),
    'student_lecture': ('Asha', 'maya', 'lecture notes', 'I am comparing what I wrote down with what I actually understood.', [
        ('How do you revise a lecture?', 'I close the notes and try to explain one idea in my own words. Then I reopen them to find the missing piece. Copying a page can feel productive, but explaining a short example tells me more about what I need to practise.'),
        ('What if I did not understand?', 'I write a specific question and keep the example that confused me. "Why does this loop stop here?" is easier to discuss than "I understand nothing." You can ask Dr. Rowan about functions, arrays and testing in this game.')]),
    'student_waiting': ('Eli', 'nina', 'asking for help', 'I am waiting for my appointment. I wrote down my questions so I do not forget them.', [
        ('What did you write down?', 'For this fictional visit, I listed what is affecting my study, what I need clarified, and which story task I am worried about. The receptionist can explain how this game appointment and its supporting document work. I do not need to discuss private details with other students.'),
        ('What are you doing while waiting?', 'I am choosing between a quiet break and a small planning task. I can leave the assignment for a moment without abandoning it. In the game, a completed puzzle also lets story time pass while a support request is pending.')]),
    'student_network': ('Morgan', 'leo', 'career conversations', 'I used to think networking meant having an impressive speech ready. Now I start with a question.', [
        ('What question would you ask?', 'I ask what a person works on and what a beginner could practise to understand that work. Then I mention one relevant project. I am trying to learn whether the work interests me, rather than asking a stranger to solve my entire career.'),
        ('How do you describe a beginner project?', 'I explain the problem, what I built, and one decision I can defend. "I separated the game rules from drawing so I could test them" says more than simply naming Python. The adviser can help turn that explanation into a project bullet on a resume.')]),
}


class ConversationBook:
    def __init__(self):
        self.nodes = {}
        self.roots = {'maya':'maya.home', 'leo':'leo.home', 'nina':'nina.home',
                      'professor':'tutor.home', 'tutor':'tutor.home', 'librarian':'library.home',
                      'receptionist':'health.home', 'support':'support.home',
                      'barista':'cafe.home', 'adviser':'career.home'}
        self._build_career()
        self._build_campus()
        self._build_students()

    def add(self, key, speaker, portrait, title, text, choices):
        self.nodes[key] = ConversationNode(speaker, portrait, title, text, choices)
        return key

    def topic(self, key, speaker, portrait, title, text, parent, extras=()):
        choices = list(extras) + [('I have another question', 'talk:'+parent), ('Back', 'talk:back')]
        return self.add(key,speaker,portrait,title,text,choices)

    def root_for(self, npc_id):
        return self.roots.get(npc_id, 'visitor.home')

    def _build_career(self):
        a,p='Imani / Career adviser','adviser'
        self.add('career.home',a,p,'Career conversations',
                 lambda s: ('Welcome back. We can keep working on the part that matters to you.' if s.flags.get('talk:career.home:read') else 'Welcome! You do not need a finished career plan to start a conversation.')+' What would you like help with: your resume, talking to people, or practising an interview?',
                 [('I need help with my resume','talk:career.resume'),('How do I introduce myself?','talk:career.network'),('Can we practise an interview?','talk:career.interview'),('Book a career planning session','career_appointment'),('Thanks, I will come back','talk:close')])
        self.add('career.resume',a,p,'Which part of your resume?',
                 'Let us choose one section. We can look at what it does, discuss an example, and then decide whether you want to work through a sample together.',
                 [('Opening profile / summary','talk:career.profile'),('Education and skills','talk:career.skills'),('Projects and experience','talk:career.projects'),('Layout and tailoring','talk:career.layout'),('Review a sample together','talk:career.review'),('Back','talk:back')])
        self.topic('career.profile',a,p,'A useful opening profile',
                   'A short profile can help connect your current experience to the opportunity. Start with what you study or do, mention a relevant strength with evidence, and describe the kind of work you want to explore. Avoid filling the space with unsupported words such as "excellent" or "expert".\n\nFor a beginner: "Postgraduate student developing Python applications, with project experience in object-oriented design, JSON persistence and testing." Adapt the wording to what you can actually explain.',
                   'career.resume', [('What if I have no work experience?','talk:career.no_experience'),('Can I see a stronger example?','talk:career.before_after')])
        self.topic('career.skills',a,p,'Education and skills',
                   'List your qualification and relevant study clearly. For skills, choose things you can demonstrate: Python functions and classes, file handling, testing, or communication through group work. A skill list is stronger when the project section shows where you used those skills.\n\nIf you are still learning something, describe the work honestly instead of giving yourself an inflated rating. A small completed project is useful evidence of what you can do.',
                   'career.resume',[('How do I prove a skill?','talk:career.evidence')])
        self.topic('career.projects',a,p,'Turning a project into experience',
                   'Describe what you made, the part you were responsible for, and the result. A useful bullet usually begins with an action, then explains the work and why it mattered.\n\nExample: "Built a Python campus-life game with tile-based collision, branching dialogue and JSON saving; separated story rules from rendering to make behaviour testable." Use only details that reflect your own contribution, and be prepared to explain them.',
                   'career.resume',[('Show a before-and-after bullet','talk:career.before_after'),('I do not have paid experience','talk:career.no_experience'),('Let us review the sample','talk:career.review')])
        self.topic('career.layout',a,p,'Layout and tailoring',
                   'Use clear section headings, consistent dates and readable spacing. Give the most relevant material enough space to be understood. When tailoring a resume, look for what the opportunity asks you to demonstrate, then choose truthful examples that address it.\n\nThe goal is not to add every course or tool you have seen. Help the reader find your relevant evidence, and check spelling, links and contact information before sending it.',
                   'career.resume',[('What should I leave out?','talk:career.relevance')])
        self.topic('career.no_experience',a,p,'Starting without paid experience',
                   'Course projects, volunteering, society roles and personal work can all provide examples. Ask what you planned, built, organised, tested or improved. Explain the context rather than pretending it was paid employment.\n\nFor example, helping a society organise a small event can show coordination and communication. A Python project can show implementation and debugging. The useful evidence is your contribution and what you learned.',
                   'career.resume',[('Help me write a project bullet','talk:career.before_after')])
        self.topic('career.before_after',a,p,'Make the evidence visible',
                   'Before: "Good at Python and teamwork."\n\nAfter: "Implemented JSON save/load for a Python game and checked recovery from invalid save files."\n\nThe second version explains an action and a result. For teamwork, name your role: "Coordinated weekly check-ins and recorded task owners for a group presentation." Do not invent numbers or outcomes. Choose an example that you can discuss in your own words.',
                   'career.resume',[('Can we review a sample now?','talk:career.review'),('How do I explain this in an interview?','talk:career.interview')])
        self.topic('career.evidence',a,p,'Connect skills to examples',
                   'For each skill you list, keep one example in mind. If you list debugging, describe a bug, how you reproduced it, and how you checked the fix. If you list communication, explain a time you clarified a task or helped a group agree on a plan. The skill and the example should support each other.',
                   'career.resume',[('Show a project bullet','talk:career.before_after')])
        self.topic('career.relevance',a,p,'Choose what helps this reader',
                   'Ask whether a detail helps someone understand your fit for this opportunity. Unrelated lists and repeated claims can hide your stronger evidence. You can keep a longer personal record of everything you have done, then choose relevant examples for the version you share.\n\nYou are allowed to be a beginner. Clarity and honest evidence are more useful than trying to sound senior.',
                   'career.resume',[('I want to work on the sample','talk:career.review')])
        self.topic('career.review',a,p,'Work through the sample',
                   'We will use a fictional student resume. First, make the education section easy to scan. Next, replace "I am good at coding" with one project example. Finally, connect a skill to something the student actually built.\n\nWould you like to spend a story session reviewing it together? The next choice completes the Career Quest resume-review activity. Reading the examples alone has not spent time or awarded career points.',
                   'career.resume',[('Review the sample together / 45 min','career_resume')])
        self.add('career.network',a,p,'Start a conversation',
                 'Imagine we are at the project showcase. I ask, "What are you working on?" Which opening would you like to try?',
                 [('I built a game about university decisions','talk:career.pitch_good'),('I know lots of programming languages','talk:career.pitch_vague'),('I am not sure what to say yet','talk:career.pitch_help'),('Back','talk:back')])
        for key,text in [('pitch_good','That gives us something concrete to discuss. Add who it is for and one interesting decision, then leave room for a question. For example: "Students choose what to do while a support reply is pending." Now ask what the other person works on.'),
                         ('pitch_vague','That names tools, but I do not yet know what you made or why it matters. Try describing one project before listing languages. A short example gives the other person an easy follow-up question.'),
                         ('pitch_help','You can start small: "I am learning Python and building a campus game. I am interested in how software can make complicated choices easier to understand." You do not need a polished sales pitch to ask someone about their work.')]:
            self.topic('career.'+key,a,p,'Keep the conversation going',text,'career.home', [('Practise a networking conversation / 45 min','career_network'),('Can we practise an interview next?','talk:career.interview')])
        self.add('career.interview',a,p,'Practise an interview answer',
                 'Let us use a practice question: "Tell me about a time your plan changed and how you responded." What would your answer focus on?',
                 [('What I changed, why, and what I learned','talk:career.answer_clear'),('How I did everything on my own','talk:career.answer_solo'),('I cannot think of a work example','talk:career.answer_beginner'),('Back','talk:back')])
        for key,text in [('answer_clear','That is a useful structure. Briefly set the situation, explain your responsibility, describe your action and reflect on the result. Make your own contribution clear without removing the other people from the story. A result can include what you learned or what you would change.'),
                         ('answer_solo','You can show initiative without claiming you solved everything alone. Explain what you owned, how you communicated, and when you asked for help. If someone else contributed, say so. That makes the account more specific and believable.'),
                         ('answer_beginner','A course project or society task can work as an example. Perhaps you found a bug, adjusted a group plan, or made a task smaller after a disruption. Explain what happened and what you did; do not invent a professional experience.')]:
            self.topic('career.'+key,a,p,'Reflect on your answer',text,'career.home',[('Finish the practice interview / 1 hour','career_interview'),('Help me describe a project first','talk:career.projects')])

    def _build_campus(self):
        self.add('maya.home','Maya','maya','A conversation with Maya',
                 lambda s: ('You look like you have a lot on today. We can talk for a minute without solving everything.' if s.stats['stress']>=60 else 'Hey! I have a little time before my next thing. What is on your mind?'),
                 [('I am overwhelmed by my workload','talk:maya.workload'),('I am finding it hard to meet people','talk:maya.friends'),('What are you working on?','talk:maya.project'),('Play the memory game together','puzzle:memory'),('Sit and catch up / 1 hour','maya'),('See you later','talk:close')])
        self.topic('maya.workload','Maya','maya','One piece of the workload',
                   'When I say "finish the project", I end up staring at it. I try naming the next visible action: open the file, reproduce the bug, or write the first example. What is making your next step difficult?',
                   'maya.home',[('I do not know where to start','talk:maya.start'),('I keep working without a break','talk:maya.break')])
        self.topic('maya.start','Maya','maya','Give the next step a name',
                   'Let us choose something small enough to finish in one session. If the instructions are unclear, the action might be to write a question for the tutor. If the program crashes, it might be to find the smallest input that repeats the error. A useful next step does not have to solve the entire assignment.',
                   'maya.home',[('Ask Leo about planning study','talk:leo.plan'),('Show my current quests','open:quests')])
        self.topic('maya.break','Maya','maya','A change of pace',
                   'I can sit with you, or we can play the matching game. In this story a completed memory round restores energy and eases stress. It takes twenty story minutes when you claim the result. You can also leave a puzzle without changing your story resources.',
                   'maya.home',[('Play a memory round','puzzle:memory'),('Let us sit together / 1 hour','maya')])
        self.topic('maya.friends','Maya','maya','A small social step',
                   'I start with the activity we share: "Have you been to this society before?" or "What are you making for the project?" Then I listen for something I can ask about. I do not need to be interesting every second. Want to practise a first line?',
                   'maya.home',[('Is this your first society event?','talk:maya.practice'),('Tell me about the free events','talk:events.home')])
        self.topic('maya.practice','Maya','maya','Practise with Maya',
                   '"It is! I came because someone said beginners were welcome." Now you could ask what interested me, or tell me what brought you. See? We already have a conversation, and neither of us needed a perfect introduction.',
                   'maya.home',[('What brought you to the event?','talk:maya.project')])
        self.topic('maya.project','Maya','maya','Maya has a project too',
                   'I am making a little story about a community garden. I keep inventing extra features, so Leo made me choose the one thing that has to work first. Today I am fixing the dialogue. I want the characters to remember what someone asked, rather than repeating the same greeting forever.',
                   'maya.home',[('How do you decide what to cut?','talk:leo.scope'),('I would like to hear about another event','talk:events.home')])
        self.add('leo.home','Leo','leo','Compare notes with Leo',
                 'I have a plan, three backup plans, and a reminder to stop planning eventually. What do you want to work through?',
                 [('How should I start a study session?','talk:leo.plan'),('I need help debugging','talk:leo.debug'),('Our group is not communicating','talk:group.home'),('How do you control project scope?','talk:leo.scope'),('Thanks, that is enough for now','talk:close')])
        self.topic('leo.plan','Leo','leo','A study session with an endpoint',
                   'Choose one outcome you can check: one function behaves correctly, one topic can be explained without notes, or one paragraph has a draft. Put the materials you need in front of you before starting.\n\nIn the game, high focus improves project progress. High stress, low energy and feeling unwell reduce it. The library computer previews the actual next-session increase. A short planning action or Cafe Rush prepares a one-use boost.',
                   'leo.home',[('Plan the next session / 15 min','work_plan'),('Try a hands-on code puzzle','puzzle:code'),('What if the code fails?','talk:leo.debug')])
        self.topic('leo.debug','Leo','leo','Make the bug smaller',
                   'I write down the input, the result I expected, and the result I got. Then I reduce the example until I can explain each line. I change one thing and rerun the example. If I ask for help, I bring that small example and the exact error.\n\nThe Logic Lab practises ordering statements so each variable exists before a later statement uses it. It is a puzzle, not an editor that executes arbitrary input.',
                   'leo.home',[('Try the Logic Lab','puzzle:code'),('Ask the tutor about testing','talk:tutor.testing')])
        self.topic('leo.scope','Leo','leo','Choose what has to work',
                   'I write a one-sentence promise to the user, then ask which feature proves it. Everything else competes for the time left after that feature works. Adding a new screen also adds navigation, saved state and things to test.\n\nFor this game, an interesting campus decision matters more to the promise than the number of buildings. A small working example makes a stronger demonstration than a long tour of unfinished ideas.',
                   'leo.home',[('Ask about presenting the project','talk:nina.presentation')])
        self.add('nina.home','Nina','nina','Find your bearings',
                 'Hello again! I am the senior student who still occasionally takes the long way to the cafe. What would help you find your next move?',
                 [('Where should I go for help?','talk:nina.where'),('How do I fit events around study?','talk:events.planning'),('How do I prepare the presentation?','talk:nina.presentation'),('Show the campus challenges','challenges'),('Open my quests','open:quests'),('See you around','talk:close')])
        self.topic('nina.where','Nina','nina','Start with the question',
                   'For this fictional campus: ask the tutor about coursework, the librarian about study resources, Student Support about university processes, and the Career Hub about projects, resumes and interviews. The health receptionist explains the story consultation.\n\nSay what you are trying to do, what is blocking you and what you have already tried. You do not need to know the whole answer before asking who can help.',
                   'nina.home',[('Talk through student services','talk:support.home'),('How does the health storyline work?','talk:health.home')])
        self.topic('nina.presentation','Nina','nina','A three-minute demonstration',
                   'Start with the student situation, show one decision and its consequence, then explain the programming that makes it possible. Practise the sequence with a timer, including menu navigation.\n\nFor example: a support request is pending, so the player solves a puzzle while story time advances. Then show how the tile and collision arrays represent the campus, and how a class keeps the rules separate from drawing.',
                   'nina.home',[('I want to practise a project introduction','talk:career.network')])
        self.add('tutor.home','Dr. Rowan','tutor','A question for your tutor',
                 'Let us find the part you want to understand. You can ask about a concept, discuss group work, or attend the story lecture.',
                 [('Functions and classes','talk:tutor.functions'),('Two-dimensional arrays','talk:tutor.arrays'),('Testing and error messages','talk:tutor.testing'),('Guidance on our group work','group_tutor'),('Attend the lecture / 1 hour','lecture'),('Assessment practice and revision','talk:tutor.assessments'),('Goodbye','talk:close')])
        self.topic('tutor.functions','Dr. Rowan','tutor','Give code a responsibility',
                   'A function gives a name to a reusable operation. A class groups state with operations that make sense for that state. In a game, a Player can own its position and movement; a Quest can own a target and progress.\n\nThe useful question is what responsibility belongs together. A class is helpful when it makes the program easier to reason about, not simply because there is a class keyword in the file.',
                   'tutor.home',[('How do arrays fit into this game?','talk:tutor.arrays'),('How do I check the behaviour?','talk:tutor.testing')])
        self.topic('tutor.arrays','Dr. Rowan','tutor','Rows, columns and collision',
                   'A two-dimensional list can represent a map as rows containing columns. In this game tiles[row][column] chooses an image, while solids[row][column] says whether that cell blocks movement.\n\nThe player checks the cells touched by the feet before moving. Using the same map coordinates for drawing and collision keeps the visual world and movement rules connected. Think carefully about row/y and column/x when indexing.',
                   'tutor.home',[('What boundary cases would you test?','talk:tutor.testing')])
        self.topic('tutor.testing','Dr. Rowan','tutor','Expected behaviour first',
                   'Choose an input and write down what should happen. Then run that case and compare. For a map, check walking across open ground, approaching a wall, moving diagonally and leaving through a door. For saving, check a round trip and a damaged file.\n\nException handling should explain a failure that can reasonably happen, such as an unreadable save. It should not silently hide every programming error.',
                   'tutor.home',[('How do I make a debugging question specific?','talk:leo.debug'),('Try ordering some code','puzzle:code')])
        self.add('tutor.assessments','Dr. Rowan','tutor','Assessment practice',
                 lambda s: 'The library is available for revision. Practice quiz and exam activities become part of Chapter 6. You are currently in Chapter '+str(s.chapter)+'. You can ask questions before deciding to do an activity.',
                 [('Revise a topic / 1 hour','revision'),('Take the practice quiz','quiz'),('Sit the practice exam','exam'),('Back','talk:back')])
        self.add('library.home','Harper / Librarian','librarian','A question at the library',
                 'Welcome. Would you like to find a resource, choose a study approach, or try the Logic Lab? The computers are along the lower desks.',
                 [('How do I find a useful resource?','talk:library.resources'),('I read but do not remember much','talk:library.active'),('What can I do when a computer is busy?','talk:library.busy'),('Try the Library Logic Lab','puzzle:code'),('Back to my work','talk:close')])
        self.topic('library.resources','Harper / Librarian','librarian','Search with a purpose',
                   'Turn the task into a question, then choose two or three key terms. Scan the title, summary and source before reading everything. Keep the details you would need to find the resource again.\n\nFor a programming task, an example that matches the concept can be more useful than a huge finished program. Compare what the example assumes with your own input and requirements.',
                   'library.home',[('How do I study from the resource?','talk:library.active'),('Ask about testing an example','talk:tutor.testing')])
        self.topic('library.active','Harper / Librarian','librarian','Do something with the idea',
                   'After a short section, close the resource and explain the idea or sketch an example. Reopen it to check the part you missed. For code, predict the output of a small change before running it.\n\nYou can practise that kind of reasoning in the Logic Lab. If you need a change of pace, the memory game and Cafe Rush are available from your phone.',
                   'library.home',[('Try a code-ordering puzzle','puzzle:code'),('Show all campus challenges','challenges')])
        self.topic('library.busy','Harper / Librarian','librarian','Keep a small alternative',
                   'You could outline the next function on paper, inspect an example, or write the question you want to ask. A quiet desk can still be useful when the machine you wanted is busy. If you need to stop, save a clear note about the next step so starting again is easier.',
                   'library.home',[('Plan my next session / 15 min','work_plan')])
        self.add('health.home','Avery / Health reception','receptionist','Talk before deciding',
                 lambda s: ('Your follow-up note is part of the current story request. I can explain what happens next.' if s.support_status=='MORE INFORMATION REQUIRED' else 'Welcome. I can explain our fictional appointment and document process. You do not need to share personal medical details in this game.'),
                 [('What happens during this story appointment?','talk:health.appointment'),('What is the supporting document for?','talk:health.document'),('I am worried about my assignment','talk:health.study'),('See the practitioner / 1 hour','health'),('Take a quiet rest / 2 hours','rest'),('Leave for now','talk:close')])
        self.topic('health.appointment','Avery / Health reception','receptionist','The story appointment',
                   'In this game, choosing the practitioner appointment takes an hour of story time, improves the character\'s health and gives a fictional Supporting Document. If Student Support has asked for more information, the visit provides a Follow-up Note instead.\n\nThis is a simplified narrative mechanic. We are not diagnosing symptoms or describing the rules of a real health service.',
                   'health.home',[('I would like the story consultation','health'),('Explain the document next','talk:health.document')])
        self.topic('health.document','Avery / Health reception','receptionist','Keep the document in your backpack',
                   lambda s: ('Your request currently says MORE INFORMATION REQUIRED. A new consultation gives a Follow-up Note. Attach it through Phone > Student Support.' if s.support_status=='MORE INFORMATION REQUIRED' else 'The Supporting Document goes into your inventory. During Chapter 5, the Student Support phone app lets you attach it to a fictional request.')+'\n\nReceiving an item does not submit the request automatically. You can ask Student Support about the next step and read its later messages. Real services and requirements may differ.',
                   'health.home',[('Ask Student Support how the request works','talk:support.assessment'),('Visit the practitioner','health')])
        self.topic('health.study','Avery / Health reception','receptionist','Make room for the next step',
                   'Within the story, you can rest, ask about support, or choose a smaller piece of work while waiting for a response. Feeling unwell slows movement and reduces the next study session\'s progress. The library preview makes that effect visible before you choose to work.\n\nYou do not have to finish every possible activity to move the story forward.',
                   'health.home',[('Ask about assessment support','talk:support.assessment'),('Take a rest now','rest')])
        self.add('support.home','Casey / Student Support','support','What would you like to understand?',
                 'We can take one question at a time. Choose a service topic, ask a follow-up, or open the fictional support request in your phone.',
                 [('Enrolment and finding the right contact','talk:support.enrolment'),('My timetable and campus events','talk:support.timetable'),('My student card','talk:support.card'),('Assessment support / Special Consideration','talk:support.assessment'),('Open the Student Support phone app','open:support'),('More campus services','talk:support.more'),('Thanks, goodbye','talk:close')])
        self.topic('support.enrolment','Casey / Student Support','support','Ask a clear enrolment question',
                   'For this fictional conversation, start with the change you want to understand, the unit or record involved, and the question you need answered. We can point you toward the appropriate office.\n\nThe game does not change your real enrolment or provide institution-specific rules. In a real enquiry, use the official service information and avoid sending unrelated private details.',
                   'support.home',[('What should I include in an enquiry?','talk:support.enquiry')])
        self.topic('support.enquiry','Casey / Student Support','support','A short, answerable enquiry',
                   'Use a clear subject, briefly describe the issue, say what you have already checked, and ask the next question. For example: "I am trying to understand which service handles this assessment-support question. Could you direct me to the right team?"\n\nBefore sending anything outside the game, check the real service\'s contact details and instructions. This conversation sends no message.',
                   'support.home',[('What can I do while I wait?','talk:support.waiting')])
        self.topic('support.timetable','Casey / Student Support','support','Read the gap carefully',
                   'Compare the start and end times, then allow for travel and the time you need before the next commitment. A gap between two classes is not always enough for an entire event.\n\nOur phone timetable is a story guide. It does not check live university timetables or book places. Nina can help you think through an event choice in this fictional campus.',
                   'support.home',[('Help me choose an event','talk:events.planning'),('Open my story timetable','open:timetable')])
        self.topic('support.card','Casey / Student Support','support','A student-card question',
                   'In this campus story, ask the desk what to do if a card goes missing and which service handles it. You can keep a note of when and where you last had it. Finding someone else\'s card can also appear as a campus encounter; handing it to a staff member is an available response.\n\nNo real replacement is ordered or identity document collected by this game.',
                   'support.home',[('How do I ask another service for help?','talk:support.enquiry')])
        self.topic('support.assessment','Casey / Student Support','support','The fictional support request',
                   lambda s: 'Your current story status is '+s.support_status.replace('_',' ')+'.\n\nIn Chapter 5, collect the story Supporting Document, submit the request in the phone and watch for messages. A later message asks for a Follow-up Note; revisit the practitioner, attach the note and let story time pass. This scripted route is not a statement of real university policy or a promise of an outcome.',
                   'support.home',[('What can I do while waiting?','talk:support.waiting'),('What if more information is requested?','talk:support.followup'),('Open my request','open:support')])
        self.topic('support.waiting','Casey / Student Support','support','Continue without assuming the outcome',
                   'A pending request does not stop every activity in this game. You can make a small amount of progress, rest, visit a friend or complete a puzzle. Claiming a puzzle result advances story time and can bring the next message.\n\nKeep an eye on the phone instead of treating a submitted request as already resolved. If a message asks for something else, adjust your next step.',
                   'support.home',[('Show the break challenges','challenges'),('Read my messages','open:messages')])
        self.topic('support.followup','Casey / Student Support','support','Respond to the actual message',
                   'In this story, MORE INFORMATION REQUIRED means the next item is the Follow-up Note. Talk to health reception, choose the practitioner visit, then attach that item in the support phone app.\n\nWaiting repeatedly without attaching the note will not advance this stage. After attaching it, other activities or the Wait action allow the review timer to finish.',
                   'support.home',[('Ask health reception about the note','talk:health.document'),('Open Student Support','open:support')])
        self.add('support.more','Casey / Student Support','support','Other campus questions',
                 'We can discuss a budget in the game, point you to career conversations or help you find a sensible first question. What would you like next?',
                 [('Review my story budget','budget'),('I have a group meeting question','talk:group.home'),('I want career guidance','talk:career.home'),('How should I write an enquiry?','talk:support.enquiry'),('Back','talk:back')])
        self.add('cafe.home','Jun / Petal & Bean','barista','A cafe conversation',
                 'Hello! You can sit here without buying anything. Would you like a recommendation, a snack, a coffee, or a conversation about the shift?',
                 [('How do the snack and coffee differ?','talk:cafe.menu'),('Is there a free way to take a break?','talk:cafe.free'),('Cafe Rush and the casual shift','talk:cafe.shift'),('Buy a snack / $6','snack'),('Buy a coffee / $5','coffee'),('Find Maya','talk:maya.home'),('Goodbye','talk:close')])
        self.topic('cafe.menu','Jun / Petal & Bean','barista','Choose what fits your plan',
                   'In our game, a snack costs $6 and restores 20 energy. Coffee costs $5, restores 12 energy and adds 5 focus. These are game effects, not nutrition or health advice.\n\nYou can look at your current energy and money before choosing. If the budget is tight, a free rest or a chat with Maya is still available.',
                   'cafe.home',[('I will have the snack','snack'),('I will have the coffee','coffee'),('Let us talk about a free break','talk:cafe.free')])
        self.topic('cafe.free','Jun / Petal & Bean','barista','No purchase required',
                   'Sit with Maya, try her matching cards or walk to a free society event. In this story, a social break does not have to cost money. A finished memory round can also help you recover before studying.\n\nYou are welcome to take a moment and decide what fits the time you have.',
                   'cafe.home',[('Talk to Maya','talk:maya.home'),('Play the memory game','puzzle:memory')])
        self.topic('cafe.shift','Jun / Petal & Bean','barista','Ask before taking the shift',
                   'Want a hands-on practice round? Cafe Rush lets you mix drinks for six customers. Read the recipe tickets, choose a customer and add three ingredients before serving. The timer starts with your first ingredient. The practice reward helps your next study session.\n\nThe separate casual shift takes time and energy and pays story money for the Money Matters chapter. Cafe Rush practice does not replace that paid activity. Which would you like to try?',
                   'cafe.home',[('Play a Cafe Rush practice round','puzzle:route'),('Take the casual shift','money_shift'),('Help me review my budget','budget')])
        self.add('group.home','Leo / Project group','leo','Talk through the missed meeting',
                 'One teammate has not arrived. We can check in before guessing why. How do you want to approach the conversation or the work?',
                 [('Help me write a message','talk:group.message'),('How do we divide the remaining work?','talk:group.tasks'),('Message the teammate now','group_message'),('Continue with the available members','group_continue'),('Wait a little','group_wait'),('Ask the tutor for guidance','group_tutor'),('Not now','talk:close')])
        self.topic('group.message','Leo / Project group','leo','A message someone can answer',
                   'Try: "Hi, we have started the meeting and wanted to check whether you can join. We are dividing the remaining tasks. Could you let us know what you can take on and when we should check in?"\n\nIt describes the situation and asks a concrete question. You have not sent anything outside this game. Would you like to use the story message option?',
                   'group.home',[('Use the story message','group_message'),('What if we need to continue?','talk:group.tasks')])
        self.topic('group.tasks','Leo / Project group','leo','Make ownership visible',
                   'List the remaining pieces, agree who owns each one and choose a next check-in. Record dependencies: someone cannot review a section that has not been drafted yet. If a commitment changes, update the plan rather than leaving everyone to infer it.\n\nFor this story, continuing with available members makes group-project progress. You can still ask for tutor guidance if the uncertainty remains.',
                   'group.home',[('Continue with an agreed contribution','group_continue'),('Ask the tutor for guidance','group_tutor')])
        self.add('events.home','Nina / Society plaza','nina','What would you like to join?',
                 'There is a free gathering and a Cafe Rush practice stand today. Want to ask about the event before deciding?',
                 [('Can I fit an event around study?','talk:events.planning'),('I do not know anyone there','talk:events.first'),('Join the free society gathering','festival'),('Try Petal & Bean: Cafe Rush','puzzle:route'),('Maybe later','talk:close')])
        self.topic('events.planning','Nina / Society plaza','nina','Choose an attendance plan',
                   'Start with the next fixed commitment, then allow travel time. Decide whether you can attend the whole event or whether a shorter visit makes sense. Keep room for the study task you meant to finish.\n\nOur timetable is fictional context; it does not enforce live clashes. The free event still consumes story time, so it is a choice about how you want to spend the day.',
                   'events.home',[('What if I do not know anyone?','talk:events.first'),('Join the free event','festival'),('Open the timetable','open:timetable')])
        self.topic('events.first','Nina / Society plaza','nina','You can arrive as a beginner',
                   'You could ask a volunteer what the activity involves, join a small table, or introduce yourself to one person. You do not have to stay for everything. Omar has been practising simple conversation starters, and Maya is happy to try one with you.',
                   'events.home',[('Practise with Maya','talk:maya.friends'),('Join the event','festival')])

    def _build_students(self):
        for npc_id,(name,portrait,theme,greeting,topics) in STUDENT_PROFILES.items():
            root='student.'+npc_id
            self.roots[npc_id]=root
            choices=[]
            for index,(question,answer) in enumerate(topics):
                key=root+'.'+str(index)
                choices.append((question,'talk:'+key))
                other=root+'.'+str(1-index)
                self.topic(key,name,portrait,question,answer,root,[(topics[1-index][0],'talk:'+other)])
            choices += [('What are you working on today?','talk:'+root+'.today'),('Nice talking to you','talk:close')]
            self.add(root,name,portrait,theme.title(),greeting,choices)
            self.topic(root+'.today',name,portrait,'Today\'s next move',
                       lambda s,n=name,t=theme: f'I am working on {t}, and choosing a manageable next step. You are in Chapter {s.chapter}: {s.chapter_title}. I like that we can ask a question, change a plan or take a break without pretending the rest of the day is already solved.',root)
        self.add('visitor.home','A campus visitor','nina','A new conversation',
                 'I am visiting the showcase. What has caught your attention?',
                 [('The campus game and its choices','talk:nina.presentation'),('I am curious about the societies','talk:events.home'),('See you around','talk:close')])


class ConversationController:
    def __init__(self, game):
        self.game = game
        self.book = ConversationBook()
        self.stack = []
        self.current = None
        self.pending_return = None

    @property
    def active(self):
        return self.current is not None

    def clear(self):
        self.stack.clear()
        self.current = None
        self.pending_return = None

    def start(self, key):
        self.clear()
        self.show(key, push=False)

    def show(self, key, push=True):
        node=self.book.nodes.get(key)
        if node is None:
            return False
        if push and key in self.stack:
            self.stack=self.stack[:self.stack.index(key)]
        elif push and self.current is not None and self.current != key:
            self.stack.append(self.current)
        self.current=key
        text=node.text(self.game.state) if callable(node.text) else node.text
        self.game.dialogue.show(node.speaker,text,node.choices,node.portrait,back_action='talk:back',topic=node.title)
        flag='talk:'+key+':read'
        if not self.game.state.flags.get(flag):
            self.game.state.flags[flag]=1
            self.game.state.history.append({'chapter':self.game.state.chapter,'action':'conversation',
                                            'npc':node.speaker,'topic':key,'title':node.title,
                                            'text':text,'time':self.game.state.clock})
        return True

    def back(self):
        if self.stack:
            previous=self.stack.pop()
            self.show(previous,push=False)
        else:
            self.clear()
            self.game.dialogue.close()

    def handle(self, action):
        if not action.startswith('talk:'):
            return False
        target=action[5:]
        if target=='back':
            self.back()
        elif target=='close':
            self.clear();self.game.dialogue.close()
        elif target in self.book.nodes:
            if self.active:
                self.show(target)
            else:
                self.start(target)
        return True

    def leave_for_activity(self):
        if self.active:
            self.pending_return=self.current

    def return_choices(self):
        if self.pending_return:
            key=self.pending_return
            self.pending_return=None
            return [('I have another question','talk:'+key),('Thanks, goodbye','talk:close')]
        return [('CONTINUE','')]
