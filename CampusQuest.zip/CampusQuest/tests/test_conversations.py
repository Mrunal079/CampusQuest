"""Real branching dialogue, pagination, follow-ups and saved explanations."""
import os
os.environ.setdefault('SDL_VIDEODRIVER','dummy')
os.environ.setdefault('SDL_AUDIODRIVER','dummy')
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
import pygame
from conversations import ConversationBook, STUDENT_PROFILES
from game import Game


class ConversationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.game=Game(headless=True,save_path=Path(self.temp.name)/'save.json')
        self.game.new_game();self.game.dialogue.close()
        self.keys=defaultdict(bool)

    def tearDown(self):
        pygame.quit();self.temp.cleanup()

    def key(self,key):
        self.game.handle_event(pygame.event.Event(pygame.KEYDOWN,key=key))

    def read(self):
        d=self.game.dialogue
        for _ in range(20):
            d.visible=len(d.text)
            self.game.draw()
            if d.page_index==len(d.pages)-1:
                return
            self.key(pygame.K_RETURN)
        self.fail('Dialogue has no reachable last page')

    def choose(self,action):
        self.read()
        d=self.game.dialogue
        actions=[c.action for c in d.choices]
        self.assertIn(action,actions)
        d.selected=0
        for _ in range(actions.index(action)):
            self.key(pygame.K_DOWN)
        self.key(pygame.K_RETURN)

    def test_every_shipped_resident_has_a_distinct_profile_and_valid_links(self):
        book=ConversationBook()
        self.assertEqual(len({book.root_for(key) for key in STUDENT_PROFILES}),len(STUDENT_PROFILES))
        first_answers=set()
        for name in STUDENT_PROFILES:
            self.game.npc_dialogue(name)
            first_answers.add(self.game.dialogue.text)
            self.assertEqual(self.game.dialogue.speaker,STUDENT_PROFILES[name][0])
        self.assertEqual(len(first_answers),len(STUDENT_PROFILES))
        for key,node in book.nodes.items():
            self.assertLessEqual(len(node.choices),7)
            for label,action in node.choices:
                if action.startswith('talk:') and action not in ('talk:close','talk:back'):
                    self.assertIn(action[5:],book.nodes,(key,label))

    def test_barista_practice_is_optional_and_returns_to_the_conversation(self):
        self.game.npc_dialogue('barista')
        self.choose('talk:cafe.shift')
        before_stats = dict(self.game.state.stats)
        before_clock = self.game.state.clock
        self.choose('puzzle:route')
        self.assertIsNotNone(self.game.puzzle)
        self.key(pygame.K_ESCAPE)
        self.choose('talk:cafe.shift')
        self.assertEqual(self.game.conversations.current, 'cafe.shift')
        self.assertEqual(self.game.state.stats, before_stats)
        self.assertEqual(self.game.state.clock, before_clock)
        self.assertFalse(self.game.state.flags.get('7:money_shift'))

    def test_resume_questions_have_examples_and_no_passive_stat_reward(self):
        self.game.npc_dialogue('adviser')
        before_stats=dict(self.game.state.stats);before_clock=self.game.state.clock
        self.choose('talk:career.resume')
        self.choose('talk:career.projects')
        self.assertGreater(len(self.game.dialogue.pages),1)
        self.read()
        self.choose('talk:career.before_after')
        self.assertIn('Before:','\n'.join(self.game.dialogue.pages))
        self.assertIn('After:','\n'.join(self.game.dialogue.pages))
        self.assertEqual(self.game.state.stats,before_stats)
        self.assertEqual(self.game.state.clock,before_clock)
        self.choose('talk:career.resume')
        self.assertEqual(self.game.conversations.current,'career.resume')
        self.assertEqual(self.game.conversations.stack,['career.home'])
        self.key(pygame.K_ESCAPE)
        self.assertEqual(self.game.conversations.current,'career.home')
        self.key(pygame.K_ESCAPE)
        self.assertFalse(self.game.dialogue.open)
        self.assertFalse(self.game.conversations.active)

    def test_resume_review_is_explicit_and_returns_to_followup_questions(self):
        self.game.activity_dialogue('career')
        self.choose('talk:career.resume')
        self.choose('talk:career.review')
        self.assertFalse(self.game.state.flags.get('resume_reviewed'))
        clock=self.game.state.clock
        self.choose('career_resume')
        self.assertTrue(self.game.state.flags['resume_reviewed'])
        self.assertEqual(self.game.state.clock,clock+45)
        self.assertEqual(self.game.dialogue.portrait,'adviser')
        self.choose('talk:career.review')
        self.assertEqual(self.game.conversations.current,'career.review')
        self.choose('talk:career.resume')
        self.choose('talk:career.skills')
        self.assertIn('skills','\n'.join(self.game.dialogue.pages).lower())

    def test_interview_responses_have_different_feedback_before_activity(self):
        self.game.npc_dialogue('adviser')
        self.choose('talk:career.interview')
        self.choose('talk:career.answer_solo')
        solo='\n'.join(self.game.dialogue.pages)
        self.choose('talk:career.home')
        self.choose('talk:career.interview')
        self.choose('talk:career.answer_beginner')
        beginner='\n'.join(self.game.dialogue.pages)
        self.assertNotEqual(solo,beginner)
        self.assertIn('course project',beginner.lower())
        self.assertFalse(self.game.state.flags.get('interview_completed'))

    def test_all_topics_render_without_cutting_off_pages_or_exceeding_width(self):
        stats=dict(self.game.state.stats);clock=self.game.state.clock
        for key in self.game.conversations.book.nodes:
            with self.subTest(topic=key):
                self.game.conversations.start(key)
                d=self.game.dialogue
                for page in d.pages:
                    self.assertLessEqual(len(page.split('\n')),4)
                    self.assertTrue(all(self.game.assets.font(15).size(line)[0]<=735 for line in page.split('\n')))
                self.read()
        self.assertEqual(self.game.state.stats,stats)
        self.assertEqual(self.game.state.clock,clock)

    def test_mouse_can_advance_a_page_and_choose_a_followup(self):
        self.game.conversations.start('career.projects')
        d=self.game.dialogue
        self.assertGreater(len(d.pages),1)
        for _ in range(8):
            d.visible=len(d.text);self.game.draw()
            if d.page_index==len(d.pages)-1:
                break
            rect=d.choice_rects[0]
            self.game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=rect.center))
        actions=[c.action for c in d.choices]
        index=actions.index('talk:career.before_after')
        rect=d.choice_rects[index]
        self.game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,button=1,pos=rect.center))
        self.assertEqual(self.game.conversations.current,'career.before_after')

    def test_journal_records_once_survives_continue_and_has_back_navigation(self):
        self.game.npc_dialogue('adviser');self.choose('talk:career.resume');self.choose('talk:career.projects')
        self.read()
        count=sum(entry.get('topic')=='career.projects' for entry in self.game.state.history)
        self.game.conversations.show('career.projects')
        self.assertEqual(sum(entry.get('topic')=='career.projects' for entry in self.game.state.history),count)
        self.game.conversations.clear();self.game.dialogue.close()
        self.game.save_game();self.game.new_game();self.game.load_game()
        self.game.phone.show('messages');self.game.phone.navigate('conversations')
        self.game.phone.navigate('contact:Imani / Career adviser')
        self.game.phone.navigate('transcript:career.projects')
        self.game.phone.animation=1;self.game.draw()
        self.assertEqual(self.game.phone.screen,'transcript:career.projects')
        self.key(pygame.K_ESCAPE)
        self.assertEqual(self.game.phone.screen,'contact:Imani / Career adviser')
        self.key(pygame.K_ESCAPE)
        self.assertEqual(self.game.phone.screen,'conversations')
        self.assertTrue(any(entry.get('topic')=='career.projects' for entry in self.game.state.history))

    def test_support_and_health_explanations_follow_current_story_status(self):
        self.game.state.support_status='MORE INFORMATION REQUIRED'
        self.game.npc_dialogue('support');self.choose('talk:support.assessment')
        self.assertIn('MORE INFORMATION REQUIRED','\n'.join(self.game.dialogue.pages))
        self.game.npc_dialogue('receptionist');self.choose('talk:health.document')
        self.assertIn('Follow-up Note','\n'.join(self.game.dialogue.pages))
        self.assertNotIn('Follow-up Note',self.game.state.inventory)

    def test_real_student_names_appear_on_the_interaction_prompt(self):
        self.game.world.load('campus')
        names={npc.id:npc.interaction()['label'] for npc in self.game.world.npcs}
        for key in STUDENT_PROFILES:
            if key in names:
                self.assertIn(STUDENT_PROFILES[key][0],names[key])
                self.assertNotEqual(names[key],'Talk to Student')

    def test_reading_greeting_again_remembers_previous_visit(self):
        self.game.npc_dialogue('adviser')
        first='\n'.join(self.game.dialogue.pages)
        self.game.conversations.clear();self.game.dialogue.close()
        self.game.npc_dialogue('adviser')
        second='\n'.join(self.game.dialogue.pages)
        self.assertNotEqual(first,second)
        self.assertIn('Welcome back',second)

    def test_replaying_a_chapter_keeps_the_conversation_journal(self):
        self.game.npc_dialogue('adviser')
        self.choose('talk:career.resume')
        self.choose('talk:career.skills')
        self.game.state.replay_chapter()
        self.assertEqual(self.game.state.flags['talk:career.skills:read'],1)
        self.assertTrue(any(entry.get('topic')=='career.skills' for entry in self.game.state.history))

    def test_people_do_not_walk_away_while_a_conversation_is_open(self):
        npc=next(n for n in self.game.world.npcs if n.id=='nina')
        npc.pos.update(self.game.world.spawn);npc.rect.center=npc.pos
        npc.velocity.update(20,0);npc.timer=10
        self.game.npc_dialogue('nina')
        before=npc.pos.copy()
        self.game.update(.05,self.keys)
        self.assertEqual(npc.pos,before)
        self.key(pygame.K_ESCAPE)
        self.game.update(.05,self.keys)
        self.assertGreater(npc.pos.x,before.x)


if __name__=='__main__':
    unittest.main()
