"""Integration regressions for chapter transitions and saved encounters."""
import os
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

from collections import defaultdict
import json
import math
from pathlib import Path
import tempfile
import unittest

import pygame

from demo_tools import DEMO_ROUTES, prepare_chapter
from game import Game


class JourneyRegressionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.game = Game(headless=True, save_path=Path(self.temporary.name) / "journey.json")
        self.no_keys = defaultdict(bool)

    def tearDown(self):
        pygame.quit()
        self.temporary.cleanup()

    def finish_fade(self):
        for _ in range(4):
            if not self.game.transition:
                break
            self.game.update(.25, self.no_keys)
        self.assertIsNone(self.game.transition)

    def test_chapter_transition_autosaves_arrival_location(self):
        self.game.new_game()
        self.game.dialogue.close()
        self.game.world.load("library")
        self.game.player.teleport(*self.game.world.spawn)
        for action in DEMO_ROUTES[1]:
            self.game.state.perform(action)
        self.assertTrue(self.game.state.chapter_complete)
        self.game.mode = "complete"
        self.game._menu_action("next")
        self.finish_fade()
        expected_position = list(self.game.player.pos)
        saved_state, location = self.game.saves.load()
        self.assertEqual(saved_state.chapter, 2)
        self.assertEqual(location["map_id"], "campus")
        self.assertEqual(location["position"], expected_position)
        self.game.dialogue.close()
        self.game.load_game()
        self.assertEqual(self.game.world.map_id, "campus")
        self.assertEqual(list(self.game.player.pos), expected_position)

    def test_all_presentation_entries_are_playable_and_have_clean_modal_state(self):
        for chapter in range(1, 9):
            with self.subTest(chapter=chapter):
                prepare_chapter(self.game, chapter)
                self.assertEqual(self.game.state.chapter, chapter)
                self.assertFalse(self.game.state.chapter_complete)
                self.assertEqual(self.game.mode, "play")
                self.assertEqual(self.game.world.map_id, "campus")
                self.assertIsNone(self.game.state.events.pending)
                self.assertFalse(self.game.event_queue)
                self.assertFalse(self.game.world.is_blocked(self.game.player.rect))
                self.game.dialogue.close()
                for action in DEMO_ROUTES[chapter]:
                    self.assertTrue(self.game.state.perform(action)["ok"])
                    if self.game.state.events.pending:
                        self.game.state.resolve_event(self.game.state.events.pending, 0)
                self.assertTrue(self.game.state.chapter_complete)

    def test_pending_encounter_is_restored_and_can_be_resolved(self):
        self.game.new_game()
        self.game.dialogue.close()
        self.game.state.events.pending = "free_food"
        self.assertTrue(self.game.save_game())
        self.game.state.events.pending = None
        self.game.event_queue.clear()
        self.game.load_game()
        self.assertEqual(self.game.state.events.pending, "free_food")
        self.assertEqual([e["id"] for e in self.game.event_queue], ["free_food"])
        self.game.update(.01, self.no_keys)
        self.assertTrue(self.game.dialogue.open)
        action = self.game.dialogue.choices[0].action
        self.assertEqual(action, "event:free_food:0")
        self.game.dialogue.close()
        self.game.do_action(action)
        self.assertIsNone(self.game.state.events.pending)
        self.assertFalse(self.game.event_queue)

    def test_invalid_saved_coordinates_do_not_poison_running_player(self):
        self.game.new_game()
        self.game.dialogue.close()
        original_position = list(self.game.player.pos)
        original_map = self.game.world.map_id
        self.game.save_game()
        payload = json.loads(self.game.saves.path.read_text())
        payload["world"]["position"] = ["nan", "nan"]
        self.game.saves.path.write_text(json.dumps(payload))
        self.game.load_game()
        self.assertTrue(all(math.isfinite(n) for n in self.game.player.pos))
        self.assertEqual(list(self.game.player.pos), original_position)
        self.assertEqual(self.game.world.map_id, original_map)
        self.game.dialogue.close()
        self.game.update(.01, self.no_keys)
        self.game.draw()


if __name__ == "__main__":
    unittest.main()
