"""Meaningful regression checks for story progression and safe persistence."""

import json
from pathlib import Path
import tempfile
import unittest

from game_state import GameState
from save_system import SaveError, SaveManager


class StoryTests(unittest.TestCase):
    DEMO_PATH = {
        1: ["visit_library", "visit_lecture_hall", "study"],
        2: ["study", "rest"],
        3: ["group_message", "group_continue"],
        4: ["health", "rest"],
        5: ["support_submit", "wait", "wait", "wait", "health", "support_attach", "wait", "wait"],
        6: ["revision", "revision", "quiz", "rest", "exam"],
        7: ["money_shift", "budget", "festival"],
        8: ["career_resume", "career_network", "career_interview"],
    }

    def complete_chapter(self, state):
        for action in self.DEMO_PATH[state.chapter]:
            result = state.perform(action)
            self.assertTrue(result["ok"], (action, result))
        self.assertTrue(state.chapter_complete, state.objectives)

    def test_all_eight_chapters_with_save_roundtrips(self):
        state = GameState()
        for chapter in range(1, 9):
            self.assertEqual(state.chapter, chapter)
            self.complete_chapter(state)
            self.assertTrue(all(q["completed"] for q in state.objectives if not q["optional"]))
            self.assertEqual(len(state.stars[str(chapter)]), 4)
            self.assertGreaterEqual(sum(state.stars[str(chapter)]), 4)
            state = GameState.from_dict(json.loads(json.dumps(state.to_dict())))
            if chapter < 8:
                self.assertIn(chapter + 1, state.unlocked_levels)
                self.assertTrue(state.next_chapter()["ok"])
        self.assertTrue(state.finished)
        self.assertEqual(len(state.stars), 8)

    def test_support_requires_document_and_requested_followup(self):
        state = GameState()
        self.assertFalse(state.perform("support_submit")["ok"])
        state.perform("health")
        self.assertIn("Supporting Document", state.inventory)
        self.assertTrue(state.perform("support_submit")["ok"])
        self.assertEqual(state.support_status, "SUBMITTED")
        state.advance_time(30)
        self.assertEqual(state.support_status, "UNDER REVIEW")
        state.advance_time(45)
        self.assertEqual(state.support_status, "MORE INFORMATION REQUIRED")
        state.advance_time(10000)
        self.assertEqual(state.support_status, "MORE INFORMATION REQUIRED")
        self.assertFalse(state.perform("support_attach")["ok"])
        state.perform("health")
        self.assertIn("Follow-up Note", state.inventory)
        self.assertTrue(state.perform("support_attach")["ok"])
        self.assertEqual(state.support_status, "UNDER REVIEW")
        state.advance_time(45)
        self.assertEqual(state.support_status, "APPROVED")
        self.assertTrue(any("MORE INFORMATION REQUIRED" in m["text"] for m in state.messages))

    def test_zero_energy_and_money_always_have_recovery(self):
        state = GameState()
        state.stats["energy"] = 0
        state.stats["money"] = 0
        clock = state.clock
        self.assertFalse(state.perform("study")["ok"])
        self.assertFalse(state.perform("snack")["ok"])
        self.assertEqual(state.clock, clock)
        self.assertEqual(state.assignments["python"]["progress"], 0)
        self.assertTrue(state.perform("rest")["ok"])
        self.assertGreater(state.stats["energy"], 0)
        self.assertTrue(state.perform("study")["ok"])
        self.assertEqual(state.stats["money"], 0)

    def test_chapter_four_disruption_and_replay_checkpoint(self):
        state = GameState()
        for _ in range(3):
            self.complete_chapter(state)
            state.next_chapter()
        self.assertEqual(state.chapter, 4)
        self.assertEqual(state.stats["health"], 40)
        self.assertEqual(state.stats["energy"], 35)
        self.complete_chapter(state)
        earned = dict(state.stars)
        state.replay_chapter()
        self.assertEqual(state.chapter, 4)
        self.assertFalse(state.chapter_complete)
        self.assertEqual(state.stats["health"], 40)
        self.assertEqual(state.stars, earned)
        self.assertNotIn("checkpoint", state.checkpoint)
        self.complete_chapter(state)

    def test_all_encounters_resolve_and_stale_choice_is_rejected(self):
        state = GameState()
        self.assertEqual(len(state.events.events), 17)
        for event in state.events.events:
            state.events.pending = event.id
            payload = event.payload()
            result = state.perform(payload["choices"][0]["action"])
            self.assertTrue(result["ok"], event.id)
            self.assertIsNone(state.events.pending)
            self.assertFalse(state.perform(payload["choices"][0]["action"])["ok"])
            self.assertTrue(all(value >= 0 for value in state.stats.values()))


class SaveTests(unittest.TestCase):
    def test_atomic_roundtrip_preserves_location_and_state(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = SaveManager(Path(directory) / "save.json")
            state = GameState()
            state.perform("study")
            location = {"map": "library", "player": [212.5, 340.0]}
            self.assertFalse(manager.exists)
            self.assertTrue(manager.save(state, location))
            self.assertTrue(manager.exists)
            loaded, world = manager.load()
            self.assertEqual(loaded.to_dict(), state.to_dict())
            self.assertEqual(world, location)

    def test_corrupt_file_is_not_overwritten_on_load(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "save.json"
            original = "{this is not valid JSON"
            path.write_text(original)
            with self.assertRaises(SaveError):
                SaveManager(path).load()
            self.assertEqual(path.read_text(), original)

    def test_invalid_save_keeps_old_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "save.json"
            manager = SaveManager(path)
            state = GameState()
            manager.save(state, {"map": "campus"})
            original = path.read_bytes()
            state.stats["energy"] = -100
            with self.assertRaises(SaveError):
                manager.save(state, {"map": "campus"})
            self.assertEqual(path.read_bytes(), original)

    def test_unsupported_version_has_clear_error(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "save.json"
            path.write_text(json.dumps({"version": 999}))
            with self.assertRaisesRegex(SaveError, "unsupported"):
                SaveManager(path).load()


if __name__ == "__main__":
    unittest.main()
