"""Exercise real challenge input, rewards, cancellation and saved records.

The solver helpers inspect a puzzle's public board, then use the same Pygame
mouse/key events as a player. They never set completion or grant rewards.
"""

import os
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

from collections import defaultdict
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pygame

from game import Game
from puzzle_ui import PuzzleScreen


class ChallengeIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="campus-challenge-test-")
        self.save_path = Path(self.temporary.name) / "journey.json"
        self.game = Game(headless=True, save_path=self.save_path)
        self.no_keys = defaultdict(bool)
        self.game.new_game()
        self.key(pygame.K_ESCAPE)

    def tearDown(self):
        pygame.quit()
        self.temporary.cleanup()

    def key(self, key):
        self.game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=key))

    def click(self, targets, action):
        matches = [rect for rect, target in targets if target == action]
        self.assertTrue(matches, f"Missing input target: {action}")
        self.game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN,
                                                button=1, pos=matches[0].center))

    def choose(self, action):
        """Use the dialogue's real arrow/Enter routing."""
        self.assertTrue(self.game.dialogue.open)
        actions = [choice.action for choice in self.game.dialogue.choices]
        self.assertIn(action, actions)
        self.key(pygame.K_RETURN)  # Reveal the question before choosing.
        for _ in range(actions.index(action)):
            self.key(pygame.K_DOWN)
        self.key(pygame.K_RETURN)

    def start(self, kind):
        self.key(pygame.K_F3)
        self.assertEqual({choice.action for choice in self.game.dialogue.choices
                          if choice.action.startswith("puzzle:")},
                         {"puzzle:memory", "puzzle:route", "puzzle:code"})
        self.choose("puzzle:" + kind)
        self.assertIsInstance(self.game.puzzle, PuzzleScreen)
        self.assertEqual(self.game.puzzle.kind, kind)
        self.assertFalse(self.game.dialogue.open)
        self.game.draw()
        return self.game.puzzle

    def select_card(self, index, mouse=False):
        puzzle = self.game.puzzle
        if mouse:
            self.game.draw()
            self.click(puzzle.targets, f"card:{index}")
            return
        if puzzle.kind == "memory":
            while puzzle.cursor // 4 != index // 4:
                self.key(pygame.K_DOWN)
            while puzzle.cursor % 4 != index % 4:
                self.key(pygame.K_RIGHT)
        else:
            while puzzle.cursor != index:
                self.key(pygame.K_DOWN)
        self.key(pygame.K_RETURN)

    def solve_memory(self):
        puzzle = self.game.puzzle
        self.game.update(2.0, self.no_keys)
        pairs = [[i for i, card in enumerate(puzzle.model.cards) if card == icon]
                 for icon in sorted(set(puzzle.model.cards))]
        for index, pair in enumerate(pairs):
            self.select_card(pair[0], mouse=index == 0)
            self.select_card(pair[1], mouse=index == 0)
        self.assertTrue(puzzle.model.complete)
        self.game.draw()

    def solve_cafe(self):
        puzzle = self.game.puzzle
        self.key(pygame.K_RIGHT)  # Serve a different ticket first.
        for index in range(6):
            recipe = puzzle.model.recipes[puzzle.model.current['drink']]
            for ingredient in recipe:
                if index == 0:
                    self.game.draw()
                    self.click(puzzle.targets, f'ingredient:{ingredient}')
                else:
                    self.key(pygame.K_1 + ingredient)
            if index == 0:
                self.game.draw()
                self.click(puzzle.targets, 'serve')
            else:
                self.key(pygame.K_SPACE)
        self.assertTrue(puzzle.model.complete)
        self.assertEqual(puzzle.model.served, 6)
        self.game.draw()

    def solve_code(self):
        puzzle = self.game.puzzle
        swaps = 0
        for round_index in range(3):
            self.assertEqual(puzzle.model.round_index, round_index)
            correct = puzzle.model.rounds[round_index]["lines"]
            for index, line in enumerate(correct):
                if puzzle.model.lines[index] != line:
                    other = puzzle.model.lines.index(line)
                    self.select_card(index, mouse=swaps == 0)
                    self.select_card(other, mouse=swaps == 0)
                    swaps += 1
            self.game.draw()
            self.assertEqual(puzzle.model.lines, correct)
            self.key(pygame.K_c)
        self.assertTrue(puzzle.model.complete)
        self.assertGreater(swaps, 0)
        self.game.draw()

    def claim(self, mouse=False):
        self.game.draw()
        if mouse:
            self.click(self.game.puzzle.targets, "claim")
        else:
            self.key(pygame.K_RETURN)
        self.assertIsNone(self.game.puzzle)
        self.assertTrue(self.game.dialogue.open)

    def test_all_three_render_hint_restart_and_cancel_without_world_changes(self):
        for kind in ("memory", "route", "code"):
            with self.subTest(kind=kind):
                original = deepcopy(self.game.state.to_dict())
                position = tuple(self.game.player.pos)
                puzzle = self.start(kind)
                self.game.update(2, self.no_keys)
                self.key(pygame.K_h)
                self.game.draw()
                self.assertEqual(puzzle.model.hints, 1)
                self.key(pygame.K_r)
                self.assertEqual(puzzle.model.hints, 0)
                self.assertFalse(puzzle.model.complete)
                self.game.draw()
                self.key(pygame.K_ESCAPE)
                self.assertIsNone(self.game.puzzle)
                self.assertEqual(self.game.state.to_dict(), original)
                self.assertEqual(tuple(self.game.player.pos), position)
                self.key(pygame.K_ESCAPE)  # Dismiss the hub before next entry.

    def test_memory_mouse_and_keyboard_solution_claims_once(self):
        state = self.game.state
        before_energy = state.stats["energy"]
        before_clock = state.clock
        puzzle = self.start("memory")
        self.solve_memory()
        self.assertEqual(state.clock, before_clock)
        self.assertNotIn("challenge:memory:cleared", state.flags)
        self.claim(mouse=True)
        self.assertEqual(state.stats["energy"], min(100, before_energy + 12))
        self.assertEqual(state.clock, before_clock + 20)
        self.assertEqual(state.flags["challenge:memory:cleared"], 1)
        self.assertEqual(state.flags["challenge:memory:best"], puzzle.model.score)
        after_claim = deepcopy(state.to_dict())
        self.assertIsNone(puzzle.handle(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN)))
        self.game.finish_challenge({"action": "complete"})
        self.assertEqual(state.to_dict(), after_claim)

    def test_cafe_mouse_and_keyboard_serving_grants_planning_boost(self):
        state = self.game.state
        before_clock = state.clock
        before_focus = state.stats["focus"]
        self.start("route")
        self.solve_cafe()
        self.assertEqual(state.clock, before_clock)
        self.assertNotIn("study_boost", state.flags)
        self.claim(mouse=True)
        self.assertEqual(state.clock, before_clock + 15)
        self.assertEqual(state.stats["focus"], min(100, before_focus + 8))
        self.assertEqual(state.flags["study_boost"], 5)

    def test_cafe_wrong_recipe_undo_clear_and_ticket_click_are_playable(self):
        puzzle = self.start('route')
        self.click(puzzle.targets, 'order:1')
        self.assertEqual(puzzle.model.selected, 1)
        self.key(pygame.K_1)
        self.key(pygame.K_BACKSPACE)
        self.assertEqual(puzzle.model.cup, [])
        self.key(pygame.K_2)
        self.key(pygame.K_c)
        self.assertEqual(puzzle.model.cup, [])
        self.key(pygame.K_1)
        self.key(pygame.K_SPACE)
        self.assertEqual(puzzle.model.mistakes, 1)
        self.assertFalse(puzzle.model.complete)
        self.game.draw()
        self.key(pygame.K_h)
        self.key(pygame.K_SPACE)
        self.assertEqual(puzzle.model.served, 1)
        self.key(pygame.K_ESCAPE)
        self.assertNotIn('challenge:route:cleared', self.game.state.flags)

    def test_three_code_rounds_are_required_before_project_progress(self):
        state = self.game.state
        before_progress = state.assignments["python"]["progress"]
        before_clock = state.clock
        puzzle = self.start("code")
        self.key(pygame.K_c)
        self.assertEqual(puzzle.model.mistakes, 1)
        self.solve_code()
        self.assertEqual(state.assignments["python"]["progress"], before_progress)
        self.assertEqual(state.clock, before_clock)
        expected = min(100, before_progress + 10 + puzzle.model.score * 2)
        self.claim(mouse=True)
        self.assertEqual(state.assignments["python"]["progress"], expected)
        self.assertEqual(state.clock, before_clock + 45)
        self.assertEqual(state.flags["challenge:code:cleared"], 1)

    def test_phone_home_entry_cancel_and_claim_restore_back_stack(self):
        self.key(pygame.K_TAB)
        self.game.update(.2, self.no_keys)
        self.game.draw()
        self.click(self.game.phone.targets, "app:challenges")
        self.assertEqual(self.game.phone.stack, ["home", "challenges"])
        self.game.draw()
        self.click(self.game.phone.targets, "puzzle:memory")
        self.assertFalse(self.game.phone.open)
        self.assertIsNotNone(self.game.puzzle)
        self.key(pygame.K_ESCAPE)
        self.assertTrue(self.game.phone.open)
        self.assertEqual(self.game.phone.stack, ["home", "challenges"])
        self.key(pygame.K_ESCAPE)  # Close cancellation/hub dialogue.
        self.game.draw()
        self.click(self.game.phone.targets, "puzzle:memory")
        self.solve_memory()
        self.claim()
        self.assertTrue(self.game.phone.open)
        self.assertEqual(self.game.phone.stack, ["home", "challenges"])
        self.key(pygame.K_ESCAPE)  # Close reward, then back one app screen.
        self.key(pygame.K_ESCAPE)
        self.assertTrue(self.game.phone.open)
        self.assertEqual(self.game.phone.stack, ["home"])
        self.key(pygame.K_ESCAPE)
        self.assertFalse(self.game.phone.open)

    def test_forged_result_cannot_bypass_actual_puzzle_completion(self):
        original = deepcopy(self.game.state.to_dict())
        self.start("memory")
        self.game.finish_challenge({"action": "complete", "kind": "memory", "score": 3, "hints": 0})
        self.assertEqual(self.game.state.to_dict(), original)
        self.assertIsNone(self.game.puzzle)

    def test_letter_shortcut_and_replayed_practice_show_no_second_daily_reward(self):
        self.key(pygame.K_b)
        self.choose('puzzle:memory')
        self.solve_memory()
        self.claim()
        self.key(pygame.K_ESCAPE)
        before_stats = dict(self.game.state.stats)
        before_clock = self.game.state.clock
        self.key(pygame.K_b)
        self.choose('puzzle:memory')
        self.assertFalse(self.game.puzzle.reward_available)
        self.solve_memory()
        self.game.draw()  # Practice result uses a record-saving message.
        self.claim()
        self.assertEqual(self.game.state.stats,before_stats)
        self.assertEqual(self.game.state.clock,before_clock+20)
        self.assertEqual(self.game.state.flags['challenge:memory:attempts'],2)

    def test_challenge_records_survive_continue_and_older_saves_still_load(self):
        self.start("memory")
        self.solve_memory()
        self.claim()
        saved_records = [dict(record) for record in self.game.state.challenge_summary]
        self.assertTrue(self.game.save_game())
        self.game.new_game()
        self.game.dialogue.close()
        self.game._menu_action("continue")
        self.assertEqual(self.game.state.challenge_summary, saved_records)
        self.assertIsNone(self.game.puzzle)

        # Pre-challenge saves have no activity flags; no migration is required.
        payload = json.loads(self.save_path.read_text())
        payload["game"]["flags"] = {key: value for key, value in payload["game"]["flags"].items()
                                    if not key.startswith("challenge:")}
        self.save_path.write_text(json.dumps(payload))
        self.game._menu_action("continue")
        self.assertEqual([record["best"] for record in self.game.state.challenge_summary], [0, 0, 0])
        self.assertTrue(all(record["reward_available"] for record in self.game.state.challenge_summary))
        self.game.draw()


if __name__ == "__main__":
    unittest.main()
