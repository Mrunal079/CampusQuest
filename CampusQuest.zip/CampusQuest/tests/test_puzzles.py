"""Behaviour checks for actual puzzle completion, rejected input and fairness."""

import unittest

from puzzles import CodePuzzle, MemoryPuzzle, CafePuzzle


class MemoryTests(unittest.TestCase):
    def test_mismatch_waits_and_rejects_more_flips(self):
        puzzle = MemoryPuzzle(8)
        original = list(puzzle.cards)
        self.assertFalse(puzzle.select(0))
        puzzle.update(2)
        first = 0
        second = next(i for i, card in enumerate(puzzle.cards) if card != puzzle.cards[first])
        puzzle.select(first)
        self.assertFalse(puzzle.select(first))
        puzzle.select(second)
        self.assertEqual(puzzle.moves, 1)
        self.assertEqual(puzzle.mismatch_remaining, .75)
        self.assertFalse(puzzle.select(15))
        puzzle.update(.5)
        self.assertEqual(len(puzzle.revealed), 2)
        puzzle.update(.25)
        self.assertEqual(puzzle.revealed, [])
        self.assertEqual(puzzle.cards, original)

    def test_every_pair_required_and_completed_state_is_stable(self):
        puzzle = MemoryPuzzle(3)
        puzzle.update(2)
        for icon in set(puzzle.cards):
            pair = [i for i, value in enumerate(puzzle.cards) if value == icon]
            self.assertTrue(puzzle.select(pair[0]))
            self.assertTrue(puzzle.select(pair[1]))
            self.assertEqual(puzzle.complete, len(puzzle.matched) == 16)
        self.assertEqual(puzzle.moves, 8)
        self.assertEqual(puzzle.score, 3)
        elapsed = puzzle.elapsed
        self.assertFalse(puzzle.hint())
        self.assertFalse(puzzle.select(0))
        puzzle.update(10)
        self.assertEqual(puzzle.elapsed, elapsed)

    def test_hint_preview_and_reset(self):
        puzzle = MemoryPuzzle(15)
        cards = list(puzzle.cards)
        puzzle.update(2)
        self.assertTrue(puzzle.hint())
        self.assertEqual(puzzle.hints, 1)
        self.assertFalse(puzzle.select(0))
        puzzle.update(1.5)
        self.assertTrue(puzzle.select(0))
        puzzle.reset()
        self.assertEqual(puzzle.cards, cards)
        self.assertEqual(puzzle.moves, 0)
        self.assertEqual(puzzle.hints, 0)
        self.assertEqual(puzzle.preview_remaining, 2)


class CafeTests(unittest.TestCase):
    def solve(self, puzzle):
        while not puzzle.complete:
            for ingredient in puzzle.recipes[puzzle.current['drink']]:
                self.assertTrue(puzzle.add(ingredient))
            self.assertTrue(puzzle.serve())

    def test_all_seed_variants_can_finish_with_correct_recipes(self):
        signatures = set()
        for seed in range(16):
            puzzle = CafePuzzle(seed)
            signatures.add(tuple(order['drink'] for order in puzzle.orders))
            self.assertEqual(len(puzzle.orders), 6)
            self.assertEqual({order['drink'] for order in puzzle.orders}, set(puzzle.recipes))
            self.solve(puzzle)
            self.assertEqual(puzzle.served, 6)
            self.assertEqual(puzzle.moves, 6)
            self.assertEqual(puzzle.best_streak, 6)
            self.assertEqual(puzzle.score, 3)
            self.assertFalse(puzzle.add(0))
            self.assertFalse(puzzle.serve())
            self.assertFalse(puzzle.hint())
            self.assertFalse(puzzle.select_order(0))
            self.assertFalse(puzzle.undo())
            elapsed = puzzle.elapsed
            puzzle.update(100)
            self.assertEqual(puzzle.elapsed, elapsed)
        self.assertGreater(len(signatures), 8)

    def test_wrong_order_quantities_undo_clear_and_invalid_inputs(self):
        puzzle = CafePuzzle(0)
        for value in (-1, 4, True, 1.0, 'milk'):
            self.assertFalse(puzzle.add(value))
            self.assertFalse(puzzle.select_order(value))
        self.assertFalse(puzzle.serve())
        self.assertEqual(puzzle.moves, 0)
        recipe = list(puzzle.recipes[puzzle.current['drink']])
        for ingredient in reversed(recipe):
            self.assertTrue(puzzle.add(ingredient))
        self.assertFalse(puzzle.add(0))
        self.assertTrue(puzzle.undo())
        self.assertFalse(puzzle.serve())  # Two ingredients are incomplete.
        self.assertEqual(puzzle.mistakes, 1)
        self.assertEqual(puzzle.served, 0)
        self.assertEqual(puzzle.cup, [])
        for ingredient in reversed(recipe):
            puzzle.add(ingredient)
        self.assertTrue(puzzle.serve())  # Pouring order is deliberately irrelevant.
        puzzle.add(0)
        self.assertTrue(puzzle.clear())
        self.assertFalse(puzzle.undo())
        self.assertFalse(puzzle.clear())
        self.assertEqual(puzzle.score, 2)

    def test_reading_time_is_free_and_expired_customers_remain_finishable(self):
        puzzle = CafePuzzle(2)
        puzzle.update(200)
        self.assertEqual(puzzle.late, 0)
        self.assertTrue(all(o['patience'] == 45 for o in puzzle.queue))
        puzzle.add(0)
        puzzle.update(46)
        self.assertEqual(puzzle.late, 3)
        self.assertEqual(len(puzzle.queue), 3)
        self.assertTrue(all(o['patience'] == 44 for o in puzzle.queue))
        puzzle.clear()
        self.solve(puzzle)
        self.assertEqual(puzzle.score, 2)
        self.assertEqual(puzzle.served, 6)

    def test_queue_selection_hints_and_reset_are_deterministic(self):
        puzzle = CafePuzzle(9)
        initial = [(o['name'], o['drink']) for o in puzzle.orders]
        self.assertTrue(puzzle.select_order(2))
        name = puzzle.current['name']
        self.assertTrue(puzzle.hint())
        self.assertEqual(puzzle.hints, 1)
        self.assertFalse(puzzle.complete)  # Assistance cannot claim completion.
        self.assertTrue(puzzle.serve())
        self.assertNotIn(name, [o['name'] for o in puzzle.queue])
        self.assertEqual(len(puzzle.queue), 3)
        puzzle.reset()
        self.assertEqual([(o['name'], o['drink']) for o in puzzle.orders], initial)
        self.assertEqual(puzzle.served, 0)
        self.assertEqual(puzzle.cup, [])
        self.assertFalse(puzzle.started)
        self.assertEqual(puzzle.hints, 0)

    def test_large_frame_and_zero_boundary_keep_patience_valid(self):
        puzzle = CafePuzzle()
        puzzle.add(0)
        puzzle.update(90)
        self.assertEqual(puzzle.late, 6)
        self.assertTrue(all(o['patience'] == 45 for o in puzzle.queue))
        puzzle.update(0)
        self.assertEqual(puzzle.late, 6)
        puzzle.clear()
        self.solve(puzzle)
        self.assertEqual(puzzle.score, 1)


class CodeTests(unittest.TestCase):
    def test_wrong_check_hints_and_three_rounds(self):
        puzzle = CodePuzzle(7)
        self.assertEqual(len(puzzle.rounds), 3)
        self.assertFalse(puzzle.check())
        self.assertEqual(puzzle.mistakes, 1)
        for round_index in range(3):
            self.assertEqual(puzzle.round_index, round_index)
            while puzzle.lines != puzzle.rounds[round_index]["lines"]:
                self.assertTrue(puzzle.hint())
            self.assertFalse(puzzle.complete)
            self.assertTrue(puzzle.check())
        self.assertTrue(puzzle.complete)
        self.assertFalse(puzzle.select(0))
        self.assertFalse(puzzle.hint())
        self.assertFalse(puzzle.check())

    def test_manual_swaps_solve_every_round_without_hints(self):
        for seed in range(8):
            puzzle = CodePuzzle(seed)
            for index in range(3):
                correct = puzzle.rounds[index]["lines"]
                for slot, desired in enumerate(correct):
                    if puzzle.lines[slot] != desired:
                        other = puzzle.lines.index(desired)
                        puzzle.select(slot)
                        puzzle.select(other)
                self.assertTrue(puzzle.check())
            self.assertTrue(puzzle.complete)
            self.assertEqual(puzzle.score, 3)

    def test_selection_invalid_index_feedback_and_deterministic_reset(self):
        puzzle = CodePuzzle(2)
        original = list(puzzle.lines)
        self.assertFalse(puzzle.select(-1))
        self.assertFalse(puzzle.select(True))
        puzzle.select(0)
        self.assertEqual(puzzle.selected, 0)
        puzzle.select(0)
        self.assertIsNone(puzzle.selected)
        self.assertEqual(puzzle.moves, 0)
        puzzle.check()
        puzzle.update(3)
        self.assertEqual(puzzle.feedback, "")
        puzzle.hint()
        puzzle.reset()
        self.assertEqual(puzzle.lines, original)
        self.assertEqual(puzzle.mistakes, 0)
        self.assertEqual(puzzle.hints, 0)

    def test_invalid_frame_times_never_poison_timers(self):
        for puzzle in (MemoryPuzzle(), CafePuzzle(), CodePuzzle()):
            for dt in (float("nan"), float("inf"), -2, True, "x"):
                puzzle.update(dt)
            self.assertEqual(puzzle.elapsed, 0)


if __name__ == "__main__":
    unittest.main()
