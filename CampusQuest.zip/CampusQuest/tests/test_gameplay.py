"""Headless integration tests for real Pygame input, maps and story screens.

Run from the project folder: python3 -m unittest discover -s tests -v
The suite uses an isolated temporary save and never overwrites a player's story.
"""
import os
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

from collections import defaultdict, deque
from pathlib import Path
import math
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pygame
from game import Game
from ui import APP_NAMES


class GameplayIntegrationTests(unittest.TestCase):
    """Test the same input routing used by the running game, without a window."""

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="campus-quest-test-")
        self.save_path = Path(self.temporary.name) / "journey.json"
        self.game = Game(headless=True, save_path=self.save_path)
        self.no_keys = defaultdict(bool)

    def tearDown(self):
        pygame.quit()
        self.temporary.cleanup()

    def key(self, key):
        self.game.handle_event(pygame.event.Event(pygame.KEYDOWN, key=key))

    def begin(self):
        # Start through the actual title-screen target and keyboard handler.
        self.game.draw()
        self.assertEqual(self.game.mode, "title")
        self.game.selection = next(i for i, (_, action) in enumerate(self.game.menu_targets) if action == "new")
        self.key(pygame.K_RETURN)
        self.assertEqual(self.game.mode, "play")
        self.assertTrue(self.game.dialogue.open)
        self.key(pygame.K_ESCAPE)
        self.assertFalse(self.game.dialogue.open)

    def finish_transition(self):
        for _ in range(4):
            if self.game.transition is None:
                break
            self.game.update(.25, self.no_keys)
        self.assertIsNone(self.game.transition)

    def settle(self):
        """Dismiss results, resolve queued encounters, then let completion run."""
        self.game.phone.open = False
        for _ in range(12):
            if self.game.transition:
                self.finish_transition()
            if self.game.dialogue.open:
                event_choices = [choice for choice in self.game.dialogue.choices if choice.action.startswith("event:")]
                if event_choices:
                    self.choose(event_choices[0].action)
                else:
                    self.key(pygame.K_ESCAPE)
            self.game.update(.02, self.no_keys)
            if not self.game.dialogue.open and not self.game.event_queue and not self.game.transition:
                return
        self.fail("A result or queued campus event did not finish")

    def choose(self, action):
        """Choose an existing dialogue branch using arrows and Enter."""
        self.assertTrue(self.game.dialogue.open)
        for _ in range(12):
            if self.game.dialogue.page_index == len(self.game.dialogue.pages)-1:
                break
            self.game.dialogue.visible = len(self.game.dialogue.text)
            self.key(pygame.K_RETURN)
        actions = [choice.action for choice in self.game.dialogue.choices]
        routes={
            'quiz':['talk:tutor.assessments'], 'exam':['talk:tutor.assessments'],
            'money_shift':['talk:cafe.shift'], 'budget':['talk:support.more'],
            'career_resume':['talk:career.resume','talk:career.review'],
            'career_network':['talk:career.network','talk:career.pitch_good'],
            'career_interview':['talk:career.interview','talk:career.answer_clear'],
        }
        if action not in actions and action in routes:
            for branch in routes[action]:
                self.choose(branch)
            self.choose(action)
            return
        self.assertIn(action, actions, f"{action!r} missing from {self.game.dialogue.speaker}: {actions}")
        self.game.dialogue.visible = len(self.game.dialogue.text)
        self.game.dialogue.selected = 0
        for _ in range(actions.index(action)):
            self.key(pygame.K_DOWN)
        self.key(pygame.K_RETURN)

    def stand_near(self, interaction):
        """Place feet on a clear approach tile, then use real proximity lookup.

        Travel between buildings is accelerated in the test harness; collision
        reachability of every approach is checked separately below.
        """
        expected = (interaction["kind"], interaction["id"])
        centre = interaction["rect"].center
        for radius in (24, 32, 40, 48, 16, 56, 8, 0, 64):
            for degrees in (90, 0, 180, 270, 45, 135, 225, 315):
                angle = math.radians(degrees)
                point = (centre[0] + round(math.cos(angle) * radius), centre[1] + round(math.sin(angle) * radius))
                self.game.player.teleport(*point)
                if self.game.world.is_blocked(self.game.player.rect):
                    continue
                nearest = self.game.world.nearest_interaction(self.game.player.rect)
                if nearest and (nearest["kind"], nearest["id"]) == expected:
                    return
        self.fail(f"No usable approach for {expected} in {self.game.world.map_id}")

    def portal(self, target):
        self.game.phone.open = False
        self.assertFalse(self.game.dialogue.open)
        entries = [a for a in self.game.world.interactables if a.get("target") == target and a["kind"] in ("door", "exit")]
        self.assertTrue(entries, f"No portal to {target}")
        self.stand_near(entries[0])
        self.key(pygame.K_e)
        self.assertIsNotNone(self.game.transition)
        self.finish_transition()
        self.assertEqual(self.game.world.map_id, target)
        self.assertFalse(self.game.world.is_blocked(self.game.player.rect))

    def travel(self, target):
        if self.game.world.map_id == target:
            return
        if self.game.world.map_id != "campus":
            self.portal("campus")
        if target != "campus":
            self.portal(target)

    def activity(self, map_id, activity_id, action):
        self.travel(map_id)
        entries = [a for a in self.game.world.interactables if a["kind"] == "activity" and a["id"] == activity_id]
        self.assertTrue(entries)
        self.stand_near(entries[0])
        self.key(pygame.K_e)
        self.choose(action)
        self.settle()

    def phone_action(self, action):
        if not self.game.phone.open:
            self.key(pygame.K_TAB)
        if self.game.phone.screen != "support":
            self.game.phone.show("support")
        self.game.phone.animation = 1
        # Support information can be longer than the screen. Wheel input must
        # reveal the actual clipped button before a mouse click can activate it.
        for _ in range(16):
            self.game.draw()
            for rect, target in self.game.phone.targets:
                if target == action:
                    self.game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=rect.center))
                    self.assertTrue(self.game.dialogue.open)
                    self.key(pygame.K_ESCAPE)
                    return
            self.game.handle_event(pygame.event.Event(pygame.MOUSEWHEEL, y=-3))
        self.fail(f"Phone action {action!r} could not be reached by scrolling")

    def next_chapter(self, expected):
        self.settle()
        self.assertTrue(self.game.state.chapter_complete)
        self.assertEqual(self.game.mode, "complete")
        self.game.draw()
        self.game.selection = next(i for i, (_, action) in enumerate(self.game.menu_targets) if action == "next")
        self.key(pygame.K_RETURN)
        self.finish_transition()
        self.assertEqual(self.game.state.chapter, expected)
        self.assertEqual(self.game.mode, "play")
        self.key(pygame.K_ESCAPE)  # chapter introduction
        self.assertFalse(self.game.dialogue.open)

    def test_title_new_game_movement_and_solid_collision(self):
        self.begin()
        start = self.game.player.pos.copy()
        keys = defaultdict(bool, {pygame.K_d: True})
        self.game.update(.05, keys)
        self.assertGreater(self.game.player.pos.x, start.x)
        self.assertEqual(self.game.player.direction, "right")
        # A student can approach the library but cannot walk through its wall.
        self.game.player.teleport(256, 369)
        upward = defaultdict(bool, {pygame.K_w: True})
        for _ in range(80):
            self.game.update(.02, upward)
        self.assertGreaterEqual(self.game.player.rect.top, 352)
        self.assertFalse(self.game.world.is_blocked(self.game.player.rect))
        # Diagonal movement is normalised rather than 1.4 times faster.
        self.game.player.teleport(480, 392)
        self.game.player.update(.04, keys, self.game.world)
        straight = self.game.player.pos.distance_to((480, 392))
        self.game.player.teleport(480, 392)
        self.game.player.update(.04, defaultdict(bool, {pygame.K_d: True, pygame.K_s: True}), self.game.world)
        diagonal = self.game.player.pos.distance_to((480, 392))
        self.assertAlmostEqual(straight, diagonal, places=4)

    def test_all_six_buildings_enter_exit_and_escape_does_not_teleport(self):
        self.begin()
        for target in ("library", "lecture_hall", "student_centre", "health_centre", "cafe", "career_hub"):
            with self.subTest(building=target):
                self.portal(target)
                position = self.game.player.pos.copy()
                self.key(pygame.K_ESCAPE)
                self.assertEqual(self.game.mode, "pause")
                self.assertEqual(self.game.world.map_id, target)
                self.assertEqual(self.game.player.pos, position)
                self.key(pygame.K_ESCAPE)
                self.assertEqual(self.game.mode, "play")
                self.portal("campus")
                self.assertLess(self.game.player.pos.distance_to(self.game.world.return_position(target)), 1)

    def test_phone_escape_stack_and_dialogue_priority(self):
        self.begin()
        self.key(pygame.K_TAB)
        self.assertTrue(self.game.phone.open)
        self.game.phone.animation = 1
        self.game.draw()
        quests = next(rect for rect, action in self.game.phone.targets if action == "app:quests")
        self.game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=quests.center))
        self.assertEqual(self.game.phone.stack, ["home", "quests"])
        self.game.phone.navigate("messages")
        self.key(pygame.K_ESCAPE)
        self.assertEqual(self.game.phone.screen, "quests")
        self.key(pygame.K_ESCAPE)
        self.assertEqual(self.game.phone.screen, "home")
        self.game.dialogue.show("Maya", "A short conversation.", [("CONTINUE", "")], "maya")
        self.key(pygame.K_ESCAPE)
        self.assertFalse(self.game.dialogue.open)
        self.assertTrue(self.game.phone.open)
        self.key(pygame.K_ESCAPE)
        self.assertFalse(self.game.phone.open)
        self.assertEqual(self.game.mode, "play")

    def test_dialogue_branch_changes_state_and_cancel_does_not(self):
        self.begin()
        before = dict(self.game.state.stats)
        self.game.activity_dialogue("cafe")
        self.key(pygame.K_ESCAPE)
        self.assertEqual(self.game.state.stats, before)
        self.game.activity_dialogue("cafe")
        self.choose("coffee")
        self.assertEqual(self.game.state.stats["money"], before["money"] - 5)
        self.assertEqual(self.game.state.stats["energy"], before["energy"] + 12)
        self.assertEqual(self.game.state.clock, 9 * 60 + 15)

    def test_every_phone_screen_and_support_status_renders_with_scrolling(self):
        self.begin()
        self.game.state.inventory = ["Supporting Document", "Follow-up Note", "Campus Sticker"]
        for name, _ in APP_NAMES:
            with self.subTest(screen=name):
                self.game.phone.show(name)
                self.game.phone.animation = 1
                self.game.draw()
                self.assertEqual(self.game.canvas.get_size(), (960, 540))
                self.assertTrue(self.game.phone.targets)
                for _ in range(10):
                    self.game.handle_event(pygame.event.Event(pygame.MOUSEWHEEL, y=-3))
                    self.game.draw()
                self.assertLessEqual(self.game.phone.scroll, self.game.phone.max_scroll)
                self.key(pygame.K_ESCAPE)
                self.assertEqual(self.game.phone.screen, "home")
        self.game.state.chapter = 5
        for status in ("DRAFT", "SUBMITTED", "UNDER REVIEW", "MORE INFORMATION REQUIRED", "APPROVED"):
            with self.subTest(support_status=status):
                self.game.state.support_status = status
                self.game.phone.show("support")
                self.game.phone.animation = 1
                self.game.draw()
                self.assertGreater(self.game.phone.max_scroll, 0)
                for _ in range(24):
                    if self.game.phone.scroll >= self.game.phone.max_scroll:
                        break
                    self.game.handle_event(pygame.event.Event(pygame.MOUSEWHEEL, y=-3))
                    self.game.draw()
                actions = [action for _, action in self.game.phone.targets]
                self.assertIn("services", actions)
                self.game.do_action("services")
                service_actions = [choice.action for choice in self.game.dialogue.choices]
                for topic in ('talk:support.enrolment','talk:support.timetable','talk:support.card','talk:support.assessment','talk:support.more'):
                    self.assertIn(topic, service_actions)
                self.key(pygame.K_ESCAPE)

    def test_all_map_interactions_reachable_through_real_collision_grid(self):
        # BFS checks routes, not just whether each destination is individually
        # clear: props or landscaping must never seal off a door or quest.
        for map_id in ("campus", "library", "lecture_hall", "student_centre", "health_centre", "cafe", "career_hub"):
            with self.subTest(map=map_id):
                self.game.world.load(map_id)
                world = self.game.world
                start = tuple(round(value / 8) * 8 for value in world.spawn)
                queue, seen = deque([start]), {start}
                while queue:
                    x, y = queue.popleft()
                    for pos in ((x+8, y), (x-8, y), (x, y+8), (x, y-8)):
                        if pos in seen:
                            continue
                        rect = pygame.Rect(0, 0, 18, 13)
                        rect.center = pos
                        if not world.is_blocked(rect):
                            seen.add(pos)
                            queue.append(pos)
                self.assertGreater(len(seen), 100)
                for entry in world.interactables:
                    rect = entry["rect"]
                    distance = min(math.hypot(max(rect.left-x, 0, x-rect.right), max(rect.top-y, 0, y-rect.bottom)) for x, y in seen)
                    self.assertLessEqual(distance, 43, f"{map_id}: {entry['id']} cannot be approached")

    def test_all_eight_chapters_through_actual_activity_choices_and_phone(self):
        self.begin()
        self.activity("library", "study", "study")
        self.travel("lecture_hall")
        self.next_chapter(2)
        self.activity("library", "study", "study")
        self.activity("campus", "rest", "rest")
        self.next_chapter(3)
        self.activity("campus", "group", "group_message")
        self.activity("campus", "group", "group_continue")
        self.next_chapter(4)
        self.assertEqual(self.game.state.stats["health"], 40)
        self.activity("health_centre", "health", "health")
        self.assertIn("Supporting Document", self.game.state.inventory)
        self.activity("campus", "rest", "rest")
        self.next_chapter(5)
        self.phone_action("support_submit")
        self.assertEqual(self.game.state.support_status, "SUBMITTED")
        for _ in range(4):
            if self.game.state.support_status == "MORE INFORMATION REQUIRED":
                break
            self.phone_action("wait")
        self.assertEqual(self.game.state.support_status, "MORE INFORMATION REQUIRED")
        self.settle()
        self.activity("health_centre", "health", "health")
        self.assertIn("Follow-up Note", self.game.state.inventory)
        self.phone_action("support_attach")
        self.assertEqual(self.game.state.support_status, "UNDER REVIEW")
        for _ in range(3):
            if self.game.state.support_status == "APPROVED":
                break
            self.phone_action("wait")
        self.assertEqual(self.game.state.support_status, "APPROVED")
        self.next_chapter(6)
        self.activity("library", "study", "revision")
        self.activity("library", "study", "revision")
        self.activity("lecture_hall", "lecture", "quiz")
        self.activity("campus", "rest", "rest")
        self.activity("lecture_hall", "lecture", "exam")
        self.next_chapter(7)
        self.activity("cafe", "cafe", "money_shift")
        self.activity("student_centre", "support", "budget")
        self.activity("campus", "festival", "festival")
        self.next_chapter(8)
        self.activity("career_hub", "career", "career_resume")
        self.activity("career_hub", "career", "career_network")
        self.activity("career_hub", "career", "career_interview")
        self.assertTrue(self.game.state.finished)
        self.assertEqual(self.game.mode, "complete")
        self.assertEqual(sorted(self.game.state.stars), [str(n) for n in range(1, 9)])
        self.assertEqual(self.game.state.unlocked_levels, list(range(1, 9)))
        self.assertGreaterEqual(self.game.state.total_stars, 32)
        self.game.draw()
        self.assertTrue(self.save_path.is_file())
        final_state = self.game.state.to_dict()
        self.game.new_game()
        self.game.load_game()
        self.assertEqual(self.game.state.to_dict(), final_state)
        self.assertEqual(self.game.world.map_id, "career_hub")

    def test_phone_save_and_title_continue_restore_exact_location(self):
        self.begin()
        self.travel("cafe")
        self.game.player.teleport(416, 420)
        self.game.player.direction = "left"
        before = self.game.state.to_dict()
        self.game.phone.show("save")
        self.game.phone.animation = 1
        self.game.draw()
        rect = next(rect for rect, action in self.game.phone.targets if action == "save")
        self.game.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=rect.center))
        self.assertTrue(self.save_path.is_file())
        self.assertEqual(self.game.state.to_dict(), before)
        self.game.new_game()
        self.key(pygame.K_ESCAPE)
        self.game.mode = "title"
        self.game.draw()
        self.game.selection = next(i for i, (_, action) in enumerate(self.game.menu_targets) if action == "continue")
        self.key(pygame.K_RETURN)
        self.assertEqual(self.game.mode, "play")
        self.assertEqual(self.game.world.map_id, "cafe")
        self.assertEqual(tuple(self.game.player.pos), (416, 420))
        self.assertEqual(self.game.player.direction, "left")
        self.assertEqual(self.game.state.to_dict(), before)

    def test_title_campus_interior_phone_pause_and_reward_frames_differ(self):
        signatures = []
        def capture():
            frame = self.game.draw()
            signatures.append(pygame.image.tobytes(frame, "RGB"))
        capture()
        self.begin()
        capture()
        self.travel("library")
        capture()
        self.key(pygame.K_TAB)
        self.game.phone.animation = 1
        capture()
        self.key(pygame.K_ESCAPE)
        self.key(pygame.K_ESCAPE)
        capture()
        self.game.mode = "complete"
        capture()
        self.assertEqual(len(set(signatures)), 6)
        for frame in signatures:
            self.assertGreater(len(set(frame)), 100)


if __name__ == "__main__":
    unittest.main(verbosity=2)
