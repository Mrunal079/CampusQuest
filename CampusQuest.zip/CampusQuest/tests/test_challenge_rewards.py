"""Rules-level coverage for optional puzzles and strategic study choices."""

import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from game_state import GameState


class ChallengeRewardTests(unittest.TestCase):
    def test_each_puzzle_has_a_distinct_useful_reward(self):
        cases = {
            "memory": (20, {"energy": 12, "stress": -10, "social": 6}),
            "route": (15, {"focus": 8, "confidence": 5, "stress": -4}),
            "code": (45, {"energy": -5, "focus": 5, "stress": -3}),
        }
        for kind, (minutes, effects) in cases.items():
            with self.subTest(kind=kind):
                state = GameState()
                clock = state.clock
                result = state.complete_challenge(kind, 3)
                self.assertTrue(result["ok"])
                self.assertEqual(result["effects"], effects)
                self.assertEqual(state.clock, clock + minutes)
                summary = next(row for row in state.challenge_summary if row["kind"] == kind)
                self.assertEqual(summary["best"], 3)
                self.assertEqual(summary["attempts"], 1)
                self.assertTrue(summary["cleared"])
                self.assertFalse(summary["reward_available"])

    def test_replay_improves_records_without_farming_resources(self):
        for kind in ("memory", "route", "code"):
            with self.subTest(kind=kind):
                state = GameState()
                state.complete_challenge(kind, 1, hints=2)
                stats = dict(state.stats)
                progress = state.assignments["python"]["progress"]
                result = state.complete_challenge(kind, 3)
                self.assertFalse(result["reward_available"])
                self.assertEqual(result["effects"], {})
                self.assertEqual(state.stats, stats)
                self.assertEqual(state.assignments["python"]["progress"], progress)
                self.assertEqual(state.flags[f"challenge:{kind}:attempts"], 2)
                self.assertEqual(state.flags[f"challenge:{kind}:best"], 3)
                self.assertEqual(state.flags[f"challenge:{kind}:hints"], 2)
                state.advance_time(1440)
                self.assertTrue(state.complete_challenge(kind, 2)["reward_available"])

    def test_invalid_completions_are_rejected_without_mutating_state(self):
        state = GameState()
        for kind, score, hints in (("invalid", 2, 0), (None, 2, 0),
                                   ("code", 0, 0), ("memory", 4, 0),
                                   ("route", "3", 0), ("code", True, 0),
                                   ("memory", 2.0, 0), ("memory", 2, -1),
                                   ("code", 2, False), ("code", 2, "1")):
            with self.subTest(kind=kind, score=score, hints=hints):
                before = state.to_dict()
                self.assertFalse(state.complete_challenge(kind, score, hints)["ok"])
                self.assertEqual(state.to_dict(), before)

    def test_badge_and_records_survive_json_and_chapter_replay(self):
        state = GameState()
        for kind in ("memory", "route", "code"):
            result = state.complete_challenge(kind, 2)
        self.assertEqual(result["item"], "Campus Challenge Badge")
        self.assertEqual(state.inventory.count("Campus Challenge Badge"), 1)
        state = GameState.from_dict(json.loads(json.dumps(state.to_dict())))
        summary = state.challenge_summary
        state.replay_chapter()
        self.assertEqual(state.challenge_summary, summary)
        self.assertIn("Campus Challenge Badge", state.inventory)
        self.assertFalse(state.complete_challenge("memory", 3)["reward_available"])
        self.assertEqual(state.inventory.count("Campus Challenge Badge"), 1)

    def test_code_puzzle_counts_as_work_but_does_not_complete_an_exam(self):
        state = GameState()
        state.visit("library")
        state.visit("lecture_hall")
        state.complete_challenge("code", 3)
        self.assertEqual(state.assignments["python"]["progress"], 16)
        self.assertTrue(state.chapter_complete)
        self.assertEqual(state.flags["1:study"], 1)
        self.assertNotIn("exam_completed", state.flags)
        self.assertEqual(state.assignments["quiz"]["progress"], 0)

    def test_completed_puzzle_processes_pending_support_reply(self):
        state = GameState()
        state.perform("health")
        state.perform("support_submit")
        state.complete_challenge("code", 2)
        self.assertEqual(state.support_status, "UNDER REVIEW")
        self.assertTrue(any("under review" in message["text"]
                            for message in state.messages))

    def test_day_is_taken_at_start_and_rewinding_does_not_refresh_reward(self):
        state = GameState()
        state.clock = 1435
        state.complete_challenge("memory", 2)
        self.assertEqual(state.flags["challenge:memory:last_reward_day"], 0)
        self.assertTrue(state.challenge_summary[0]["reward_available"])
        state.complete_challenge("memory", 3)
        self.assertEqual(state.flags["challenge:memory:last_reward_day"], 1)
        state.replay_chapter()
        self.assertFalse(state.challenge_summary[0]["reward_available"])

    def test_rewards_clamp_and_code_progress_never_exceeds_one_hundred(self):
        state = GameState()
        state.stats.update({"energy": 98, "social": 99, "stress": 2})
        result = state.complete_challenge("memory", 3)
        self.assertEqual(result["effects"], {"energy": 2, "stress": -2, "social": 1})
        state.assignments["python"]["progress"] = 99
        result = state.complete_challenge("code", 3)
        self.assertEqual(state.assignments["python"]["progress"], 100)
        self.assertIn("adds 1%", result["text"])

    def test_save_validation_rejects_corrupted_challenge_records(self):
        for key, value in (("challenge:memory:attempts", True),
                           ("challenge:route:best", 4),
                           ("challenge:code:hints", -1),
                           ("study_boost", "5"), ("study_boost", 6)):
            with self.subTest(key=key, value=value):
                data = GameState().to_dict()
                data["flags"][key] = value
                with self.assertRaises(ValueError):
                    GameState.from_dict(data)


class StrategicStudyTests(unittest.TestCase):
    def test_default_progress_is_preserved_and_preview_is_pure(self):
        for demo, expected in ((True, 20), (False, 15)):
            state = GameState(demo_mode=demo)
            before = state.to_dict()
            self.assertEqual(state.study_preview["increase"], expected)
            self.assertEqual(state.to_dict(), before)
            state.perform("study")
            self.assertEqual(state.assignments["python"]["progress"], expected)

    def test_wellbeing_changes_efficiency_and_is_explained(self):
        state = GameState()
        state.stats.update({"focus": 90, "stress": 70, "energy": 20, "health": 40})
        preview = state.study_preview
        self.assertEqual(preview["modifier"], -8)
        self.assertEqual(preview["increase"], 12)
        result = state.perform("study")
        self.assertEqual(state.assignments["python"]["progress"], 12)
        for explanation in ("high focus", "high stress", "low energy", "feeling unwell"):
            self.assertIn(explanation, result["text"])

    def test_route_and_planning_boost_do_not_stack_and_are_consumed_once(self):
        state = GameState()
        state.complete_challenge("route", 3)
        state.perform("work_plan")
        state.perform("work_plan")
        self.assertEqual(state.flags["study_boost"], 5)
        # Route and two plans reach 80 focus: +4 focus and +5 planning.
        self.assertEqual(state.study_preview["increase"], 29)
        state.perform("study")
        self.assertEqual(state.assignments["python"]["progress"], 29)
        self.assertNotIn("study_boost", state.flags)
        self.assertEqual(state.study_preview["increase"], 20)

    def test_blocked_study_keeps_preparation_and_free_rest_recovers(self):
        state = GameState()
        state.perform("work_plan")
        state.stats.update({"energy": 0, "money": 0})
        before = state.clock
        self.assertFalse(state.perform("study")["ok"])
        self.assertEqual(state.clock, before)
        self.assertEqual(state.flags["study_boost"], 5)
        self.assertTrue(state.perform("rest")["ok"])
        self.assertTrue(state.perform("study")["ok"])
        self.assertNotIn("study_boost", state.flags)
        self.assertEqual(state.stats["money"], 0)

    def test_minimum_progress_and_remaining_progress_cap(self):
        state = GameState(demo_mode=False)
        state.stats.update({"focus": 0, "stress": 100, "energy": 10, "health": 0})
        self.assertEqual(state.study_preview["increase"], 8)
        state.assignments["python"]["progress"] = 98
        self.assertEqual(state.study_preview["increase"], 2)
        result = state.perform("study")
        self.assertIn("+2%", result["text"])
        self.assertEqual(state.assignments["python"]["progress"], 100)


if __name__ == "__main__":
    unittest.main()
