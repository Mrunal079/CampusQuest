"""Building descriptions shared by the campus and its enterable interiors."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Building:
    """A real doorway joins a campus façade to a separate interior map."""

    id: str
    name: str
    x: int
    y: int
    activity: str
    width: int = 256
    height: int = 224

    @property
    def door_position(self):
        return self.x + self.width // 2, self.y + self.height + 14

    def as_object(self):
        return {"asset": f"buildings/{self.id}.png", "x": self.x, "y": self.y,
                "type": "building", "name": self.name, "solid": False}

    def as_interaction(self):
        x, y = self.door_position
        return {"id": self.id, "label": f"Enter {self.name}", "kind": "door",
                "target": self.id, "x": x - 24, "y": y - 18, "w": 48, "h": 36}


BUILDINGS = (
    Building("library", "Main Library", 128, 128, "study"),
    Building("lecture_hall", "Lecture Theatre", 864, 96, "lecture"),
    Building("student_centre", "Student Centre", 1568, 128, "support"),
    Building("cafe", "Petal & Bean Café", 192, 896, "cafe"),
    Building("health_centre", "Health Centre", 896, 896, "health"),
    Building("career_hub", "Career & Innovation Hub", 1536, 896, "career"),
)
BUILDING_BY_ID = {building.id: building for building in BUILDINGS}
