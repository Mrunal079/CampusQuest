"""Game orchestration: exploration, modal navigation and story activity routing."""
import math
import random
import pygame
from assets import Assets
from dialogue import DialogueManager
from conversations import ConversationController
from game_state import GameState
from player import Player, Camera
from world import World
from save_system import SaveManager, SaveError
from ui import UI, Phone
from settings import INTERNAL_SIZE, WINDOW_SIZE, DEMO_MODE, FPS, TITLE, INK, CREAM, PINK, MUTED, SAGE, GOLD

CHAPTER_TITLES = ['First Day', 'Deadline Rush', 'Group Project Chaos', 'Health Disruption',
                  'Special Consideration', 'Exam Season', 'Money Matters', 'Career Quest']


class Game:
    def __init__(self, headless=False, save_path=None):
        pygame.init()
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
        except pygame.error:
            pass
        pygame.display.set_caption(TITLE)
        self.window = pygame.display.set_mode(INTERNAL_SIZE if headless else WINDOW_SIZE, pygame.RESIZABLE)
        self.canvas = pygame.Surface(INTERNAL_SIZE).convert()
        self.assets = Assets()
        self.ui = UI(self.assets)
        self.phone = Phone()
        self.dialogue = DialogueManager()
        self.dialogue.set_layout(self.assets.font(15))
        self.conversations = ConversationController(self)
        self.puzzle = None
        self.puzzle_return_phone = None
        self.state = GameState(demo_mode=DEMO_MODE)
        self.world = World(self.assets)
        self.player = Player(*self.world.spawn, self.assets)
        self.camera = Camera(INTERNAL_SIZE)
        self.camera.update(self.player,(self.world.width,self.world.height),0,snap=True)
        self.saves = SaveManager(save_path) if save_path else SaveManager()
        self.mode = 'title'
        self.running = True
        self.clock = pygame.time.Clock()
        self.time = 0.0
        self.selection = 0
        self.menu_targets = []
        self.toasts = []
        self.transition = None
        self.event_queue = []
        self.last_message_count = 0
        self.chapter_campus_return = False
        self.chapter_origin = self.state.chapter
        rng = random.Random(9001)
        self.petals = [[rng.uniform(0,960), rng.uniform(0,540), rng.uniform(8,22), rng.random()*6] for _ in range(32)]
        self.display_rect = pygame.Rect(0,0,*self.window.get_size())

    def new_game(self):
        self.conversations.clear()
        self.puzzle = None
        self.puzzle_return_phone = None
        self.state = GameState(demo_mode=DEMO_MODE)
        self.world.load('campus')
        self.player.teleport(*self.world.spawn)
        self.camera.update(self.player,(self.world.width,self.world.height),0,snap=True)
        self.phone.open = False
        self.mode = 'play'
        self.toasts.clear()
        self.event_queue.clear()
        self.chapter_campus_return = False
        self.last_message_count = len(self.state.messages)
        self.dialogue.show('Nina', 'Welcome to Rosewood! Find the Library and Lecture Theatre, and try a study session. TAB opens your phone. Need a change of pace? B opens our playable campus challenges. Walk to doors and press E.',
                           [('LET\'S FIND OUR NEXT MOVE', '')], 'nina')

    def load_game(self):
        try:
            state, location = self.saves.load()
            map_id = location.get('map_id','campus')
            known_maps = ('campus','library','lecture_hall','student_centre','health_centre','cafe','career_hub')
            if map_id not in known_maps:
                raise SaveError('The saved campus location is invalid.')
            pos = location.get('position')
            if pos is not None and (not isinstance(pos,(list,tuple)) or len(pos)!=2):
                raise SaveError('The saved player position is invalid.')
            if pos is not None and any(isinstance(v,bool) or not isinstance(v,(int,float))
                                       or not math.isfinite(v) or not 0 <= v <= 100000 for v in pos):
                raise SaveError('The saved player coordinates must be finite numbers.')
            self.world.load(map_id)
            pos = pos if pos is not None else self.world.spawn
            self.player.teleport(float(pos[0]),float(pos[1]))
            if self.world.is_blocked(self.player.rect):
                self.player.teleport(*self.world.spawn)
            self.player.direction = location.get('direction','down') if location.get('direction','down') in ('up','down','left','right') else 'down'
            self.state = state
            self.conversations.clear()
            self.puzzle = None
            self.puzzle_return_phone = None
            self.camera.update(self.player,(self.world.width,self.world.height),0,snap=True)
            self.mode = 'play'
            self.phone.open = False
            self.dialogue.close()
            self.toasts.clear()
            self.event_queue.clear()
            pending = self.state.events.current()
            if pending:
                self.event_queue.append(pending)
            self.chapter_campus_return = False
            self.last_message_count = len(self.state.messages)
            self.notify('WELCOME BACK', 'Your next move is waiting.', 'save')
        except (SaveError,OSError,ValueError,TypeError,KeyError,OverflowError) as error:
            self.dialogue.show('Save journal', f'Your journey could not be loaded. {error}', [('BACK','')])

    def save_game(self, automatic=False):
        try:
            location = {'map_id':self.world.map_id,'position':list(self.player.pos),'direction':self.player.direction}
            self.saves.save(self.state,location)
            if not automatic:
                self.notify('JOURNEY SAVED', 'Location, story and phone progress saved.', 'save')
            self.assets.sound('click')
            return True
        except (SaveError,OSError,ValueError,TypeError) as error:
            self.dialogue.show('Save journal',f'Could not save: {error}',[('BACK','')])
            return False

    def notify(self,title,text,icon='messages'):
        self.toasts.append([title,str(text),4.5,icon])
        self.toasts = self.toasts[-3:]
        self.assets.sound('notification')

    def change_map(self,target,save_after=False):
        old = self.world.map_id
        def switch():
            spawn = self.world.load(target)
            if target == 'campus' and old != 'campus':
                spawn = self.world.return_position(old)
            self.player.teleport(*spawn)
            self.camera.update(self.player,(self.world.width,self.world.height),0,snap=True)
            self.state.visit(target)
            self.notify('ARRIVED',self.world.map_name,'map')
            self.assets.sound('door')
            if save_after:
                self.save_game(automatic=True)
        self.transition = {'elapsed':0.0,'duration':.48,'callback':switch,'switched':False}

    def interact(self):
        interaction = self.world.nearest_interaction(self.player.rect)
        if not interaction:
            return
        kind = interaction['kind']
        if kind in ('door','exit'):
            self.change_map(interaction.get('target','campus'))
        elif kind == 'activity':
            self.activity_dialogue(interaction['id'])
        elif kind == 'npc':
            self.npc_dialogue(interaction['id'])

    def activity_dialogue(self,name):
        conversation_roots={'career':'career.home','health':'health.home',
                            'support':'support.home','cafe':'cafe.home','lecture':'tutor.home',
                            'group':'group.home','festival':'events.home'}
        if name in conversation_roots:
            self.conversations.start(conversation_roots[name])
            return
        self.conversations.clear()
        if name == 'study':
            choices = [('WORK FOR 1 HOUR','study'),('PLAY THE LIBRARY LOGIC LAB','puzzle:code'),
                       ('PLAN MY NEXT STUDY SESSION','work_plan'),('ASK THE LIBRARIAN A QUESTION','talk:library.home')]
            if self.state.chapter >= 6:
                choices += [('REVISE FOR EXAMS','revision'),('TAKE PRACTICE QUIZ','quiz'),('TAKE PRACTICE EXAM','exam')]
            choices += [('NOT NOW','')]
            preview = self.state.study_preview
            text = f"Next session: +{preview['increase']}% project progress. {preview['reason']}. You can work, practise with a puzzle, or ask the librarian a question first."
            self.dialogue.show('Library computer',text,choices,'librarian')
        elif name == 'rest':
            self.dialogue.show('A quiet moment','A rest is part of the plan. Have a quiet break, try a puzzle, or work out your next step.',
                               [('REST / 2 HOURS','rest'),('PLAY A BREAK PUZZLE','challenges'),
                                ('MAKE A SIMPLE BUDGET','budget'),('CHECK PHONE / WAIT A WHILE','wait'),('NOT NOW','')])

    def npc_dialogue(self,name):
        self.conversations.start(self.conversations.book.root_for(name))

    def challenge_hub(self):
        """A small optional arcade, accessible in-world and from the phone."""
        summary = self.state.challenge_summary
        cleared = sum(bool(record['cleared']) for record in summary)
        text = f'{cleared}/3 challenges completed. Earn a Campus Challenge Badge by finishing all three. H gives a hint; Escape lets you leave. Daily rewards refresh on the next story day.'
        choices = [('MAYA\'S MEMORY BREAK','puzzle:memory'),('PETAL & BEAN: CAFE RUSH','puzzle:route'),('LIBRARY LOGIC LAB','puzzle:code'),('BACK','')]
        if self.conversations.active:
            choices[-1]=('BACK TO OUR CONVERSATION','talk:'+self.conversations.current)
        self.dialogue.show('Campus challenges',text,choices,'nina')

    def start_challenge(self, kind):
        from puzzle_ui import PuzzleScreen
        if kind not in ('memory','route','code'):
            return
        self.conversations.leave_for_activity()
        self.puzzle_return_phone = (list(self.phone.stack),self.phone.scroll) if self.phone.open else None
        self.phone.open = False
        self.dialogue.close()
        self.player.moving = False
        attempts = self.state.flags.get(f'challenge:{kind}:attempts',0)
        self.puzzle = PuzzleScreen(kind,self.assets,self.ui,seed=9001+self.state.chapter*101+attempts)
        self.puzzle.reward_available = next(record['reward_available'] for record in self.state.challenge_summary if record['kind']==kind)
        self.assets.sound('click')

    def finish_challenge(self, outcome):
        puzzle = self.puzzle
        if puzzle is None:
            return
        # Rewards require the actual model to be solved. UI events cannot grant them alone.
        solved = puzzle.model.complete
        self.puzzle = None
        if self.puzzle_return_phone:
            stack,scroll = self.puzzle_return_phone
            self.phone.open = True
            self.phone.stack = stack
            self.phone.scroll = scroll
        self.puzzle_return_phone = None
        if outcome.get('action') == 'complete' and solved:
            before = {q['title']:q.get('completed',False) for q in self.state.objectives}
            result = self.state.complete_challenge(puzzle.kind,puzzle.model.score,puzzle.model.hints)
            self.present_result(result,before)
            self.assets.sound('quest')
        else:
            self.challenge_hub()

    def do_action(self, action):
        if not action or action == '__closed__':
            return
        if self.conversations.handle(action):
            return
        if action == 'challenges':
            self.challenge_hub()
            return
        if action.startswith('puzzle:'):
            self.start_challenge(action.split(':',1)[1])
            return
        if action.startswith('open:'):
            self.conversations.clear()
            self.phone.show(action.split(':',1)[1])
            return
        if action.startswith('activity:'):
            self.activity_dialogue(action.split(':',1)[1])
            return
        if action == 'services':
            self.conversations.start('support.home')
            return
        if action == 'save':
            self.save_game()
            return
        if action == 'chapters':
            self.conversations.clear()
            self.mode='chapters'
            self.selection=0
            return
        before = {q['title']:q.get('completed',False) for q in self.state.objectives}
        self.conversations.leave_for_activity()
        result = self.state.perform(action)
        self.present_result(result,before)

    def present_result(self,result,before=None):
        """Display effects consistently for activities and solved challenges."""
        if not result:
            return
        before = before or {q['title']:q.get('completed',False) for q in self.state.objectives}
        if result.get('item'):
            self.notify('ITEM RECEIVED',result['item'],'document')
            self.assets.sound('item')
        for q in self.state.objectives:
            if q.get('completed') and not before.get(q['title'],False):
                self.notify('QUEST COMPLETE',q['title'],'quests')
                self.assets.sound('quest')
        if len(self.state.messages) > self.last_message_count:
            self.notify('PHONE BUZZ', 'A new message is waiting in your phone.','messages')
            self.last_message_count = len(self.state.messages)
        event=result.get('event') or self.state.events.current()
        if event:
            if not any(queued['id']==event['id'] for queued in self.event_queue):
                self.event_queue.append(event)
        text = result.get('text','You have taken another step.')
        effects = result.get('effects',{})
        if effects:
            labels = [f'{name.title()} {delta:+d}' for name,delta in effects.items()]
            text += '\n' + '  /  '.join(labels)
        portrait = 'student_tired' if self.state.stats['health'] < 45 else 'student'
        choices = self.conversations.return_choices()
        speaker = result.get('title','Your next move')
        if self.conversations.active:
            node=self.conversations.book.nodes[self.conversations.current]
            speaker=node.speaker
            portrait=node.portrait
        self.dialogue.show(speaker,text,choices,portrait,
                           back_action='talk:back' if self.conversations.active else '',
                           topic=result.get('title',''))

    def _menu_action(self,action):
        self.assets.sound('click')
        if action=='new':
            self.new_game()
        elif action=='continue':
            if self.saves.exists:
                self.load_game()
        elif action=='help':
            self.dialogue.show('How to play','Move with WASD or arrows. Press E near a door, person or activity. TAB opens your phone; Escape goes back one screen or pauses exploration. Walk out through exit doors. Activities advance the clock; walking does not. Rest and seeking help are progress.', [('GOT IT','')],'nina')
        elif action=='quit':
            self.running=False
        elif action=='resume':
            self.mode='play'
        elif action=='phone':
            self.mode='play'
            self.phone.show()
        elif action=='save':
            self.save_game()
        elif action=='title':
            self.conversations.clear()
            self.mode='title'
            self.selection=0
            self.phone.open=False
        elif action=='chapters':
            self.mode='chapters'
            self.selection=0
        elif action=='next':
            self.conversations.clear()
            if self.state.chapter>=8:
                self.mode='play'
                self.chapter_campus_return=True
                self.dialogue.show('Your next move','You reached the end of this campus story. You can keep exploring, revisit your chapter journal, or start a new journey. Thank you for playing Campus Quest.', [('BACK TO CAMPUS','')],'maya')
                return
            self.state.next_chapter()
            self.phone.open=False
            self.mode='play'
            self.chapter_campus_return=False
            self.event_queue.clear()
            self.change_map('campus',save_after=True)
            self.dialogue.show(f'Chapter {self.state.chapter} / {self.state.chapter_title}',self.state.chapter_description,[('FIND MY NEXT MOVE','')])
            if self.state.chapter==4:
                self.notify('UNEXPECTED EVENT','You are feeling unwell. Take a moment to replan.','health')
        elif action=='replay':
            self.conversations.clear()
            self.state.replay_chapter()
            self.phone.open=False
            self.mode='play'
            self.chapter_campus_return=False
            self.event_queue.clear()
            self.change_map('campus')
        elif action=='campus':
            self.chapter_campus_return=True
            self.mode='play'
        elif action.startswith('chapter:'):
            chapter=int(action.split(':')[1])
            if chapter==self.state.chapter:
                self.mode='complete' if self.state.chapter_complete else 'play'
                self.phone.open=False
            elif chapter not in self.state.unlocked_levels:
                self.dialogue.show('Your campus journey','Finish the current chapter to unlock the next step in the story.', [('BACK TO JOURNEY','')],'nina')
            else:
                self.dialogue.show('Your campus journey','These stars record your earlier progress. Replay is available for your current chapter from its rewards screen.', [('BACK TO JOURNEY','')],'nina')

    def handle_event(self,event):
        if event.type==pygame.QUIT:
            self.running=False
            return
        if event.type==pygame.VIDEORESIZE:
            self.window=pygame.display.set_mode((max(640,event.w),max(360,event.h)),pygame.RESIZABLE)
            return
        if self.transition:
            return
        if self.puzzle is not None and self.mode == 'play':
            outcome = self.puzzle.handle(event)
            if outcome is not None:
                self.finish_challenge(outcome)
            return
        if self.dialogue.open:
            action=self.dialogue.handle(event)
            if action is not None:
                self.do_action(action)
            return
        if self.mode=='play' and self.phone.open:
            action=self.phone.handle(event)
            if action:
                self.do_action(action)
            return
        if self.mode in ('title','pause','complete','chapters'):
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE and self.mode in ('pause','chapters'):
                    self.mode='play'
                    return
                if event.key in (pygame.K_DOWN,pygame.K_s,pygame.K_RIGHT,pygame.K_d):
                    self.selection=(self.selection+1)%max(1,len(self.menu_targets))
                if event.key in (pygame.K_UP,pygame.K_w,pygame.K_LEFT,pygame.K_a):
                    self.selection=(self.selection-1)%max(1,len(self.menu_targets))
                if event.key in (pygame.K_RETURN,pygame.K_SPACE) and self.menu_targets:
                    self._menu_action(self.menu_targets[self.selection][1])
            if event.type==pygame.MOUSEMOTION:
                for i,(rect,action) in enumerate(self.menu_targets):
                    if rect.collidepoint(event.pos):
                        self.selection=i
            if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
                for rect,action in self.menu_targets:
                    if rect.collidepoint(event.pos):
                        self._menu_action(action)
                        break
            return
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_e:
                self.interact()
            elif event.key==pygame.K_TAB:
                self.phone.show()
            elif event.key==pygame.K_ESCAPE:
                self.mode='pause'
                self.selection=0
            elif event.key==pygame.K_F5:
                self.save_game()
            elif event.key==pygame.K_F2:
                self.mode='chapters'
                self.selection=0
            elif event.key in (pygame.K_b,pygame.K_F3):
                self.challenge_hub()
            elif event.key==pygame.K_n and self.chapter_campus_return and self.state.chapter_complete:
                self.mode='complete'
                self.selection=0

    def update(self,dt,keys=None):
        self.time+=dt
        for petal in self.petals:
            petal[0]+=(math.sin(self.time+petal[3])*5+8)*dt
            petal[1]+=petal[2]*dt
            if petal[1]>550:
                petal[1]=-5
            if petal[0]>970:
                petal[0]=-5
        for toast in self.toasts:
            if not self.dialogue.open and not self.phone.open and self.puzzle is None and self.mode=='play':
                toast[2]-=dt
        self.toasts=[toast for toast in self.toasts if toast[2]>0]
        self.dialogue.update(dt)
        self.phone.update(dt)
        if self.transition:
            self.transition['elapsed']+=dt
            if self.transition['elapsed']>=self.transition['duration']/2 and not self.transition['switched']:
                self.transition['callback']()
                self.transition['switched']=True
            if self.transition['elapsed']>=self.transition['duration']:
                self.transition=None
            return
        if self.mode!='play':
            return
        if self.puzzle is not None:
            self.player.moving=False
            self.puzzle.update(dt)
            return
        if self.dialogue.open or self.phone.open:
            self.player.moving=False
            return
        self.world.update(dt)
        if self.event_queue:
            event=self.event_queue.pop(0)
            choices=[(c['label'],c['action']) for c in event.get('choices',[])]
            self.dialogue.show(event.get('title','Campus moment'),event.get('text',''),choices or [('CONTINUE','')],'nina')
            return
        if self.state.chapter_complete and not self.chapter_campus_return:
            self.mode='complete'
            self.selection=0
            self.assets.sound('quest')
            self.save_game(automatic=True)
            return
        if keys is None:
            keys=pygame.key.get_pressed()
        speed=.7 if self.state.stats['health']<45 else 1
        self.player.update(dt,keys,self.world,speed)
        self.camera.update(self.player,(self.world.width,self.world.height),dt)

    def draw_title(self):
        ui,s=self.ui,self.canvas
        s.blit(self.assets.image('ui/title_background.png'),(0,0))
        # Readability veil leaves the original painted campus visible.
        veil=pygame.Surface(INTERNAL_SIZE,pygame.SRCALPHA)
        veil.fill((255,244,224,40))
        s.blit(veil,(0,0))
        char=self.assets.image('ui/title_character.png')
        s.blit(char,(648,190+int(math.sin(self.time*1.5)*2)))
        logo=self.assets.image('ui/title_logo.png')
        if logo.get_width()>590:
            logo=pygame.transform.scale(logo,(560,int(logo.get_height()*560/logo.get_width())))
        s.blit(logo,(47,42))
        ui.text(s,'A little courage. A campus full of possibilities.',(304,205),13,INK,False,True)
        self.menu_targets=[]
        labels=[('NEW GAME','new',True),('CONTINUE','continue',self.saves.exists),('HOW TO PLAY','help',True),('QUIT','quit',True)]
        for i,(label,action,enabled) in enumerate(labels):
            rect=ui.button(s,(152,247+i*52,304,43),label,i==self.selection,enabled,16)
            self.menu_targets.append((rect,action))
        for x,y,speed,phase in self.petals:
            pygame.draw.rect(s,(241,171,188),(int(x),int(y),4,2))
            pygame.draw.rect(s,(255,218,222),(int(x)+1,int(y)-1,2,2))
        ui.panel(s,(18,489,589,33))
        ui.text(s,'ORIGINAL PIXEL-ART STORY  /  8 CHAPTERS  /  COMP9001',(33,499),11,INK,True)
        ui.text(s,'Arrows + Enter or mouse',(793,516),11,INK,False,True)

    def draw_menu(self):
        ui,s=self.ui,self.canvas
        ui.dim(s,155)
        self.menu_targets=[]
        if self.mode=='pause':
            ui.panel(s,(300,65,360,413))
            ui.text(s,'A MOMENT TO PAUSE',(480,103),24,INK,True,True)
            ui.text(s,'Your next move can wait.',(480,136),14,MUTED,False,True)
            options=[('RESUME','resume'),('OPEN PHONE','phone'),('CHAPTER JOURNEY','chapters'),('SAVE JOURNEY','save'),('TITLE SCREEN','title'),('QUIT','quit')]
            for i,(label,action) in enumerate(options):
                rect=ui.button(s,(331,169+i*45,298,37),label,i==self.selection,size=13)
                self.menu_targets.append((rect,action))
        elif self.mode=='chapters':
            ui.panel(s,(147,30,666,479))
            ui.text(s,'YOUR CAMPUS JOURNEY',(480,67),26,INK,True,True)
            ui.text(s,'Earn stars, open a chapter, find another way forward.',(480,98),13,MUTED,False,True)
            for i,title in enumerate(CHAPTER_TITLES):
                row,col=i%4,i//4
                rect=pygame.Rect(173+col*313,127+row*75,300,65)
                enabled=i+1 in self.state.unlocked_levels
                ui.panel(s,rect,selected=i==self.selection,button=True)
                ui.text(s,f'{i+1:02d}',(rect.x+12,rect.y+16),25,PINK if enabled else MUTED,True)
                ui.text(s,title,(rect.x+56,rect.y+10),14,INK if enabled else MUTED,True)
                values=self.state.stars.get(str(i+1),[])
                caption=(f'{sum(values)} / 12 stars' if values else ('CURRENT CHAPTER' if i+1==self.state.chapter else 'UNLOCKED' if enabled else 'LOCKED'))
                ui.text(s,caption,(rect.x+56,rect.y+36),11,SAGE if enabled else MUTED)
                self.menu_targets.append((rect,'chapter:'+str(i+1)))
            rect=ui.button(s,(340,444,280,39),'BACK TO CAMPUS',self.selection==8,size=14)
            self.menu_targets.append((rect,'resume'))
        elif self.mode=='complete':
            ui.panel(s,(107,43,746,454))
            ui.text(s,f'CHAPTER {self.state.chapter} COMPLETE',(480,85),16,PINK,True,True)
            ui.text(s,self.state.chapter_title,(480,126),35,INK,True,True)
            ui.text(s,'You found your next move.',(480,166),15,MUTED,False,True)
            categories=['Health management','Academic progress','Wellbeing','Social life']
            values=self.state.stars.get(str(self.state.chapter),[2,2,2,2])
            for i,(label,value) in enumerate(zip(categories,values)):
                x=151+i*173
                ui.text(s,label,(x+70,216),12,INK,True,True)
                for star in range(3):
                    icon=self.assets.image('icons/star.png').copy()
                    if star>=value:
                        icon.set_alpha(45)
                    s.blit(pygame.transform.scale(icon,(37,37)),(x+11+star*40,242+int(math.sin(self.time*2+i)*2)))
            ui.text(s,f'{sum(values)} / 12 STARS',(480,315),24,GOLD,True,True)
            ui.text(s,'Next chapter unlocked' if self.state.chapter<8 else 'Your campus story is complete',(480,347),15,SAGE,True,True)
            options=[('NEXT CHAPTER' if self.state.chapter<8 else 'FINISH STORY','next'),('REPLAY CHAPTER','replay'),('CAMPUS','campus'),('SAVE','save')]
            for i,(label,action) in enumerate(options):
                rect=ui.button(s,(135+i*176,397,164,47),label,i==self.selection,size=12)
                self.menu_targets.append((rect,action))
            ui.text(s,'Replay restores this chapter\'s starting checkpoint.',(480,468),12,MUTED,False,True)

    def draw(self):
        self.canvas.fill((99,119,104))
        if self.mode=='title':
            self.draw_title()
        else:
            self.world.draw(self.canvas,self.camera,self.player)
            # Pale dusk light is an overlay, not a replacement for world artwork.
            hour=(self.state.clock//60)%24
            if hour>=18 or hour<6:
                veil=pygame.Surface(INTERNAL_SIZE,pygame.SRCALPHA)
                veil.fill((65,64,100,45))
                self.canvas.blit(veil,(0,0))
            self.ui.hud(self.canvas,self)
            if self.mode=='play' and self.puzzle is None and not self.dialogue.open and not self.phone.open and not self.transition:
                nearest=self.world.nearest_interaction(self.player.rect)
                if nearest:
                    self.ui.prompt(self.canvas,'E  /  '+nearest['label'],self.time)
                if self.chapter_campus_return and self.state.chapter_complete:
                    self.ui.text(self.canvas,'N / CHAPTER REWARDS',(480,437),13,CREAM,True,True)
            if self.phone.open and self.mode=='play':
                self.phone.draw(self.canvas,self)
            if self.mode in ('pause','complete','chapters'):
                self.draw_menu()
        for index,toast in enumerate(self.toasts[-2:]):
            if not self.phone.open and self.puzzle is None and not self.dialogue.open and self.mode=='play':
                self.ui.toast(self.canvas,toast,index)
        if self.puzzle is not None and self.mode=='play':
            self.puzzle.draw(self.canvas)
        if self.dialogue.open:
            self.ui.dialogue(self.canvas,self.dialogue)
        if self.transition:
            elapsed=self.transition['elapsed']/self.transition['duration']
            alpha=int(255*(1-abs(elapsed*2-1)))
            veil=pygame.Surface(INTERNAL_SIZE,pygame.SRCALPHA)
            veil.fill((29,28,41,max(0,min(255,alpha))))
            self.canvas.blit(veil,(0,0))
        ww,wh=self.window.get_size()
        ratio=min(ww/960,wh/540)
        size=(max(1,int(960*ratio)),max(1,int(540*ratio)))
        self.display_rect=pygame.Rect((ww-size[0])//2,(wh-size[1])//2,*size)
        self.window.fill((32,29,42))
        self.window.blit(pygame.transform.scale(self.canvas,size),self.display_rect)
        pygame.display.flip()
        return self.canvas

    def normalise_event(self,event):
        if hasattr(event,'pos'):
            attrs=event.dict.copy()
            attrs['pos']=(int((event.pos[0]-self.display_rect.x)*960/self.display_rect.w),int((event.pos[1]-self.display_rect.y)*540/self.display_rect.h))
            return pygame.event.Event(event.type,attrs)
        return event

    def run(self,max_frames=None):
        frames=0
        while self.running:
            dt=min(self.clock.tick(FPS)/1000,.06)
            for event in pygame.event.get():
                self.handle_event(self.normalise_event(event))
            self.update(dt)
            self.draw()
            frames+=1
            if max_frames is not None and frames>=max_frames:
                break
