"""Cached PNG, font and optional sound loading; no artwork is drawn here."""
from pathlib import Path
import pygame
from settings import ASSET_DIR, SOUND_ENABLED


class Assets:
    def __init__(self):
        self.images = {}
        self.fonts = {}
        self.sounds = {}

    def image(self, relative_path):
        key = str(relative_path)
        if key not in self.images:
            path = ASSET_DIR / key
            if not path.is_file():
                raise FileNotFoundError(f'Missing game artwork: {path}. Run python3 asset_generator.py.')
            self.images[key] = pygame.image.load(str(path)).convert_alpha()
        return self.images[key]

    def font(self, size=16, bold=False):
        key = (size, bold)
        if key not in self.fonts:
            candidates = [
                ASSET_DIR / 'fonts' / ('bold.ttf' if bold else 'regular.ttf'),
                Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf' if bold else '/System/Library/Fonts/Supplemental/Arial.ttf'),
                Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
                Path('C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf'),
            ]
            found = next((p for p in candidates if p.is_file()), None)
            self.fonts[key] = pygame.font.Font(str(found) if found else None, size)
            if found is None:
                self.fonts[key].set_bold(bold)
        return self.fonts[key]

    def sound(self, name):
        if not SOUND_ENABLED or pygame.mixer.get_init() is None:
            return
        try:
            if name not in self.sounds:
                path = ASSET_DIR / 'audio' / f'{name}.wav'
                if not path.exists():
                    return
                self.sounds[name] = pygame.mixer.Sound(str(path))
                self.sounds[name].set_volume(.22)
            self.sounds[name].play()
        except pygame.error:
            pass  # Audio hardware is optional; gameplay remains available.
