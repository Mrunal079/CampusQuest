"""Small, serialisable quest objects used by the campus story.

Quest progress is derived from the game state rather than from interface clicks.
This keeps the phone, chapter screens and save files in agreement.
"""

from dataclasses import asdict, dataclass


@dataclass
class Quest:
    title: str
    description: str
    category: str
    progress: int
    target: int
    completed: bool
    reward: str
    chapter: int
    optional: bool = False
    key: str = ""

    def set_progress(self, value):
        """Update a quest safely; completed objectives remain completed."""
        self.progress = max(0, min(self.target, int(value)))
        self.completed = self.progress >= self.target

    @property
    def current_progress(self):
        return self.progress

    def to_dict(self):
        return asdict(self)


def _quest(key, title, description, category, target, chapter, optional=False,
           reward="Chapter stars"):
    return Quest(title, description, category, 0, target, False, reward,
                 chapter, optional, key)


class QuestManager:
    """Own the eight chapters' objectives and calculate their progress."""

    def __init__(self):
        self.quests = [
            _quest("bearings", "Find Your Bearings", "Enter the Library and Lecture Theatre.", "Explore", 2, 1),
            _quest("first_work", "A Small First Step", "Use a library computer for one project session.", "Academic", 1, 1),
            _quest("first_friend", "Coffee Break", "Sit with Maya at the campus cafe.", "Social", 1, 1, True),
            _quest("python", "Python Panic", "Reach 40% on your COMP9001 project.", "Academic", 40, 2),
            _quest("recharge", "Pace Yourself", "Rest or have a snack during Deadline Rush.", "Wellbeing", 1, 2),
            _quest("lecture", "A Fresh Perspective", "Attend a lecture for a focus boost.", "Academic", 1, 2, True),
            _quest("group_decision", "Where Is Everyone?", "Resolve the missed group meeting: wait, message, continue, or ask your tutor.", "Social", 1, 3),
            _quest("group_work", "Your Contribution Counts", "Reach 40% on the group project.", "Academic", 40, 3),
            _quest("group_kindness", "Clear Communication", "Message your teammate or ask for tutor guidance.", "Social", 1, 3, True),
            _quest("practitioner", "Feeling Unwell", "Visit the Health Centre practitioner.", "Health", 1, 4),
            _quest("evidence", "Supporting Evidence", "Receive the fictional Supporting Document.", "Support", 1, 4),
            _quest("health_rest", "Room to Recover", "Take a rest after the disruption.", "Wellbeing", 1, 4),
            _quest("support_submit", "Ask for Support", "Submit your fictional support request from the phone.", "Support", 1, 5),
            _quest("followup", "A Little More Information", "After the message, revisit the practitioner and attach the Follow-up Note.", "Support", 1, 5),
            _quest("support_approved", "A Way Forward", "Wait for the fictional application to be approved.", "Support", 1, 5),
            _quest("revision", "One Topic at a Time", "Reach 60% revision preparation at the library.", "Academic", 60, 6),
            _quest("quiz", "Knowledge Check", "Complete the practice quiz at the Lecture Theatre.", "Academic", 1, 6),
            _quest("exam", "You've Prepared for This", "Sit the fictional exam at the Lecture Theatre.", "Academic", 1, 6),
            _quest("exam_rest", "Sleep Is Preparation", "Rest once during Exam Season.", "Wellbeing", 1, 6),
            _quest("shift", "A Little Breathing Room", "Complete a casual cafe shift.", "Money", 1, 7),
            _quest("budget", "Make a Plan", "Review your budget in the phone or at the Student Centre.", "Money", 1, 7),
            _quest("free_event", "Campus Without the Cost", "Attend the free society event at the campus stalls.", "Social", 1, 7),
            _quest("resume", "Tell Your Story", "Get a resume review at the Career Hub.", "Career", 1, 8),
            _quest("network", "Start a Conversation", "Join the Career Hub networking session.", "Career", 1, 8),
            _quest("interview", "Find Your Next Move", "Practise an interview after reviewing your resume and networking.", "Career", 1, 8),
            _quest("final_friend", "Bring a Friend Along", "Catch up with Maya during Career Quest.", "Social", 1, 8, True),
        ]

    def active(self, chapter):
        return [quest for quest in self.quests if quest.chapter == chapter]

    def required_complete(self, chapter):
        return all(q.completed for q in self.active(chapter) if not q.optional)

    def update(self, key, progress):
        """Update a named objective; primarily useful for small extensions."""
        for quest in self.quests:
            if quest.key == key:
                quest.set_progress(progress)
                return quest
        raise KeyError("Unknown quest: " + str(key))

    def refresh(self, state):
        """Derive active chapter progress; return newly completed quests."""
        f = state.flags
        count = lambda chapter, action: f.get(f"{chapter}:{action}", 0)
        values = {
            "bearings": sum(place in state.visited for place in ("library", "lecture_hall")),
            "first_work": count(1, "study"),
            "first_friend": count(1, "maya"),
            "python": state.assignments["python"]["progress"],
            "recharge": count(2, "rest") + count(2, "snack"),
            "lecture": count(2, "lecture"),
            "group_decision": int(bool(f.get("group_resolved"))),
            "group_work": state.assignments["group"]["progress"],
            "group_kindness": count(3, "group_message") + count(3, "group_tutor"),
            "practitioner": count(4, "health"),
            "evidence": int("Supporting Document" in state.inventory),
            "health_rest": count(4, "rest"),
            "support_submit": int(bool(f.get("support_submitted"))),
            "followup": int(bool(f.get("support_followup_attached"))),
            "support_approved": int(state.support_status == "APPROVED"),
            "revision": state.assignments["revision"]["progress"],
            "quiz": int(state.assignments["quiz"]["progress"] >= 100),
            "exam": int(bool(f.get("exam_completed"))),
            "exam_rest": count(6, "rest"),
            "shift": count(7, "money_shift"),
            "budget": count(7, "budget"),
            "free_event": count(7, "festival"),
            "resume": int(bool(f.get("resume_reviewed"))),
            "network": int(bool(f.get("networked"))),
            "interview": int(bool(f.get("interview_completed"))),
            "final_friend": count(8, "maya"),
        }
        completed = []
        for quest in self.active(state.chapter):
            was_complete = quest.completed
            quest.set_progress(values.get(quest.key, quest.progress))
            if quest.completed and not was_complete:
                completed.append(quest)
        return completed

    def to_dict(self):
        return [quest.to_dict() for quest in self.quests]

    def restore(self, saved):
        """Restore known quest keys only, retaining current text and rules."""
        by_key = {q.key: q for q in self.quests}
        if not isinstance(saved, list):
            return
        for record in saved:
            if isinstance(record, dict) and record.get("key") in by_key:
                value = record.get("progress", 0)
                if isinstance(value, (int, float)):
                    by_key[record["key"]].set_progress(value)
