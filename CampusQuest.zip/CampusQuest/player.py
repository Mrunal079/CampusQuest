"""Smooth, frame-independent player movement and a softly following camera."""
import math
import pygame

TILE = 32
DIRECTION_ROWS = {"down": 0, "up": 1, "left": 2, "right": 3}


class Player:
    """The collision rectangle represents feet rather than the student's head."""

    def __init__(self, x, y, assets):
        self.assets = assets
        self.pos = pygame.Vector2(x, y)
        self.rect = pygame.Rect(0, 0, 18, 13)
        self.rect.center = (round(x), round(y))
        self.direction = "down"
        self.moving = False
        self.animation_time = 0.0
        self.sheet = self._load_sheet()

    def _load_sheet(self):
        for name in ("player/student.png", "player/player.png", "player/student_sheet.png"):
            try:
                return self.assets.image(name)
            except (FileNotFoundError, pygame.error, KeyError):
                continue
        return None

    @property
    def sprite(self):
        if self.sheet is None:
            return None
        frame = (1 + int(self.animation_time * 9) % 3) if self.moving else 0
        source = pygame.Rect(frame * 32, DIRECTION_ROWS[self.direction] * 48, 32, 48)
        return self.sheet.subsurface(source)

    def teleport(self, x, y):
        self.pos.update(x, y)
        self.rect.center = (round(x), round(y))
        self.moving = False

    def update(self, dt, keys, world, speed_factor=1):
        x_axis = int(bool(keys[pygame.K_d] or keys[pygame.K_RIGHT])) - int(bool(keys[pygame.K_a] or keys[pygame.K_LEFT]))
        y_axis = int(bool(keys[pygame.K_s] or keys[pygame.K_DOWN])) - int(bool(keys[pygame.K_w] or keys[pygame.K_UP]))
        movement = pygame.Vector2(x_axis, y_axis)
        self.moving = movement.length_squared() > 0
        if not self.moving:
            return
        movement = movement.normalize()
        if abs(movement.x) > abs(movement.y):
            self.direction = "right" if movement.x > 0 else "left"
        else:
            self.direction = "down" if movement.y > 0 else "up"
        self.animation_time += dt
        # Sub-pixel position avoids slow-speed stutter; each axis is tested independently.
        distance = 152 * max(.35, speed_factor) * min(dt, .08)
        for axis in (0, 1):
            candidate_pos = self.pos.copy()
            candidate_pos[axis] += movement[axis] * distance
            candidate_rect = self.rect.copy()
            candidate_rect.center = (round(candidate_pos.x), round(candidate_pos.y))
            if not world.is_blocked(candidate_rect):
                self.pos = candidate_pos
                self.rect = candidate_rect

    def draw(self, surface, camera):
        offset = camera.offset
        image = self.sprite
        if image is not None:
            surface.blit(image, (round(self.pos.x - 16 - offset.x), round(self.pos.y - 41 - offset.y)))


class Camera:
    """Camera offset stays within the map and eases towards the student's feet."""

    def __init__(self, view_size=(960, 540)):
        self.view_size = pygame.Vector2(view_size)
        self.offset = pygame.Vector2()

    def update(self, target, world_size, dt, snap=False):
        if hasattr(target, "rect"):
            centre = pygame.Vector2(target.rect.center)
        elif isinstance(target, pygame.Rect):
            centre = pygame.Vector2(target.center)
        else:
            centre = pygame.Vector2(target)
        desired = centre - self.view_size / 2
        for axis in (0, 1):
            map_size = world_size[axis]
            if map_size < self.view_size[axis]:
                desired[axis] = (map_size - self.view_size[axis]) / 2
            else:
                desired[axis] = max(0, min(desired[axis], map_size - self.view_size[axis]))
        self.offset = desired if snap else self.offset.lerp(desired, 1 - math.exp(-dt * 8))

    def apply(self, rect):
        return rect.move(-round(self.offset.x), -round(self.offset.y))
