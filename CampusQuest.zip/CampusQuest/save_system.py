"""Atomic JSON save files with a checked schema and readable error messages."""

import json
import math
import os
from pathlib import Path
import tempfile

from game_state import GameState


class SaveError(Exception):
    """An expected save/load problem that can be shown in the game UI."""


class SaveManager:
    VERSION = 1

    def __init__(self, path=None):
        self.path = Path(path) if path else Path(__file__).resolve().parent / "data" / "save.json"

    @property
    def exists(self):
        return self.path.is_file()

    @staticmethod
    def _validate_world(world_data):
        if not isinstance(world_data, dict):
            raise ValueError("The saved world must be an object.")

        def check(value, depth=0):
            if depth > 25:
                raise ValueError("The saved world data is nested too deeply.")
            if value is None or isinstance(value, (str, bool, int)):
                return
            if isinstance(value, float):
                if not math.isfinite(value):
                    raise ValueError("A saved coordinate is not a finite number.")
                return
            if isinstance(value, (list, tuple)):
                for part in value:
                    check(part, depth + 1)
                return
            if isinstance(value, dict):
                for key, part in value.items():
                    if not isinstance(key, str):
                        raise ValueError("World-data keys must be text.")
                    check(part, depth + 1)
                return
            raise ValueError("The world contains a value JSON cannot save.")

        check(world_data)
        return world_data

    def save(self, state, world_data=None):
        """Write a temporary file, then replace the old save in one operation.

        A failed encode or write leaves the previous save untouched. Pygame
        surfaces, sprites and other runtime objects never belong in this file.
        """
        temporary_path = None
        try:
            game_data = state.to_dict()
            GameState.from_dict(game_data)
            world_data = self._validate_world(world_data or {})
            payload = {"version": self.VERSION, "game": game_data, "world": world_data}
            encoded = json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                                             dir=self.path.parent, prefix=".campus-save-",
                                             suffix=".tmp", delete=False) as handle:
                temporary_path = Path(handle.name)
                handle.write(encoded)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, self.path)
            return True
        except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
            if temporary_path and temporary_path.exists():
                try:
                    temporary_path.unlink()
                except OSError:
                    pass
            raise SaveError("The game could not be saved. Your previous save was kept. " + str(exc)) from exc

    def load(self):
        """Return (GameState, world_data), never modifying the file on failure."""
        try:
            if not self.exists:
                raise SaveError("There is no saved story yet. Choose New Game to begin.")
            if self.path.stat().st_size > 10 * 1024 * 1024:
                raise SaveError("The save file is unexpectedly large. It was left untouched.")
            with self.path.open("r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if not isinstance(payload, dict) or payload.get("version") != self.VERSION:
                raise SaveError("This save uses an unsupported format. It was left untouched; you can start a new story.")
            state = GameState.from_dict(payload.get("game"))
            world_data = self._validate_world(payload.get("world", {}))
            return state, world_data
        except SaveError:
            raise
        except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError) as exc:
            raise SaveError("This save could not be read safely. It was left untouched. " + str(exc)) from exc
