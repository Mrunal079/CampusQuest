"""Campus residents: animated sprites with short collision-aware wander routes."""
import random
import pygame
from conversations import STUDENT_PROFILES

DIRECTION_ROWS = {"down": 0, "up": 1, "left": 2, "right": 3}


class NPC:
    def __init__(self, data, assets):
        self.id = data["id"]
        self.name = data.get("name", self.id.replace("_", " ").title())
        if self.id in STUDENT_PROFILES:
            self.name = STUDENT_PROFILES[self.id][0]
        self.name = {'librarian':'Harper', 'receptionist':'Avery', 'support':'Casey',
                     'adviser':'Imani', 'barista':'Jun'}.get(self.id,self.name)
        self.pos = pygame.Vector2(data["x"], data["y"])
        self.origin = self.pos.copy()
        self.rect = pygame.Rect(0, 0, 17, 12)
        self.rect.center = self.pos
        self.direction = data.get("direction", "down")
        self.wander = data.get("wander", False)
        self.radius = data.get("radius", 72)
        self.timer = random.uniform(.5, 3)
        self.velocity = pygame.Vector2()
        self.moving = False
        self.animation_time = random.random()
        self.sheet = None
        for name in (data.get("sprite", f"npcs/{self.id}.png"), "npcs/student1.png"):
            try:
                self.sheet = assets.image(name)
                break
            except (FileNotFoundError, pygame.error, KeyError):
                pass

    def update(self, dt, world):
        if not self.wander:
            return
        self.timer -= dt
        if self.timer <= 0:
            self.timer = random.uniform(1.0, 3.8)
            if random.random() < .35:
                self.velocity.update(0, 0)
            elif self.pos.distance_to(self.origin) > self.radius:
                self.velocity = self.origin - self.pos
                if self.velocity.length_squared():
                    self.velocity = self.velocity.normalize() * 29
            else:
                self.velocity = pygame.Vector2(random.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))) * 29
        self.moving = self.velocity.length_squared() > 0
        if not self.moving:
            return
        self.animation_time += dt
        if abs(self.velocity.x) > abs(self.velocity.y):
            self.direction = "right" if self.velocity.x > 0 else "left"
        else:
            self.direction = "down" if self.velocity.y > 0 else "up"
        next_pos = self.pos + self.velocity * min(dt, .08)
        rect = self.rect.copy()
        rect.center = next_pos
        if world.is_blocked(rect):
            self.velocity *= -1
            self.timer = .4
        else:
            self.pos = next_pos
            self.rect = rect

    def draw(self, surface, camera):
        if self.sheet is None:
            return
        frame = (1 + int(self.animation_time * 7) % 3) if self.moving else 0
        source = pygame.Rect(frame * 32, DIRECTION_ROWS[self.direction] * 48, 32, 48)
        surface.blit(self.sheet, (round(self.pos.x - 16 - camera.offset.x), round(self.pos.y - 41 - camera.offset.y)), source)

    def interaction(self):
        return {"id": self.id, "label": f"Talk to {self.name}", "kind": "npc",
                "name": self.name, "rect": self.rect.inflate(10, 10)}
