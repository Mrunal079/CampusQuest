CAMPUS QUEST: FIND YOUR NEXT MOVE
COMP9001 Python Final Project — run main.py

IMPORTANT FOR THE TUTOR
The complete playable copy is CampusQuest.zip. Extract the ZIP, open its
CampusQuest folder, and run main.py from that folder. The separately uploaded
Python files are the same program source. Keep assets/ and maps/ with main.py.
This is a desktop GUI game and must run locally, outside Ed's code runner.

REQUIREMENTS / DECLARATIONS
- Python 3.12 recommended; verified on Python 3.12.7 on macOS.
- External libraries: pygame-ce (>=2.5.3,<3), Pillow (>=10,<13).
- requirements.txt gives the exact dependency ranges for installation.
- Graphics / GUI: Pygame window, keyboard/mouse input and PNG artwork.
- Audio: optional playback of bundled local WAV effects using Pygame.
  No audio recording, audio/video processing workflow or video features.
- No web application, network calls, accounts, API keys or online service.
  Installing dependencies can require an internet connection; gameplay is local.
- Artwork, sound and JSON maps are included in the ZIP. Dependencies themselves
  are installed with pip; their third-party distributions are not bundled.

INSTALL AND RUN (macOS / Linux)
Open a terminal inside the extracted CampusQuest folder:
    python3 -m pip install -r requirements.txt
    python3 main.py
Use the same Python interpreter for installing and running.

ON THIS MAC'S ANACONDA ENVIRONMENT
    /opt/anaconda3/bin/python3 -m pip install -r requirements.txt
    /opt/anaconda3/bin/python3 main.py

WINDOWS
Open a terminal inside the extracted CampusQuest folder:
    py -3.12 -m pip install -r requirements.txt
    py -3.12 main.py
Windows instructions are provided; interactive testing was performed on macOS.
Do not install classic pygame alongside pygame-ce: they share an import name.

CONTROLS
WASD / arrows: move. E: interact. Tab: phone. F5: save. B: three challenges.
Mouse or arrows + Enter: choose. Enter: reveal text / continue reading.
Escape: previous conversation topic, phone Back, or pause while exploring.
Leave interiors through their physical exit doors.
Cafe Rush: 1-4 add ingredients, Left/Right select ticket, Space serve,
Backspace undo, C clear, H help. Recipes stay visible on tickets.

CHAPTER ONE
Enter the Library and Lecture Theatre. Use a library computer once for project
work (or complete the Logic Lab). Optional: sit with Maya. When all required
objectives are complete, use the chapter reward screen to continue.
Phone > Quests lists the required objectives and their progress.

PREVIEW LATER CHAPTERS WITHOUT COMPLETING CHAPTER ONE
    python3 main.py --demo-chapter 4
    python3 main.py --demo-chapter 5
    python3 main.py --demo-chapter 8
Choose any chapter number 1-8. These presentation journeys use a separate
file, data/demo_save.json. Normal play uses data/save.json; neither is supplied.

IMPLEMENTED CONCEPTS
- Object-oriented classes for game state, maps, NPCs, quests and puzzle rules.
- Two-dimensional tile and collision arrays drive drawing and movement.
- JSON file reading/writing for maps and validated save/load.
- Exception handling, modular functions, lists/dictionaries and state transitions.
The README.md explains these with the relevant modules.

VERIFICATION
70 automated tests passed, including all eight chapter paths, puzzle inputs,
conversation navigation, JSON save/load and resource/reward checks.
    python3 -m unittest discover -s tests -v
Optional window-free launch check:
    python3 main.py --headless --frames 60
No personal progress is needed; New Game starts a fresh story.

FICTIONAL SETTING
Campus services, supporting documents, timetables and approval outcomes are
fictional game mechanics, not real university systems or medical advice.
Conversations are authored branching choices, not unrestricted AI chat.
The three mini-games are optional. There are eight chapters on the same campus.

FILES TO UPLOAD TO ED
Upload all program Python files, this README.txt and the complete CampusQuest.zip.
The ZIP includes all program files, tests, assets/, maps/, data/README.txt,
requirements.txt and detailed documentation. It is under 2,000,000 bytes.
Review screenshots and personal saves are excluded from the submission ZIP.
If Ed rejects ZIP uploads, host the unchanged ZIP on GitHub/OneDrive, paste the
accessible link below and upload this README.txt and the Python files to Ed.
External link (only if needed): not needed for the prepared compact ZIP.
Test any hosted link while signed out. Do not change the submitted copy after
the deadline. See your course instructions for the final submission cutoff.

PROGRAM PYTHON FILES (19)
    asset_generator.py
    assets.py
    buildings.py
    conversations.py
    demo_tools.py
    dialogue.py
    events.py
    game.py
    game_state.py
    main.py
    npc.py
    player.py
    puzzle_ui.py
    puzzles.py
    quests.py
    save_system.py
    settings.py
    ui.py
    world.py

Additional verification Python files are included in tests/ in the ZIP.
See CREATED_FILES.txt for the complete archive file list.
