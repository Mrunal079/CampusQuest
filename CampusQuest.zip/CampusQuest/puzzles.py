"""Small, replayable break activities, independent of Pygame and game state.

Each model exposes actions and a timer; presentation code owns keyboard/mouse
input. Randomness is local and seeded, making a round reproducible for testing.
No puzzle executes Python supplied by the player.
"""

from collections import Counter
import math
import random


def _seconds(dt):
    """Ignore invalid frame durations instead of corrupting puzzle timers."""
    if isinstance(dt, bool) or not isinstance(dt, (int, float)):
        return 0.0
    return float(dt) if math.isfinite(dt) and dt > 0 else 0.0


def _valid_index(index, count):
    return isinstance(index, int) and not isinstance(index, bool) and 0 <= index < count


class MemoryPuzzle:
    """Find eight campus-symbol pairs after a short opening preview."""

    kind = "memory"
    title = "Campus Connections"
    instructions = "Remember the pairs. Select two cards; match all eight to finish."

    def __init__(self, seed=0):
        self.seed = seed
        self.cards = ["health", "energy", "focus", "social", "career", "document", "star", "money"] * 2
        random.Random(seed).shuffle(self.cards)
        self.matched = set()
        self.revealed = []
        self.cursor = 0
        self.moves = 0
        self.hints = 0
        self.complete = False
        self.elapsed = 0.0
        self.preview_remaining = 2.0
        self.mismatch_remaining = 0.0

    def select(self, index):
        """Flip one eligible card; a second card resolves a pair attempt."""
        if (self.complete or self.preview_remaining > 0 or self.mismatch_remaining > 0
                or not _valid_index(index, len(self.cards))
                or index in self.matched or index in self.revealed):
            return False
        self.cursor = index
        self.revealed.append(index)
        if len(self.revealed) == 2:
            self.moves += 1
            first, second = self.revealed
            if self.cards[first] == self.cards[second]:
                self.matched.update(self.revealed)
                self.revealed.clear()
                self.complete = len(self.matched) == len(self.cards)
            else:
                self.mismatch_remaining = 0.75
        return True

    def hint(self):
        """Offer a short full-board peek; peeks affect the star rating."""
        if self.complete or self.preview_remaining > 0 or self.mismatch_remaining > 0:
            return False
        self.hints += 1
        self.preview_remaining = 1.5
        return True

    def update(self, dt):
        if self.complete:
            return
        dt = _seconds(dt)
        self.elapsed += dt
        self.preview_remaining = max(0.0, self.preview_remaining - dt)
        if self.mismatch_remaining > 0:
            self.mismatch_remaining = max(0.0, self.mismatch_remaining - dt)
            if self.mismatch_remaining == 0:
                self.revealed.clear()

    def reset(self):
        self.__init__(self.seed)

    @property
    def score(self):
        if self.moves <= 12 and self.hints == 0:
            return 3
        return 2 if self.moves <= 20 and self.hints <= 2 else 1

    @property
    def rating_label(self):
        return {3: "Photographic memory!", 2: "Making connections", 1: "A refreshing reset"}[self.score]


class CafePuzzle:
    """A six-customer drink-making rush with visible recipes and a live queue.

    The legacy ``route`` save key keeps existing badge/reward records compatible.
    Timers start with the first ingredient. Late customers patiently retry their
    order, so mistakes affect stars but cannot make a round impossible to finish.
    Recipes compare ingredient quantities, independent of pouring order.
    """

    kind = "route"
    title = "Petal & Bean: Cafe Rush"
    ingredients = ("Coffee", "Milk", "Cocoa", "Ice")
    recipes = {
        "Latte": (0, 1, 1),
        "Mocha": (0, 1, 2),
        "Iced coffee": (0, 3, 3),
        "Hot chocolate": (1, 1, 2),
    }
    total_orders = 6
    patience_limit = 45.0

    def __init__(self, seed=0):
        self.seed = seed
        rng = random.Random(seed)
        drinks = list(self.recipes) + rng.choices(list(self.recipes), k=2)
        rng.shuffle(drinks)
        names = ["Maya", "Leo", "Nina", "Riya", "Omar", "Tess"]
        rng.shuffle(names)
        self.orders = [{"name": name, "drink": drink, "patience": self.patience_limit,
                        "portrait": ("maya", "leo", "nina")[i % 3]}
                       for i, (name, drink) in enumerate(zip(names, drinks))]
        self.queue = self.orders[:3]
        self.next_order = 3
        self.selected = 0
        self.cup = []
        self.served = 0
        self.moves = 0
        self.mistakes = 0
        self.late = 0
        self.streak = 0
        self.best_streak = 0
        self.hints = 0
        self.complete = False
        self.started = False
        self.elapsed = 0.0
        self.feedback = "Read the tickets first. Adding an ingredient starts the rush!"
        self.feedback_remaining = 0.0

    @property
    def current(self):
        return self.queue[self.selected] if self.queue else None

    def select_order(self, index):
        if self.complete or not _valid_index(index, len(self.queue)):
            return False
        self.selected = index
        return True

    def add(self, ingredient):
        if self.complete or not _valid_index(ingredient, len(self.ingredients)) or len(self.cup) >= 3:
            return False
        self.started = True
        self.cup.append(ingredient)
        return True

    def undo(self):
        if self.complete or not self.cup:
            return False
        self.cup.pop()
        return True

    def clear(self):
        if self.complete or not self.cup:
            return False
        self.cup.clear()
        return True

    def serve(self):
        if self.complete or not self.cup:
            return False
        self.moves += 1
        expected = self.recipes[self.current["drink"]]
        if Counter(self.cup) != Counter(expected):
            self.mistakes += 1
            self.streak = 0
            self.cup.clear()
            self.feedback = "Not that recipe. Cup cleared: check the selected ticket and try again."
            self.feedback_remaining = 4.0
            return False
        name = self.current["name"]
        self.served += 1
        self.streak += 1
        self.best_streak = max(self.best_streak, self.streak)
        self.cup.clear()
        self.queue.pop(self.selected)
        if self.next_order < self.total_orders:
            self.queue.append(self.orders[self.next_order])
            self.next_order += 1
        self.selected = min(self.selected, max(0, len(self.queue) - 1))
        self.complete = self.served == self.total_orders
        self.feedback = ("Six happy customers! Your practice shift is complete." if self.complete
                         else f"Thanks from {name}! Streak: {self.streak}. Choose your next ticket.")
        self.feedback_remaining = 4.0
        return True

    def hint(self):
        """Prepare the selected recipe; the player still chooses to serve it."""
        if self.complete:
            return False
        self.hints += 1
        self.started = True
        self.cup = list(self.recipes[self.current["drink"]])
        self.feedback = "Jun helped mix this recipe. Press SERVE when you are ready."
        self.feedback_remaining = 4.0
        return True

    def update(self, dt):
        if self.complete:
            return
        dt = _seconds(dt)
        self.elapsed += dt
        if self.feedback_remaining > 0:
            self.feedback_remaining = max(0.0, self.feedback_remaining - dt)
            if self.feedback_remaining == 0:
                self.feedback = "Choose a ticket, match its recipe, then serve."
        if not self.started:
            return
        for order in self.queue:
            remaining = order["patience"] - dt
            if remaining <= 0:
                self.late += int((-remaining) // self.patience_limit) + 1
                order["patience"] = self.patience_limit - ((-remaining) % self.patience_limit)
                self.streak = 0
                self.feedback = "A customer waited too long, but will retry. Their ticket is still here."
                self.feedback_remaining = 4.0
            else:
                order["patience"] = remaining

    def reset(self):
        self.__init__(self.seed)

    @property
    def score(self):
        penalties = self.mistakes + self.late + self.hints
        return 3 if penalties == 0 else 2 if penalties <= 3 else 1

    @property
    def rating_label(self):
        return {3: "Rush-hour superstar!", 2: "A lovely little shift", 1: "Every customer served"}[self.score]


class CodePuzzle:
    """Repair three short dependency chains by swapping Python statement cards."""

    kind = "code"
    title = "Code Scramble"
    instructions = "Select two lines to swap them. Put the program in order, then CHECK."
    _ROUNDS = (
        {
            "prompt": 'Make this program print: Progress: 30%',
            "lines": ['minutes_left = 45', 'study_blocks = minutes_left // 15',
                      'progress = study_blocks * 10', 'message = "Progress: " + str(progress) + "%"',
                      'print(message)'],
            "hint": "Define a variable before a later line uses it. Start with minutes_left.",
        },
        {
            "prompt": 'Make this program print: Ready to study: True',
            "lines": ['energy = 30', 'after_break = energy + 20', 'after_walk = after_break - 5',
                      'can_study = after_walk >= 40', 'print("Ready to study:", can_study)'],
            "hint": "Follow energy through the break and walk, then check readiness.",
        },
        {
            "prompt": 'Make this program print: Next: Draft at the library',
            "lines": ['tasks = ["Draft", "Review", "Submit"]', 'next_task = tasks[0]',
                      'message = "Next: " + next_task', 'reminder = message + " at the library"',
                      'print(reminder)'],
            "hint": "Create the task list before indexing it; print the completed reminder last.",
        },
        {
            "prompt": 'Make this program print: Snack budget: 4',
            "lines": ['coins = 12', 'ticket_price = coins // 3', 'remaining = coins - ticket_price',
                      'snack_budget = remaining // 2', 'print("Snack budget:", snack_budget)'],
            "hint": "Start with your coins, subtract the ticket, then halve what remains.",
        },
        {
            "prompt": 'Make this program print: Complete 7 blocks',
            "lines": ['hours_left = 3', 'minutes_left = hours_left * 60', 'blocks = minutes_left // 25',
                      'plan = "Complete " + str(blocks) + " blocks"', 'print(plan)'],
            "hint": "Convert hours to minutes before calculating complete study blocks.",
        },
    )

    def __init__(self, seed=0):
        self.seed = seed
        self._rng = random.Random(seed)
        choices = self._rng.sample(list(self._ROUNDS), 3)
        self.rounds = [{"prompt": item["prompt"], "lines": list(item["lines"]), "hint": item["hint"]}
                       for item in choices]
        self.round_index = 0
        self.cursor = 0
        self.selected = None
        self.moves = 0
        self.mistakes = 0
        self.hints = 0
        self.complete = False
        self.elapsed = 0.0
        self.feedback = ""
        self.feedback_remaining = 0.0
        self._load_round()

    def _load_round(self):
        correct = self.rounds[self.round_index]["lines"]
        self.lines = list(correct)
        self._rng.shuffle(self.lines)
        if self.lines == correct:
            self.lines = self.lines[1:] + self.lines[:1]
        self.cursor = 0
        self.selected = None

    @property
    def prompt(self):
        return self.rounds[self.round_index]["prompt"]

    def select(self, index):
        if self.complete or not _valid_index(index, len(self.lines)):
            return False
        self.cursor = index
        if self.selected is None:
            self.selected = index
        elif self.selected == index:
            self.selected = None
        else:
            first = self.selected
            self.lines[first], self.lines[index] = self.lines[index], self.lines[first]
            self.moves += 1
            self.selected = None
        return True

    def check(self):
        """Check the intended statement order without evaluating any code."""
        if self.complete:
            return False
        if self.lines != self.rounds[self.round_index]["lines"]:
            self.mistakes += 1
            self.feedback = "Not quite. Each variable must be defined before it is used."
            self.feedback_remaining = 3.0
            return False
        self.selected = None
        if self.round_index == len(self.rounds) - 1:
            self.complete = True
            self.feedback = "All three programs repaired!"
        else:
            self.round_index += 1
            self._load_round()
            self.feedback = "Program repaired! Next challenge."
        self.feedback_remaining = 2.0
        return True

    def hint(self):
        """Repair one misplaced statement; CHECK is still required to advance."""
        if self.complete:
            return False
        correct = self.rounds[self.round_index]["lines"]
        for index, line in enumerate(correct):
            if self.lines[index] != line:
                other = self.lines.index(line)
                self.lines[index], self.lines[other] = self.lines[other], self.lines[index]
                self.moves += 1
                self.hints += 1
                self.selected = None
                self.cursor = index
                self.feedback = self.rounds[self.round_index]["hint"]
                self.feedback_remaining = 4.0
                return True
        self.feedback = "The order looks ready. Press CHECK to run the check."
        self.feedback_remaining = 2.0
        return False

    def update(self, dt):
        dt = _seconds(dt)
        if not self.complete:
            self.elapsed += dt
        if self.feedback_remaining > 0:
            self.feedback_remaining = max(0.0, self.feedback_remaining - dt)
            if self.feedback_remaining == 0:
                self.feedback = ""

    def reset(self):
        self.__init__(self.seed)

    @property
    def score(self):
        if self.mistakes == 0 and self.hints == 0:
            return 3
        return 2 if self.mistakes <= 3 and self.hints <= 3 else 1

    @property
    def rating_label(self):
        return {3: "Clean code champion!", 2: "Debugger in training", 1: "Every bug is a lesson"}[self.score]
