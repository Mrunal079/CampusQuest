"""Keyboard/mouse branching conversations, independent from activity rules."""
from dataclasses import dataclass
import pygame


@dataclass
class Choice:
    label: str
    action: str = ''


class DialogueManager:
    def __init__(self):
        self.open = False
        self.speaker = ''
        self.text = ''
        self.portrait = 'student'
        self._choices = []
        self.pages = ['']
        self.page_index = 0
        self.back_action = ''
        self.topic = ''
        self.layout_font = None
        self.selected = 0
        self.visible = 0.0
        self.choice_rects = []

    @property
    def choices(self):
        if self.page_index < len(self.pages)-1:
            return [Choice('CONTINUE READING', '__next_page__')]
        return self._choices

    def set_layout(self, font, width=735, lines=4):
        self.layout_font = font
        self.layout_width = width
        self.layout_lines = lines

    def _paginate(self, text):
        if self.layout_font is None:
            return [text]
        lines=[]
        for paragraph in text.split('\n'):
            line=''
            for word in paragraph.split():
                candidate=(line+' '+word).strip()
                if line and self.layout_font.size(candidate)[0]>self.layout_width:
                    lines.append(line)
                    line=word
                else:
                    line=candidate
            lines.append(line)
        return ['\n'.join(lines[i:i+self.layout_lines]) for i in range(0,len(lines),self.layout_lines)] or ['']

    def show(self, speaker, text, choices=None, portrait='student', back_action='', topic=''):
        self.open = True
        self.speaker = speaker
        self.pages = self._paginate(str(text))
        self.page_index = 0
        self.text = self.pages[0]
        self.portrait = portrait
        self._choices = [c if isinstance(c, Choice) else Choice(*c) for c in (choices or [('CONTINUE', '')])]
        self.back_action = back_action
        self.topic = topic
        self.selected = 0
        self.visible = 0.0
        self.choice_rects = []

    def close(self):
        self.open = False

    def change_page(self, step):
        target=self.page_index+step
        if 0<=target<len(self.pages):
            self.page_index=target
            self.text=self.pages[target]
            self.visible=0
            self.selected=0
            self.choice_rects=[]
            return True
        return False

    def _choose(self, index):
        if self.visible < len(self.text):
            self.visible = len(self.text)
            return None
        if self.page_index < len(self.pages)-1:
            self.change_page(1)
            return None
        action=self.choices[index].action
        self.close()
        return action

    def update(self, dt):
        self.visible = min(len(self.text), self.visible + dt * 100)

    def handle(self, event):
        if not self.open:
            return None
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.close()
                return self.back_action or '__closed__'
            if event.key in (pygame.K_LEFT, pygame.K_PAGEUP):
                self.change_page(-1)
                return None
            if event.key in (pygame.K_RIGHT, pygame.K_PAGEDOWN) and self.page_index < len(self.pages)-1:
                self.change_page(1)
                return None
            if event.key in (pygame.K_UP, pygame.K_w):
                self.selected = (self.selected - 1) % len(self.choices)
            if event.key in (pygame.K_DOWN, pygame.K_s):
                self.selected = (self.selected + 1) % len(self.choices)
            if event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
                return self._choose(self.selected)
        if event.type == pygame.MOUSEMOTION:
            for i, rect in enumerate(self.choice_rects):
                if rect.collidepoint(event.pos):
                    self.selected = i
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self.choice_rects):
                if rect.collidepoint(event.pos):
                    return self._choose(i)
            self.visible = len(self.text)
        return None
